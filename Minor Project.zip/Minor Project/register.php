<?php
// register.php - User Registration Page

require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Redirect if already logged in
if (is_logged_in()) {
    header("Location: dashboard.php");
    exit;
}

$error_msg = "";
$success_msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Validate inputs
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $error_msg = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_msg = "Please enter a valid email address.";
    } elseif (strlen($password) < 6) {
        $error_msg = "Password must be at least 6 characters long.";
    } elseif ($password !== $confirm_password) {
        $error_msg = "Passwords do not match.";
    } else {
        $db = getDBConnection();
        
        // Check if username or email already exists
        $stmt = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            $error_msg = "Username or Email is already registered.";
        } else {
            // Hash password and insert
            $password_hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $db->prepare("INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, 'user')");
            if ($stmt->execute([$username, $email, $password_hash])) {
                // Get the inserted user ID
                $userId = $db->lastInsertId();
                
                // Automatically log them in
                login_user($userId, $username, 'user');
                
                header("Location: dashboard.php?registered=1");
                exit;
            } else {
                $error_msg = "Registration failed. Please try again.";
            }
        }
    }
}

$page_title = "Create an Account";
require_once 'includes/header.php';
?>

<div class="container d-flex align-items-center justify-content-center" style="min-height: calc(100vh - 120px); padding-top: 80px;">
    <div class="row w-100 justify-content-center">
        <div class="col-md-6 col-lg-5 col-xl-4">
            <div class="card glass-card p-4 animate-fade-in">
                <div class="card-body">
                    <div class="text-center mb-4">
                        <i class="bi bi-rocket-takeoff-fill text-gradient fs-1"></i>
                        <h2 class="fw-bold mt-2">Get Started</h2>
                        <p class="text-secondary">Join CareerCraft AI today</p>
                    </div>

                    <?php if ($error_msg): ?>
                        <div class="alert alert-danger d-flex align-items-center py-2" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i>
                            <div><?php echo htmlspecialchars($error_msg); ?></div>
                        </div>
                    <?php endif; ?>

                    <form action="register.php" method="POST" novalidate>
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <div class="input-group">
                                <span class="input-group-text bg-transparent border-end-0 border-indigo"><i class="bi bi-person text-secondary"></i></span>
                                <input type="text" class="form-control border-start-0" id="username" name="username" value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" required placeholder="johndoe">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email address</label>
                            <div class="input-group">
                                <span class="input-group-text bg-transparent border-end-0"><i class="bi bi-envelope text-secondary"></i></span>
                                <input type="email" class="form-control border-start-0" id="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required placeholder="john@example.com">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <div class="input-group">
                                <span class="input-group-text bg-transparent border-end-0"><i class="bi bi-lock text-secondary"></i></span>
                                <input type="password" class="form-control border-start-0" id="password" name="password" required placeholder="••••••••">
                            </div>
                        </div>

                        <div class="mb-4">
                            <label for="confirm_password" class="form-label">Confirm Password</label>
                            <div class="input-group">
                                <span class="input-group-text bg-transparent border-end-0"><i class="bi bi-shield-lock text-secondary"></i></span>
                                <input type="password" class="form-control border-start-0" id="confirm_password" name="confirm_password" required placeholder="••••••••">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-gradient w-100 py-2 mb-3">Sign Up</button>
                    </form>

                    <div class="text-center mt-3">
                        <span class="text-secondary small">Already have an account?</span>
                        <a href="login.php" class="text-gradient fw-bold small ms-1 text-decoration-none">Sign In</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
