<?php
// ai_generate.php - Backend Asynchronous AI Operations Controller

header('Content-Type: application/json');

require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_once 'api/gemini.php';

// Authentication Check
if (!is_logged_in()) {
    echo json_encode(["error" => "Authentication required."]);
    exit;
}

$db = getDBConnection();
$userId = get_logged_in_user_id();

// Helper to fetch complete resume data
function get_complete_resume_data($db, $resumeId, $userId) {
    // Verify ownership
    $stmt = $db->prepare("SELECT * FROM resumes WHERE id = ? AND user_id = ?");
    $stmt->execute([$resumeId, $userId]);
    $resume = $stmt->fetch();
    
    if (!$resume) return null;

    // Fetch child tables
    $stmt = $db->prepare("SELECT * FROM education WHERE resume_id = ?");
    $stmt->execute([$resumeId]);
    $resume['education'] = $stmt->fetchAll();

    $stmt = $db->prepare("SELECT * FROM experience WHERE resume_id = ?");
    $stmt->execute([$resumeId]);
    $resume['experience'] = $stmt->fetchAll();

    $stmt = $db->prepare("SELECT * FROM projects WHERE resume_id = ?");
    $stmt->execute([$resumeId]);
    $resume['projects'] = $stmt->fetchAll();

    $stmt = $db->prepare("SELECT * FROM skills WHERE resume_id = ?");
    $stmt->execute([$resumeId]);
    $resume['skills'] = $stmt->fetchAll();

    $stmt = $db->prepare("SELECT * FROM certificates WHERE resume_id = ?");
    $stmt->execute([$resumeId]);
    $resume['certificates'] = $stmt->fetchAll();

    $stmt = $db->prepare("SELECT * FROM achievements WHERE resume_id = ?");
    $stmt->execute([$resumeId]);
    $resume['achievements'] = $stmt->fetchAll();

    return $resume;
}

// Log AI interaction metrics
function log_ai_usage($db, $userId, $resumeId, $action) {
    $stmt = $db->prepare("INSERT INTO ai_history (user_id, resume_id, action_type) VALUES (?, ?, ?)");
    $stmt->execute([$userId, $resumeId, $action]);
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? $_POST['action'] ?? '';
$resumeId = $input['resume_id'] ?? $_POST['resume_id'] ?? null;

if (empty($action)) {
    echo json_encode(["error" => "Missing action parameter."]);
    exit;
}

try {
    switch ($action) {
        case 'rewrite_text':
            $text = $input['text'] ?? '';
            if (empty($text)) {
                echo json_encode(["error" => "No text provided to rewrite."]);
                exit;
            }
            
            $prompt = "You are a professional resume writer and career expert. Please rewrite the following sentence or description to be highly professional, impactful, and recruiter-friendly. Use active verbs and professional phrasing while preserving the core facts. Return ONLY the rewritten text, with no introductory text, no quotes, and no conversational filler.\n\nText: \"$text\"";
            
            $response = ask_gemini($prompt, false);
            log_ai_usage($db, $userId, $resumeId, 'rewrite_text');
            
            echo json_encode(["result" => trim($response)]);
            break;

        case 'generate_summary':
            $targetRole = $input['target_role'] ?? 'Software Engineer';
            $skillsList = $input['skills'] ?? '';
            $expList = $input['experience'] ?? '';
            
            $prompt = "Create a brief, highly professional summary (2-3 sentences, about 50-70 words) for a resume, tailored for the target job role: \"$targetRole\".\nSkills: \"$skillsList\"\nExperience Highlights: \"$expList\"\nWrite in third-person or standard resume bullet format without using personal pronouns (like 'I' or 'my'). Return ONLY the summary content, no labels, no quotes.";
            
            $response = ask_gemini($prompt, false);
            log_ai_usage($db, $userId, $resumeId, 'generate_summary');
            
            echo json_encode(["result" => trim($response)]);
            break;

        case 'score_resume':
            if (!$resumeId) {
                echo json_encode(["error" => "Resume ID is required."]);
                exit;
            }

            $resume = get_complete_resume_data($db, $resumeId, $userId);
            if (!$resume) {
                echo json_encode(["error" => "Resume not found or access denied."]);
                exit;
            }

            // Build detailed data summary for AI analyzer
            $resumeText = "Target Job: " . $resume['target_job_role'] . "\n";
            $resumeText .= "Professional Summary: " . $resume['summary'] . "\n";
            
            $resumeText .= "Skills:\n";
            foreach ($resume['skills'] as $s) {
                $resumeText .= "- " . $s['name'] . " (" . $s['skill_type'] . ")\n";
            }
            
            $resumeText .= "Experience:\n";
            foreach ($resume['experience'] as $e) {
                $resumeText .= "- " . $e['position'] . " at " . $e['company'] . " (" . $e['description'] . ")\n";
            }

            $resumeText .= "Education:\n";
            foreach ($resume['education'] as $edu) {
                $resumeText .= "- " . $edu['degree'] . " in " . $edu['field_of_study'] . " at " . $edu['institution'] . "\n";
            }

            $prompt = "Analyze the following resume for a target job role of \"" . $resume['target_job_role'] . "\" and generate a detailed score out of 100.\n\n" .
                      "Provide your response as a strict JSON object with EXACTLY the following structure (no markdown wrapper, no extra code text, just raw JSON):\n" .
                      "{\n" .
                      "  \"score\": 85,\n" .
                      "  \"grammar_score\": 90,\n" .
                      "  \"ats_score\": 80,\n" .
                      "  \"missing_keywords\": [\"Docker\", \"CI/CD\", \"Agile\"],\n" .
                      "  \"keyword_distribution\": [\n" .
                      "    {\"text\": \"PHP\", \"value\": 10},\n" .
                      "    {\"text\": \"MySQL\", \"value\": 8}\n" .
                      "  ],\n" .
                      "  \"suggestions\": [\n" .
                      "    \"Include measurable results in your experience description.\",\n" .
                      "    \"Add key project technologies in the tech stack.\"\n" .
                      "  ]\n" .
                      "}\n\n" .
                      "Resume Data:\n$resumeText";

            $response = ask_gemini($prompt, true);
            
            // Clean markdown blocks if Gemini returned them
            $cleanResponse = preg_replace('/```(json)?/', '', $response);
            $cleanResponse = trim($cleanResponse);
            
            $data = json_decode($cleanResponse, true);
            
            if ($data && isset($data['score'])) {
                // Save to database
                $stmt = $db->prepare("INSERT INTO resume_scores (resume_id, score, grammar_score, ats_score, keywords_analysis, suggestions) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $resumeId,
                    $data['score'],
                    $data['grammar_score'],
                    $data['ats_score'],
                    json_encode($data['keyword_distribution']),
                    implode("\n", $data['suggestions'])
                ]);
                
                log_ai_usage($db, $userId, $resumeId, 'score_resume');
                echo $cleanResponse;
            } else {
                echo json_encode([
                    "error" => "Failed to parse AI scoring response.", 
                    "raw" => $response
                ]);
            }
            break;

        case 'recommend_skills':
            $skills = $input['skills'] ?? '';
            $prompt = "The candidate has the following skills on their resume: \"$skills\". Give 7 recommendations for additional skills they should add to match industry standards, returning ONLY a raw JSON array of strings. Do not include markdown code fences or other text. Example: [\"Git\", \"Bootstrap\", \"REST API\"]";
            
            $response = ask_gemini($prompt, true);
            $cleanResponse = preg_replace('/```(json)?/', '', $response);
            $cleanResponse = trim($cleanResponse);
            
            log_ai_usage($db, $userId, $resumeId, 'recommend_skills');
            echo $cleanResponse;
            break;

        case 'generate_cover_letter':
            if (!$resumeId) {
                echo json_encode(["error" => "Resume ID is required."]);
                exit;
            }
            
            $company = $input['company_name'] ?? 'Target Company';
            $jobRole = $input['job_role'] ?? 'Software Developer';
            
            $resume = get_complete_resume_data($db, $resumeId, $userId);
            if (!$resume) {
                echo json_encode(["error" => "Resume not found."]);
                exit;
            }

            // Create contextual info
            $info = "Candidate Name: " . $resume['full_name'] . "\n";
            $info .= "Target Job: $jobRole\n";
            $info .= "Target Company: $company\n";
            $info .= "Skills: " . implode(', ', array_map(function($s) { return $s['name']; }, $resume['skills'])) . "\n";
            $info .= "Experience: ";
            foreach ($resume['experience'] as $e) {
                $info .= $e['position'] . " at " . $e['company'] . " (" . $e['description'] . "); ";
            }

            $prompt = "Write a persuasive, high-quality, professional cover letter based on the following candidate information:\n\n$info\n\n" .
                      "Tailor it for the role of \"$jobRole\" at \"$company\". Ensure it is grammatically perfect, compelling, and has placeholders like [Date] where appropriate. Return ONLY the content of the letter.";
            
            $response = ask_gemini($prompt, false);
            
            if ($response && !isset(json_decode($response, true)['error'])) {
                // Save cover letter
                $stmt = $db->prepare("INSERT INTO cover_letters (resume_id, company_name, job_role, content) VALUES (?, ?, ?, ?)");
                $stmt->execute([$resumeId, $company, $jobRole, $response]);
                
                log_ai_usage($db, $userId, $resumeId, 'generate_cover_letter');
                echo json_encode(["result" => $response, "id" => $db->lastInsertId()]);
            } else {
                echo json_encode(["error" => "Failed to generate cover letter.", "raw" => $response]);
            }
            break;

        case 'generate_interview':
            if (!$resumeId) {
                echo json_encode(["error" => "Resume ID is required."]);
                exit;
            }
            
            $resume = get_complete_resume_data($db, $resumeId, $userId);
            if (!$resume) {
                echo json_encode(["error" => "Resume not found."]);
                exit;
            }

            $skills = implode(', ', array_map(function($s) { return $s['name']; }, $resume['skills']));
            $projects = implode(', ', array_map(function($p) { return $p['title'] . " (" . $p['description'] . ")"; }, $resume['projects']));
            
            $prompt = "Based on this candidate's details, generate exactly 20 interview questions. Split them into 'easy' (6 questions), 'medium' (7 questions), and 'advanced' (7 questions) categories based on these skills: \"$skills\" and these projects: \"$projects\".\n\n" .
                      "Return a strict JSON object (no markdown wrapping) like this:\n" .
                      "{\n" .
                      "  \"easy\": [\"Question 1?\", \"Question 2?\"],\n" .
                      "  \"medium\": [\"Question 1?\", \"Question 2?\"],\n" .
                      "  \"advanced\": [\"Question 1?\", \"Question 2?\"]\n" .
                      "}";
            
            $response = ask_gemini($prompt, true);
            $cleanResponse = preg_replace('/```(json)?/', '', $response);
            $cleanResponse = trim($cleanResponse);
            
            log_ai_usage($db, $userId, $resumeId, 'generate_interview');
            echo $cleanResponse;
            break;

        case 'chatbot_message':
            $message = $input['message'] ?? '';
            $chatHistory = $input['history'] ?? [];
            
            if (empty($message)) {
                echo json_encode(["error" => "No message provided."]);
                exit;
            }

            // Build a chat transcript
            $transcript = "You are 'CareerCraft AI', a helpful, advanced, premium career coach chatbot integrated inside a web application. Your job is to help users construct, refine, and review their resumes, prepare for interviews, or suggest career growth paths.\n\n";
            
            foreach ($chatHistory as $chat) {
                $roleName = $chat['role'] === 'user' ? 'User' : 'Assistant';
                $transcript .= "$roleName: " . $chat['text'] . "\n";
            }
            
            $transcript .= "User: $message\n";
            $transcript .= "Assistant: ";

            $response = ask_gemini($transcript, false);
            log_ai_usage($db, $userId, null, 'chatbot');
            
            echo json_encode(["result" => trim($response)]);
            break;

        default:
            echo json_encode(["error" => "Invalid action specified."]);
            break;
    }
} catch (Exception $e) {
    echo json_encode(["error" => "Execution Exception: " . $e->getMessage()]);
}
?>
