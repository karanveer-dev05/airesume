<?php
// gemini.php - Gemini API Client Integration Wrapper

require_once __DIR__ . '/../includes/config.php';

/**
 * Sends a prompt to the Gemini API and returns the text response.
 * Handles API key checking and processes optional JSON output configuration.
 *
 * @param string $prompt The prompt to send.
 * @param bool $json_mode Attempt to request and parse JSON from the model.
 * @return string The generated text.
 */
function ask_gemini($prompt, $json_mode = false) {
    if (GEMINI_API_KEY === 'YOUR_GEMINI_API_KEY_HERE' || empty(GEMINI_API_KEY)) {
        // Return a realistic mock response for demo purposes if no API key is set yet
        return get_mock_gemini_response($prompt, $json_mode);
    }

    $url = GEMINI_API_URL . "?key=" . GEMINI_API_KEY;

    $payload = [
        "contents" => [
            [
                "parts" => [
                    ["text" => $prompt]
                ]
            ]
        ]
    ];

    if ($json_mode) {
        $payload["generationConfig"] = [
            "responseMimeType" => "application/json"
        ];
    }

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    
    // In local development we can optionally disable SSL verification if it throws certificates errors
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if (curl_errno($ch)) {
        $error_msg = curl_error($ch);
        curl_close($ch);
        return json_encode(["error" => "cURL error: " . $error_msg]);
    }
    
    curl_close($ch);

    if ($http_code !== 200) {
        return json_encode([
            "error" => "API returned HTTP code " . $http_code,
            "raw_response" => $response
        ]);
    }

    $result = json_decode($response, true);
    
    if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
        return $result['candidates'][0]['content']['parts'][0]['text'];
    }

    return json_encode(["error" => "Unexpected Gemini API response structure.", "raw" => $result]);
}

/**
 * Returns mock data for essential workflows when API key is missing.
 * This ensures the application has high testability out-of-the-box in local XAMPP.
 */
function get_mock_gemini_response($prompt, $json_mode) {
    $prompt_lower = strtolower($prompt);

    if ($json_mode) {
        // 1. ATS Checker and Resume Scorer
        if (strpos($prompt_lower, 'score') !== false || strpos($prompt_lower, 'ats') !== false) {
            return json_encode([
                "score" => 78,
                "grammar_score" => 85,
                "ats_score" => 72,
                "missing_keywords" => ["REST API", "Docker", "Unit Testing", "TailwindCSS"],
                "keyword_distribution" => [
                    ["text" => "PHP", "value" => 10],
                    ["text" => "MySQL", "value" => 8],
                    ["text" => "HTML", "value" => 7],
                    ["text" => "CSS", "value" => 7],
                    ["text" => "JavaScript", "value" => 9],
                    ["text" => "Bootstrap", "value" => 6]
                ],
                "suggestions" => [
                    "Add measurable results (e.g., 'improved performance by 25%')",
                    "Include soft skills like Team Leadership or Agile Methodologies",
                    "Add missing key developer words like Git, CI/CD, or REST API",
                    "Avoid multi-column nested templates for ATS compatibility"
                ]
            ]);
        }
        
        // 2. Career Suggestions
        if (strpos($prompt_lower, 'career') !== false || strpos($prompt_lower, 'salary') !== false) {
            return json_encode([
                "roles" => [
                    ["title" => "Full Stack Web Developer", "salary" => "$85,000 - $110,000", "match" => "95%"],
                    ["title" => "Backend Software Engineer", "salary" => "$90,000 - $125,000", "match" => "88%"],
                    ["title" => "Database Administrator", "salary" => "$80,000 - $105,000", "match" => "78%"]
                ],
                "missing_skills" => ["Node.js", "Docker", "REST API", "TailwindCSS"],
                "roadmap" => [
                    "Step 1: Master Object-Oriented PHP & MVC design patterns.",
                    "Step 2: Learn Modern JavaScript frameworks like React, Vue or Node.js.",
                    "Step 3: Familiarize with cloud deployments (AWS, Docker, CI/CD pipelines)."
                ],
                "technologies" => ["Laravel 11", "React.js", "MongoDB", "Kubernetes"]
            ]);
        }

        // 3. Interview Questions
        if (strpos($prompt_lower, 'interview') !== false || strpos($prompt_lower, 'question') !== false) {
            return json_encode([
                "easy" => [
                    "What is the difference between GET and POST requests in PHP?",
                    "How do you style elements using Bootstrap grid classes?"
                ],
                "medium" => [
                    "Explain MVC architecture and how to implement it in PHP.",
                    "What is database normalization and why is it important?"
                ],
                "advanced" => [
                    "How do you prevent SQL injection vulnerabilities in dynamic queries?",
                    "Explain the difference between call, apply, and bind in JavaScript."
                ]
            ]);
        }

        // 4. Smart Skills Recommendation
        if (strpos($prompt_lower, 'skills') !== false || strpos($prompt_lower, 'recommend') !== false) {
            return json_encode(["Bootstrap", "React", "Git", "REST API", "Node.js", "PHP", "MySQL"]);
        }

        return json_encode(["message" => "Mock JSON generated successfully."]);
    } else {
        // Text outputs (Cover letter, rewrite summaries, etc.)
        if (strpos($prompt_lower, 'cover letter') !== false) {
            return "[Your Contact Information]\n[City, State]\n\nDear Hiring Team,\n\nI am writing to express my strong interest in the Developer position. With my background in developing custom solutions using HTML, CSS, JavaScript, PHP, and MySQL, I am confident in my ability to contribute value to your development team.\n\nDuring my projects, I designed and developed dynamic websites, optimized database queries, and implemented responsive client layouts using Bootstrap. I would welcome the opportunity to discuss my qualifications further.\n\nSincerely,\n[Applicant]";
        }
        
        if (strpos($prompt_lower, 'grammar') !== false || strpos($prompt_lower, 'rewrite') !== false) {
            return "Designed and developed a responsive web application using HTML, CSS, JavaScript, PHP and MySQL, improving overall user experience and application load performance by 30%.";
        }

        if (strpos($prompt_lower, 'summary') !== false) {
            return "Results-driven Software Developer with hands-on experience designing and building secure, database-driven web applications using PHP, JavaScript, and Bootstrap. Skilful at writing clean code and optimizing performance.";
        }

        return "Gemini AI: This is a placeholder text response generated under Local Demo Mode.";
    }
}
?>
