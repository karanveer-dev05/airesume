<?php
// portfolio.php - AI Personal Portfolio Website Builder and Host

require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

$db = getDBConnection();
$resumeId = intval($_GET['id'] ?? $_GET['resume_id'] ?? 0);

// Check if accessing as public preview or recruiter mode
$isPreview = isset($_GET['preview']) && $_GET['preview'] === '1';
$shareToken = $_GET['token'] ?? null;

$resume = null;

if ($shareToken) {
    // Recruiter public access
    $stmt = $db->prepare("SELECT * FROM resumes WHERE share_token = ?");
    $stmt->execute([$shareToken]);
    $resume = $stmt->fetch();
} elseif ($resumeId > 0) {
    // User or preview access (Verify ownership if not preview)
    if (!$isPreview) {
        require_login();
        $userId = get_logged_in_user_id();
        $stmt = $db->prepare("SELECT * FROM resumes WHERE id = ? AND user_id = ?");
        $stmt->execute([$resumeId, $userId]);
        $resume = $stmt->fetch();
    } else {
        // Simple public display
        $stmt = $db->prepare("SELECT * FROM resumes WHERE id = ?");
        $stmt->execute([$resumeId]);
        $resume = $stmt->fetch();
    }
}

// Redirect if resume not found
if (!$resume) {
    if (is_logged_in()) {
        // Let the user pick a resume
        $stmt = $db->prepare("SELECT * FROM resumes WHERE user_id = ? ORDER BY updated_at DESC");
        $stmt->execute([get_logged_in_user_id()]);
        $resumes = $stmt->fetchAll();
        
        $page_title = "Portfolio Builder";
        require_once 'includes/header.php';
        ?>
        <div class="row justify-content-center">
            <div class="col-md-8 text-center py-5">
                <i class="bi bi-globe text-gradient display-1 mb-3"></i>
                <h2 class="fw-bold Outfit">AI Portfolio Generator</h2>
                <p class="text-secondary mb-4">Select a resume to transform into an online interactive personal website.</p>
                
                <?php if (count($resumes) === 0): ?>
                    <div class="alert alert-warning glass-card py-3">
                        Please create a resume first. <a href="dashboard.php" class="alert-link text-gradient fw-bold">Create Now</a>
                    </div>
                <?php else: ?>
                    <div class="list-group col-md-8 mx-auto shadow-sm rounded-3">
                        <?php foreach ($resumes as $res): ?>
                            <a href="portfolio.php?id=<?php echo $res['id']; ?>" class="list-group-item list-group-item-action bg-transparent border-secondary border-opacity-10 py-3 text-start d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="fw-bold text-gradient d-block"><?php echo htmlspecialchars($res['title']); ?></span>
                                    <small class="text-secondary"><?php echo htmlspecialchars($res['target_job_role']); ?></small>
                                </div>
                                <span class="btn btn-sm btn-gradient">Select <i class="bi bi-chevron-right small"></i></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
        require_once 'includes/footer.php';
        exit;
    } else {
        die("Unauthorized access or missing parameters.");
    }
}

// Fetch all resume information for portfolio rendering
$resumeId = $resume['id'];
$stmt = $db->prepare("SELECT * FROM education WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$education = $stmt->fetchAll();

$stmt = $db->prepare("SELECT * FROM experience WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$experience = $stmt->fetchAll();

$stmt = $db->prepare("SELECT * FROM projects WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$projects = $stmt->fetchAll();

$stmt = $db->prepare("SELECT * FROM skills WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$skills = $stmt->fetchAll();

// If not public preview, show the Builder Options Panel
if (is_logged_in() && !$isPreview && !$shareToken):
    $page_title = "Portfolio Builder - " . $resume['title'];
    require_once 'includes/header.php';
    ?>
    <div class="row align-items-center mb-4">
        <div class="col">
            <h2 class="fw-bold Outfit mb-0">AI Personal Portfolio Builder</h2>
            <p class="text-secondary mb-0">Launch an online website showcasing your qualifications, education, and projects with single-click themes.</p>
        </div>
    </div>
    
    <div class="row">
        <!-- Configuration options -->
        <div class="col-lg-5 mb-4">
            <div class="card glass-card p-4 h-100">
                <h5 class="fw-bold mb-3 text-gradient"><i class="bi bi-sliders me-2"></i>Portfolio Customization</h5>
                
                <div class="mb-4">
                    <label class="form-label fw-bold small text-secondary">Active Resume</label>
                    <div class="p-3 bg-secondary bg-opacity-10 border border-secondary border-opacity-10 rounded-3">
                        <span class="fw-bold d-block"><?php echo htmlspecialchars($resume['title']); ?></span>
                        <small class="text-secondary">Target Role: <?php echo htmlspecialchars($resume['target_job_role']); ?></small>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="form-label fw-bold small text-secondary">Website Theme Design</label>
                    <select class="form-select" id="portfolioThemeSelector">
                        <option value="cyber">Cyber Neon (Dark + Purples)</option>
                        <option value="minimal">Modern Minimalist (Light + Grey)</option>
                        <option value="corporate">Classic Professional (Navy + Blue)</option>
                    </select>
                </div>
                
                <div class="mb-4">
                    <label class="form-label fw-bold small text-secondary">Recruiter Comment Section</label>
                    <div class="p-3 bg-secondary bg-opacity-10 rounded-3">
                        <small class="text-secondary d-block mb-2">When shared, recruiters can leave ratings and comments on this portfolio.</small>
                        <span class="badge <?php echo $resume['recruiter_comments_enabled'] ? 'bg-success' : 'bg-secondary'; ?>">
                            <?php echo $resume['recruiter_comments_enabled'] ? 'Comments Enabled' : 'Comments Disabled'; ?>
                        </span>
                    </div>
                </div>
                
                <div class="d-grid gap-2">
                    <a href="portfolio.php?id=<?php echo $resumeId; ?>&preview=1&theme=cyber" target="_blank" class="btn btn-gradient py-2.5" id="btnPreviewPortfolio">
                        <i class="bi bi-eye-fill me-1"></i> Preview Portfolio Website
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Showcase Links -->
        <div class="col-lg-7 mb-4">
            <div class="card glass-card p-4 h-100">
                <h5 class="fw-bold mb-3 text-gradient"><i class="bi bi-share-fill me-2"></i>Publishing & Recruiter Links</h5>
                <p class="text-secondary small">Your personal website is active! You can copy the secure recruiter sharing link or scan the QR code to open it on mobile devices.</p>
                
                <div class="mb-4">
                    <label class="form-label fw-bold small text-secondary">Public Hosting URL</label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="portfolioUrlInput" value="<?php echo APP_URL; ?>/portfolio.php?id=<?php echo $resumeId; ?>&preview=1" readonly>
                        <button class="btn btn-outline-gradient" type="button" id="btnCopyUrl"><i class="bi bi-clipboard"></i> Copy</button>
                    </div>
                </div>
                
                <div class="text-center py-4 border border-secondary border-opacity-10 rounded bg-secondary bg-opacity-5">
                    <h6 class="fw-bold mb-3 text-secondary">Scan to View on Phone</h6>
                    <div class="d-inline-block bg-white p-2 rounded mb-2" id="portfolioQr"></div>
                    <script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
                    <script>
                        document.addEventListener("DOMContentLoaded", () => {
                            new QRCode(document.getElementById("portfolioQr"), {
                                text: document.getElementById("portfolioUrlInput").value,
                                width: 130,
                                height: 130,
                                colorDark : "#111827",
                                colorLight : "#ffffff"
                            });
                            
                            // Handle theme change preview updates
                            const selector = document.getElementById("portfolioThemeSelector");
                            const previewBtn = document.getElementById("btnPreviewPortfolio");
                            const inputUrl = document.getElementById("portfolioUrlInput");
                            
                            selector.onchange = () => {
                                const theme = selector.value;
                                const base = "<?php echo APP_URL; ?>/portfolio.php?id=<?php echo $resumeId; ?>&preview=1";
                                previewBtn.href = base + "&theme=" + theme;
                                inputUrl.value = base + "&theme=" + theme;
                            };
                            
                            // Copy helper
                            document.getElementById("btnCopyUrl").onclick = () => {
                                navigator.clipboard.writeText(inputUrl.value).then(() => {
                                    alert("Portfolio Link copied to clipboard!");
                                });
                            };
                        });
                    </script>
                </div>
            </div>
        </div>
    </div>
    <?php
    require_once 'includes/footer.php';
    exit;
else:

// =========================================================================
// PUBLIC OR PREVIEW WEBSITE RENDERING SECTION (CUSTOM PORTFOLIO THEMES)
// =========================================================================
$theme = $_GET['theme'] ?? 'cyber';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($resume['full_name']); ?> | Personal Portfolio</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@400;600;800&display=swap" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Inter', sans-serif;
            scroll-behavior: smooth;
        }
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Outfit', sans-serif;
            font-weight: 600;
        }
        
        /* 1. Cyber Theme Styling */
        <?php if ($theme === 'cyber'): ?>
        body {
            background-color: #0b0f19;
            color: #cbd5e1;
        }
        .text-accent {
            color: #a855f7;
        }
        .hero-section {
            background: linear-gradient(180deg, rgba(168, 85, 247, 0.05) 0%, rgba(11, 15, 25, 0) 100%);
            padding: 100px 0;
            min-height: 80vh;
            display: flex;
            align-items: center;
        }
        .card-custom {
            background: rgba(17, 23, 38, 0.7);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(168, 85, 247, 0.15);
            border-radius: 16px;
            color: #cbd5e1;
        }
        .nav-portfolio {
            background: rgba(11, 15, 25, 0.85);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(168, 85, 247, 0.15);
        }
        .btn-custom {
            background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
            color: white;
            border: none;
        }
        .btn-custom:hover {
            opacity: 0.9;
            color: white;
        }
        
        /* 2. Minimal Theme Styling */
        <?php elseif ($theme === 'minimal'): ?>
        body {
            background-color: #fafafa;
            color: #27272a;
        }
        .text-accent {
            color: #4b5563;
        }
        .hero-section {
            padding: 100px 0;
            min-height: 70vh;
            display: flex;
            align-items: center;
        }
        .card-custom {
            background: #ffffff;
            border: 1px solid #e4e4e7;
            border-radius: 8px;
            color: #27272a;
        }
        .nav-portfolio {
            background: rgba(250, 250, 250, 0.9);
            border-bottom: 1px solid #e4e4e7;
        }
        .btn-custom {
            background: #27272a;
            color: white;
            border: none;
            border-radius: 4px;
        }
        .btn-custom:hover {
            background: #3f3f46;
            color: white;
        }
        
        /* 3. Corporate Theme Styling */
        <?php else: ?>
        body {
            background-color: #f1f5f9;
            color: #1e293b;
        }
        .text-accent {
            color: #1d4ed8;
        }
        .hero-section {
            background: linear-gradient(135deg, #1e3a8a 0%, #0f172a 100%);
            color: white;
            padding: 120px 0;
            min-height: 60vh;
            display: flex;
            align-items: center;
        }
        .hero-section .text-accent {
            color: #38bdf8;
        }
        .card-custom {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            border-radius: 12px;
            color: #1e293b;
        }
        .nav-portfolio {
            background: #ffffff;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .btn-custom {
            background: #1e3a8a;
            color: white;
            border: none;
        }
        .btn-custom:hover {
            background: #1d4ed8;
            color: white;
        }
        <?php endif; ?>
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg nav-portfolio sticky-top py-3">
    <div class="container">
        <a class="navbar-brand fw-bold text-accent" href="#"><?php echo htmlspecialchars($resume['full_name']); ?></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#portfolioNavContent">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="portfolioNavContent">
            <ul class="navbar-nav ms-auto gap-2">
                <li class="nav-item"><a class="nav-link text-body-emphasis small" href="#about">About</a></li>
                <li class="nav-item"><a class="nav-link text-body-emphasis small" href="#experience">Experience</a></li>
                <li class="nav-item"><a class="nav-link text-body-emphasis small" href="#education">Education</a></li>
                <li class="nav-item"><a class="nav-link text-body-emphasis small" href="#projects">Projects</a></li>
                <li class="nav-item"><a class="nav-link text-body-emphasis small" href="#skills">Skills</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Hero landing -->
<header class="hero-section" id="about">
    <div class="container text-center text-lg-start">
        <div class="row align-items-center">
            <div class="col-lg-7">
                <h1 class="display-3 fw-bold mb-2">Hi, I'm <span class="text-accent"><?php echo htmlspecialchars($resume['full_name']); ?></span></h1>
                <h3 class="h2 text-secondary mb-4"><?php echo htmlspecialchars($resume['target_job_role']); ?></h3>
                <p class="lead mb-4 small opacity-85" style="max-width: 600px;"><?php echo htmlspecialchars($resume['summary']); ?></p>
                <div class="d-flex justify-content-center justify-content-lg-start gap-2.5">
                    <a href="mailto:<?php echo htmlspecialchars($resume['email']); ?>" class="btn btn-custom px-4 py-2.5">Hire Me</a>
                    <?php if ($resume['linkedin']): ?>
                        <a href="https://<?php echo htmlspecialchars($resume['linkedin']); ?>" target="_blank" class="btn btn-outline-secondary px-4 py-2.5"><i class="bi bi-linkedin"></i> LinkedIn</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-5 text-center mt-5 mt-lg-0">
                <div class="position-relative d-inline-block">
                    <!-- Large Avatar Circle visual -->
                    <div class="rounded-circle bg-secondary bg-opacity-10 d-flex align-items-center justify-content-center mx-auto" style="width: 260px; height: 260px; border: 4px solid var(--text-accent);">
                        <i class="bi bi-person-fill display-1 text-accent opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Experience timeline -->
<section class="py-5" id="experience">
    <div class="container">
        <h2 class="text-center fw-bold mb-5 border-bottom pb-3"><i class="bi bi-briefcase me-2 text-accent"></i>Experience</h2>
        <div class="row justify-content-center">
            <div class="col-md-9">
                <?php if (count($experience) === 0): ?>
                    <p class="text-center text-secondary small">No experience history registered.</p>
                <?php else: ?>
                    <?php foreach ($experience as $exp): ?>
                        <div class="card card-custom p-4 mb-4">
                            <div class="d-flex flex-wrap justify-content-between mb-2">
                                <h4 class="fw-bold mb-0 text-accent"><?php echo htmlspecialchars($exp['position'] ?? ''); ?></h4>
                                <span class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary border-opacity-10 px-3 py-1.5 rounded-pill small">
                                    <?php 
                                    $start = !empty($exp['start_date']) ? date('M Y', strtotime($exp['start_date'])) : '';
                                    $end = !empty($exp['end_date']) ? date('M Y', strtotime($exp['end_date'])) : 'Present';
                                    echo htmlspecialchars($start . ($start && $end ? ' - ' : '') . $end);
                                    ?>
                                </span>
                            </div>
                            <h6 class="text-secondary fw-semibold mb-3"><?php echo htmlspecialchars($exp['company'] ?? ''); ?> (<?php echo htmlspecialchars($exp['location'] ?? 'Remote'); ?>)</h6>
                            <p class="small mb-0 opacity-90" style="white-space: pre-wrap;"><?php echo htmlspecialchars($exp['description'] ?? ''); ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- Education timeline -->
<section class="py-5 bg-black bg-opacity-10" id="education">
    <div class="container">
        <h2 class="text-center fw-bold mb-5 border-bottom pb-3"><i class="bi bi-book me-2 text-accent"></i>Education</h2>
        <div class="row justify-content-center">
            <div class="col-md-9">
                <?php if (count($education) === 0): ?>
                    <p class="text-center text-secondary small">No education entries registered.</p>
                <?php else: ?>
                    <?php foreach ($education as $edu): ?>
                        <div class="card card-custom p-4 mb-4">
                            <div class="d-flex flex-wrap justify-content-between mb-2">
                                <h4 class="fw-bold mb-0 text-accent"><?php echo htmlspecialchars($edu['degree'] ?? ''); ?> in <?php echo htmlspecialchars($edu['field_of_study'] ?? ''); ?></h4>
                                <span class="text-muted small">
                                    <?php 
                                    $start = !empty($edu['start_date']) ? date('Y', strtotime($edu['start_date'])) : '';
                                    $end = !empty($edu['end_date']) ? date('Y', strtotime($edu['end_date'])) : 'Present';
                                    echo htmlspecialchars($start . ($start && $end ? ' - ' : '') . $end);
                                    ?>
                                </span>
                            </div>
                            <h6 class="text-secondary fw-semibold mb-0"><?php echo htmlspecialchars($edu['institution'] ?? ''); ?></h6>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- Projects grid -->
<section class="py-5" id="projects">
    <div class="container">
        <h2 class="text-center fw-bold mb-5 border-bottom pb-3"><i class="bi bi-folder-check me-2 text-accent"></i>Featured Projects</h2>
        <div class="row g-4 justify-content-center">
            <?php if (count($projects) === 0): ?>
                <p class="text-center text-secondary small">No projects highlights registered.</p>
            <?php else: ?>
                <?php foreach ($projects as $proj): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card card-custom p-4 h-100 d-flex flex-column justify-content-between">
                            <div>
                                <h4 class="fw-bold mb-2 text-accent"><?php echo htmlspecialchars($proj['title']); ?></h4>
                                <span class="badge bg-secondary bg-opacity-10 text-secondary mb-3 small">Stack: <?php echo htmlspecialchars($proj['technologies']); ?></span>
                                <p class="small opacity-85" style="white-space: pre-wrap;"><?php echo htmlspecialchars($proj['description']); ?></p>
                            </div>
                            <?php if ($proj['link']): ?>
                                <a href="<?php echo htmlspecialchars($proj['link']); ?>" target="_blank" class="btn btn-custom btn-sm w-100 mt-3 py-2"><i class="bi bi-github"></i> Source Code</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Skills badge bank -->
<section class="py-5 bg-black bg-opacity-10" id="skills">
    <div class="container">
        <h2 class="text-center fw-bold mb-5 border-bottom pb-3"><i class="bi bi-cpu me-2 text-accent"></i>Skills Inventory</h2>
        <div class="row justify-content-center">
            <div class="col-md-9 text-center">
                <?php if (count($skills) === 0): ?>
                    <p class="text-center text-secondary small">No skills registered.</p>
                <?php else: ?>
                    <div class="d-flex flex-wrap justify-content-center gap-3">
                        <?php foreach ($skills as $sk): ?>
                            <span class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary border-opacity-10 px-4 py-2.5 rounded-pill fs-6 font-heading">
                                <?php echo htmlspecialchars($sk['name']); ?>
                                <small class="text-accent fs-7 ms-1.5 fw-normal">(<?php echo htmlspecialchars($sk['level']); ?>)</small>
                            </span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- Recruiter rating modal comments system (Only if enabled) -->
<?php if ($resume['recruiter_comments_enabled'] && $shareToken): 
    // Fetch comments
    $rrStmt = $db->prepare("SELECT * FROM recruiter_reviews WHERE resume_id = ? ORDER BY created_at DESC");
    $rrStmt->execute([$resumeId]);
    $comments = $rrStmt->fetchAll();
    
    // Submit review process
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_review'])) {
        $recruiterName = trim($_POST['recruiter_name'] ?: 'Anonymous Recruiter');
        $rating = intval($_POST['rating']);
        $comment = trim($_POST['comments']);
        
        if ($rating >= 1 && $rating <= 5 && !empty($comment)) {
            $insStmt = $db->prepare("INSERT INTO recruiter_reviews (resume_id, recruiter_name, rating, comments) VALUES (?, ?, ?, ?)");
            $insStmt->execute([$resumeId, $recruiterName, $rating, $comment]);
            header("Location: portfolio.php?token=" . $shareToken . "&reviewed=1");
            exit;
        }
    }
?>
<section class="py-5 bg-dark text-white border-top border-secondary border-opacity-10">
    <div class="container">
        <h2 class="text-center fw-bold mb-4 text-accent"><i class="bi bi-shield-check me-2"></i>Recruiter Mode Review Portal</h2>
        
        <div class="row g-4 mt-2">
            <!-- Review submission form -->
            <div class="col-md-6">
                <div class="card card-custom p-4">
                    <h5 class="fw-bold mb-3">Leave a Review</h5>
                    <?php if (isset($_GET['reviewed'])): ?>
                        <div class="alert alert-success py-2 small">Thank you for rating this developer's resume! Your comment is posted.</div>
                    <?php endif; ?>
                    <form action="portfolio.php?token=<?php echo $shareToken; ?>" method="POST">
                        <input type="hidden" name="action_review" value="1">
                        <div class="mb-3">
                            <label class="form-label small">Your Name / Title</label>
                            <input type="text" class="form-control bg-dark border-secondary border-opacity-10 text-white" name="recruiter_name" placeholder="Hiring Manager at Google">
                        </div>
                        <div class="mb-3">
                            <label class="form-label small">Resume Rating</label>
                            <select class="form-select bg-dark border-secondary border-opacity-10 text-white" name="rating">
                                <option value="5">★★★★★ Outstanding (5/5)</option>
                                <option value="4">★★★★ Very Good (4/5)</option>
                                <option value="3">★★★ Acceptable (3/5)</option>
                                <option value="2">★★ Needs Work (2/5)</option>
                                <option value="1">★ Critical (1/5)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small">Constructive Feedback</label>
                            <textarea class="form-control bg-dark border-secondary border-opacity-10 text-white" name="comments" rows="3" required placeholder="Add missing keywords or review suggestions..."></textarea>
                        </div>
                        <button type="submit" class="btn btn-custom w-100">Submit Rating</button>
                    </form>
                </div>
            </div>
            
            <!-- Ratings and comment list -->
            <div class="col-md-6">
                <div class="card card-custom p-4">
                    <h5 class="fw-bold mb-3">Existing Recruiter Reviews (<?php echo count($comments); ?>)</h5>
                    <div style="max-height: 330px; overflow-y: auto;">
                        <?php if (count($comments) === 0): ?>
                            <p class="text-secondary small">No recruiter remarks yet. Be the first to evaluate!</p>
                        <?php else: ?>
                            <?php foreach ($comments as $cm): ?>
                                <div class="border-bottom border-secondary border-opacity-10 pb-3 mb-3">
                                    <div class="d-flex justify-content-between align-items-center small mb-1">
                                        <strong class="text-accent"><?php echo htmlspecialchars($cm['recruiter_name']); ?></strong>
                                        <span class="text-warning"><?php echo str_repeat('★', $cm['rating']); ?></span>
                                    </div>
                                    <p class="small text-muted mb-0"><?php echo htmlspecialchars($cm['comments']); ?></p>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<footer class="py-4 text-center border-top border-secondary border-opacity-10 mt-5 opacity-75">
    <small class="text-secondary">&copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars($resume['full_name']); ?> Portfolio. Hosted on CareerCraft AI.</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php endif; ?>
