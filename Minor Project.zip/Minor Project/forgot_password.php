<?php
// forgot_password.php - Forgot Password Page

require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

$error_msg = "";
$success_msg = "";
$step = 1; // 1: Enter email, 2: Reset password
$user_id = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action_request'])) {
        $email = trim($_POST['email'] ?? '');
        if (empty($email)) {
            $error_msg = "Please enter your email.";
        } else {
            $db = getDBConnection();
            $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user) {
                $user_id = $user['id'];
                $step = 2;
                $success_msg = "Verification successful (Local XAMPP Demo Mode). Please choose a new password.";
            } else {
                $error_msg = "No user found with that email address.";
            }
        }
    } elseif (isset($_POST['action_reset'])) {
        $user_id = $_POST['user_id'] ?? null;
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (empty($password) || empty($confirm_password)) {
            $error_msg = "Both fields are required.";
            $step = 2;
        } elseif (strlen($password) < 6) {
            $error_msg = "Password must be at least 6 characters long.";
            $step = 2;
        } elseif ($password !== $confirm_password) {
            $error_msg = "Passwords do not match.";
            $step = 2;
        } else {
            $db = getDBConnection();
            $password_hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $db->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
            if ($stmt->execute([$password_hash, $user_id])) {
                $success_msg = "Password reset successful! You can now log in.";
                $step = 3;
            } else {
                $error_msg = "Failed to update password. Try again.";
                $step = 2;
            }
        }
    }
}

$page_title = "Forgot Password";
require_once 'includes/header.php';
?>

<div class="container d-flex align-items-center justify-content-center" style="min-height: calc(100vh - 120px); padding-top: 80px;">
    <div class="row w-100 justify-content-center">
        <div class="col-md-6 col-lg-5 col-xl-4">
            <div class="card glass-card p-4 animate-fade-in">
                <div class="card-body">
                    <div class="text-center mb-4">
                        <i class="bi bi-shield-key-fill text-gradient fs-1"></i>
                        <h2 class="fw-bold mt-2">Reset Password</h2>
                        <p class="text-secondary">Recover access to your account</p>
                    </div>

                    <?php if ($error_msg): ?>
                        <div class="alert alert-danger d-flex align-items-center py-2" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i>
                            <div><?php echo htmlspecialchars($error_msg); ?></div>
                        </div>
                    <?php endif; ?>

                    <?php if ($success_msg): ?>
                        <div class="alert alert-success d-flex align-items-center py-2" role="alert">
                            <i class="bi bi-check-circle-fill me-2"></i>
                            <div><?php echo htmlspecialchars($success_msg); ?></div>
                        </div>
                    <?php endif; ?>

                    <?php if ($step === 1): ?>
                        <form action="forgot_password.php" method="POST">
                            <input type="hidden" name="action_request" value="1">
                            <div class="mb-4">
                                <label for="email" class="form-label">Email address</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-transparent border-end-0"><i class="bi bi-envelope text-secondary"></i></span>
                                    <input type="email" class="form-control border-start-0" id="email" name="email" required placeholder="john@example.com">
                                </div>
                                <div class="form-text text-secondary mt-2">
                                    <i class="bi bi-info-circle me-1"></i> Under local environment, entering a valid email redirects you directly to the password update screen.
                                </div>
                            </div>
                            <button type="submit" class="btn btn-gradient w-100 py-2 mb-3">Verify Email</button>
                        </form>
                    <?php elseif ($step === 2): ?>
                        <form action="forgot_password.php" method="POST">
                            <input type="hidden" name="action_reset" value="1">
                            <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user_id); ?>">
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">New Password</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-transparent border-end-0"><i class="bi bi-lock text-secondary"></i></span>
                                    <input type="password" class="form-control border-start-0" id="password" name="password" required placeholder="••••••••">
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="confirm_password" class="form-label">Confirm Password</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-transparent border-end-0"><i class="bi bi-shield-lock text-secondary"></i></span>
                                    <input type="password" class="form-control border-start-0" id="confirm_password" name="confirm_password" required placeholder="••••••••">
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-gradient w-100 py-2 mb-3">Update Password</button>
                        </form>
                    <?php else: ?>
                        <div class="text-center">
                            <a href="login.php" class="btn btn-gradient w-100 py-2 mb-3">Proceed to Login</a>
                        </div>
                    <?php endif; ?>

                    <div class="text-center mt-3">
                        <a href="login.php" class="text-gradient fw-bold small text-decoration-none"><i class="bi bi-arrow-left me-1"></i> Back to Login</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
