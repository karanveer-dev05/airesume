<?php
// ats_checker.php - ATS Scanner & Keyword Optimization Portal

require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Route guards
require_login();

define('SHOW_SIDEBAR', true);
$db = getDBConnection();
$userId = get_logged_in_user_id();

$resumeId = intval($_GET['id'] ?? 0);

// If no specific resume selected, show a selection menu
if ($resumeId === 0) {
    // Fetch user's resumes
    $stmt = $db->prepare("SELECT * FROM resumes WHERE user_id = ? ORDER BY updated_at DESC");
    $stmt->execute([$userId]);
    $resumes = $stmt->fetchAll();
    
    $page_title = "ATS Check";
    require_once 'includes/header.php';
    ?>
    <div class="row justify-content-center">
        <div class="col-md-8 text-center py-5">
            <i class="bi bi-patch-check text-gradient display-1 mb-3"></i>
            <h2 class="fw-bold Outfit">ATS Compatibility Scan</h2>
            <p class="text-secondary mb-4">Select which resume you would like to run through the Gemini AI ATS Scanner.</p>
            
            <?php if (count($resumes) === 0): ?>
                <div class="alert alert-warning glass-card py-3">
                    You need to create a resume first in order to scan it. <a href="dashboard.php" class="alert-link text-decoration-none text-gradient fw-bold">Create Now</a>
                </div>
            <?php else: ?>
                <div class="list-group col-md-8 mx-auto shadow-sm rounded-3 overflow-hidden">
                    <?php foreach ($resumes as $res): ?>
                        <a href="ats_checker.php?id=<?php echo $res['id']; ?>" class="list-group-item list-group-item-action bg-transparent border-secondary border-opacity-10 py-3 text-start d-flex justify-content-between align-items-center">
                            <div>
                                <span class="fw-bold text-gradient d-block"><?php echo htmlspecialchars($res['title']); ?></span>
                                <small class="text-secondary"><?php echo htmlspecialchars($res['target_job_role']); ?></small>
                            </div>
                            <span class="btn btn-sm btn-gradient">Select <i class="bi bi-chevron-right small"></i></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
    require_once 'includes/footer.php';
    exit;
}

// Verify ownership
$stmt = $db->prepare("SELECT * FROM resumes WHERE id = ? AND user_id = ?");
$stmt->execute([$resumeId, $userId]);
$resume = $stmt->fetch();

if (!$resume) {
    header("Location: ats_checker.php?error=notfound");
    exit;
}

// Fetch latest score from DB
$scoreStmt = $db->prepare("SELECT * FROM resume_scores WHERE resume_id = ? ORDER BY created_at DESC LIMIT 1");
$scoreStmt->execute([$resumeId]);
$latestScore = $scoreStmt->fetch();

$page_title = "ATS Optimizer - " . $resume['title'];
require_once 'includes/header.php';
?>

<div class="row align-items-center mb-4">
    <div class="col">
        <h2 class="fw-bold Outfit mb-0">ATS Optimize Analyzer</h2>
        <p class="text-secondary mb-0">Review ATS compatibility, grammar assessments, and trending developer keyword distributions.</p>
    </div>
    <div class="col-auto">
        <button class="btn btn-gradient py-2" id="btnRunScan">
            <i class="bi bi-arrow-repeat me-1"></i> Scan Resume with AI
        </button>
    </div>
</div>

<div class="row" id="scanResultsArea">
    <?php if (!$latestScore): ?>
        <!-- Empty State -->
        <div class="col-12 text-center py-5">
            <div class="card glass-card p-5 max-width-600 mx-auto">
                <i class="bi bi-activity text-gradient fs-1 mb-3"></i>
                <h4 class="fw-bold">No Analysis Found</h4>
                <p class="text-secondary">This resume has not been scanned yet. Click the "Scan Resume with AI" button above to evaluate spelling, grammar, and ATS keyword presence.</p>
            </div>
        </div>
    <?php else: 
        $keywords = json_decode($latestScore['keywords_analysis'], true) ?: [];
        $suggestions = explode("\n", $latestScore['suggestions']);
    ?>
        <!-- Results Column (Left) -->
        <div class="col-lg-6 mb-4">
            <div class="card glass-card p-4 h-100">
                <h5 class="fw-bold mb-4 text-gradient"><i class="bi bi-speedometer2 me-2"></i>Compatability Scores</h5>
                
                <div class="row g-4 text-center justify-content-center mb-4">
                    <div class="col-6 col-md-4">
                        <div class="score-circle mx-auto mb-2" style="--score: <?php echo $latestScore['score']; ?>;">
                            <div class="score-inner"><?php echo $latestScore['score']; ?><span class="fs-6 text-secondary">%</span></div>
                        </div>
                        <span class="small fw-semibold text-secondary">Overall Score</span>
                    </div>
                    <div class="col-6 col-md-4">
                        <div class="score-circle mx-auto mb-2" style="--score: <?php echo $latestScore['ats_score']; ?>; background: conic-gradient(#0ea5e9 calc(var(--score) * 1%), var(--bg-primary) 0)">
                            <div class="score-inner"><?php echo $latestScore['ats_score']; ?><span class="fs-6 text-secondary">%</span></div>
                        </div>
                        <span class="small fw-semibold text-secondary">ATS Index</span>
                    </div>
                    <div class="col-6 col-md-4">
                        <div class="score-circle mx-auto mb-2" style="--score: <?php echo $latestScore['grammar_score']; ?>; background: conic-gradient(#10b981 calc(var(--score) * 1%), var(--bg-primary) 0)">
                            <div class="score-inner"><?php echo $latestScore['grammar_score']; ?><span class="fs-6 text-secondary">%</span></div>
                        </div>
                        <span class="small fw-semibold text-secondary">Grammar Index</span>
                    </div>
                </div>

                <h5 class="fw-bold mb-3 mt-4 text-gradient"><i class="bi bi-lightbulb-fill me-2"></i>Actionable Improvement Checklist</h5>
                <ul class="list-group list-group-flush bg-transparent">
                    <?php foreach ($suggestions as $sug): if (trim($sug) === '') continue; ?>
                        <li class="list-group-item bg-transparent border-secondary border-opacity-10 px-0 py-2.5 small text-secondary d-flex align-items-start gap-2">
                            <span class="text-warning mt-0.5"><i class="bi bi-exclamation-circle-fill"></i></span>
                            <span><?php echo htmlspecialchars($sug); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <!-- Keyword Visualizations & Cloud (Right) -->
        <div class="col-lg-6 mb-4">
            <div class="card glass-card p-4 h-100 d-flex flex-column">
                <h5 class="fw-bold mb-2 text-gradient"><i class="bi bi-cloud-snow-fill me-2"></i>Resume Keyword Cloud</h5>
                <p class="text-secondary small mb-4">Visual distribution of essential skill frequencies on your resume. Click terms to explore.</p>
                
                <div class="flex-grow-1 border border-secondary border-opacity-10 rounded-3 p-4 d-flex align-items-center justify-content-center flex-wrap gap-3 bg-secondary bg-opacity-5" style="min-height: 250px;">
                    <?php if (count($keywords) === 0): ?>
                        <span class="text-muted small">No keywords analyzed.</span>
                    <?php else: ?>
                        <?php foreach ($keywords as $kw): 
                            // Map value size 1-10 to font sizing
                            $size = 0.8 + ($kw['value'] * 0.15); 
                            $opacity = 0.4 + ($kw['value'] * 0.06);
                        ?>
                            <span class="badge bg-secondary-subtle text-secondary px-3 py-2 rounded-pill font-heading" 
                                  style="font-size: <?php echo $size; ?>rem; opacity: <?php echo $opacity; ?>; border: 1px solid var(--card-border);">
                                <?php echo htmlspecialchars($kw['text']); ?>
                            </span>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <div class="mt-4 pt-3 border-top border-secondary border-opacity-10">
                    <h5 class="fw-bold mb-3 text-gradient"><i class="bi bi-tag-fill me-2"></i>Critical Missing Keywords</h5>
                    <div class="d-flex flex-wrap gap-2">
                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-2 rounded-pill"><i class="bi bi-x-circle me-1"></i> REST API</span>
                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-2 rounded-pill"><i class="bi bi-x-circle me-1"></i> CI/CD Pipeline</span>
                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-2 rounded-pill"><i class="bi bi-x-circle me-1"></i> Unit Testing</span>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
    const btnScan = document.getElementById("btnRunScan");
    const container = document.getElementById("scanResultsArea");
    const resumeId = <?php echo $resumeId; ?>;

    if (btnScan) {
        btnScan.addEventListener("click", async () => {
            btnScan.disabled = true;
            btnScan.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status"></span> Scanning...';
            
            container.innerHTML = `
                <div class="col-12 text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Analyzing details...</span>
                    </div>
                    <p class="text-secondary mt-3">Gemini AI is scanning your resume grammar, layout flow, and keyword coverage. Please wait...</p>
                </div>
            `;

            try {
                const response = await fetch(APP_URL + "/ai_generate.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        action: "score_resume",
                        resume_id: resumeId
                    })
                });
                
                const data = await response.json();
                
                if (data.error) {
                    container.innerHTML = `
                        <div class="col-12 text-center text-danger py-5">
                            <i class="bi bi-exclamation-triangle fs-1"></i>
                            <p class="mt-3">Scan Failed: ${data.error}</p>
                            <button class="btn btn-outline-secondary mt-2" onclick="location.reload();">Retry</button>
                        </div>
                    `;
                } else {
                    // Reload page to show DB stored updates cleanly
                    location.reload();
                }
            } catch (err) {
                container.innerHTML = `
                    <div class="col-12 text-center text-danger py-5">
                        <i class="bi bi-exclamation-triangle fs-1"></i>
                        <p class="mt-3">Network error occurred during scanner processing.</p>
                        <button class="btn btn-outline-secondary mt-2" onclick="location.reload();">Retry</button>
                    </div>
                `;
            } finally {
                btnScan.disabled = false;
                btnScan.innerHTML = '<i class="bi bi-arrow-repeat me-1"></i> Scan Resume with AI';
            }
        });
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
