s<?php
// index.php - Main Landing Page

require_once 'includes/config.php';
require_once 'includes/auth.php';

$page_title = "Craft Your Career with AI";
require_once 'includes/header.php';
?>

<!-- Hero Section -->
<div class="container py-5" style="padding-top: 100px !important;">
    <div class="row align-items-center min-vh-75 py-5">
        <div class="col-lg-6 mb-5 mb-lg-0 animate-fade-in">
            <span class="badge bg-purple-gradient text-white px-3 py-2 rounded-pill mb-3" style="background: var(--primary-gradient);">NEXT GENERATION AI BUILDER</span>
            <h1 class="display-3 fw-extrabold mb-3 lh-sm Outfit">
                Craft Your Perfect <span class="text-gradient">ATS-Proof</span> Resume with AI
            </h1>
            <p class="lead text-secondary mb-4 fs-5">
                Go beyond simple forms. Leverage the power of Gemini AI to rewrite your experience, test ATS scores, generate cover letters, and prepare for interviews based on your specific job role.
            </p>
            <div class="d-flex flex-wrap gap-3">
                <?php if (is_logged_in()): ?>
                    <a href="dashboard.php" class="btn btn-gradient btn-lg px-4 py-3">
                        Go to Dashboard <i class="bi bi-arrow-right-short ms-1"></i>
                    </a>
                <?php else: ?>
                    <a href="register.php" class="btn btn-gradient btn-lg px-4 py-3">
                        Build Resume Now <i class="bi bi-rocket-takeoff ms-1"></i>
                    </a>
                    <a href="login.php" class="btn btn-outline-gradient btn-lg px-4 py-3">
                        Sign In
                    </a>
                <?php endif; ?>
            </div>
            
            <div class="d-flex gap-4 mt-5 text-secondary">
                <div>
                    <h4 class="fw-bold text-gradient mb-0">100%</h4>
                    <span class="small">ATS Compliant</span>
                </div>
                <div class="border-start ps-4">
                    <h4 class="fw-bold text-gradient mb-0">Gemini 1.5</h4>
                    <span class="small">AI Intelligence</span>
                </div>
                <div class="border-start ps-4">
                    <h4 class="fw-bold text-gradient mb-0">7+</h4>
                    <span class="small">Premium Templates</span>
                </div>
            </div>
        </div>
        
        <div class="col-lg-6 text-center animate-fade-in" style="animation-delay: 0.2s;">
            <div class="position-relative d-inline-block">
                <!-- Decorative backgrounds -->
                <div class="position-absolute top-50 start-50 translate-middle rounded-circle bg-purple-gradient opacity-10" style="width: 400px; height: 400px; background: var(--primary-gradient); filter: blur(50px); z-index: -1;"></div>
                
                <!-- Main Glass Card Preview -->
                <div class="card glass-card p-4 mx-auto" style="max-width: 450px; border-radius: 24px;">
                    <div class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3" style="border-color: var(--card-border) !important;">
                        <div class="d-flex align-items-center gap-2">
                            <span class="p-2 bg-success bg-opacity-10 rounded-circle text-success"><i class="bi bi-shield-check"></i></span>
                            <span class="fw-bold">ATS Score Check</span>
                        </div>
                        <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1 rounded">Optimal</span>
                    </div>
                    
                    <div class="text-center my-4 d-flex flex-column align-items-center">
                        <!-- Score Display -->
                        <div class="score-circle mb-3" style="--score: 88; width: 140px; height: 140px;">
                            <div class="score-inner fs-1">88<span class="fs-6 text-secondary">/100</span></div>
                        </div>
                        <h4 class="fw-bold">ATS Keyword Match: High</h4>
                        <p class="text-secondary small px-3">We analyzed your resume details against target 'Web Developer' positions. AI recommends adding 3 skills.</p>
                    </div>
                    
                    <div class="d-flex gap-2 justify-content-center flex-wrap pt-2">
                        <span class="badge bg-secondary-subtle text-secondary px-3 py-2 rounded-pill"><i class="bi bi-check-circle-fill text-gradient me-1"></i> PHP PDO</span>
                        <span class="badge bg-secondary-subtle text-secondary px-3 py-2 rounded-pill"><i class="bi bi-check-circle-fill text-gradient me-1"></i> Bootstrap 5</span>
                        <span class="badge bg-secondary-subtle text-secondary px-3 py-2 rounded-pill"><i class="bi bi-plus-circle-fill text-warning me-1"></i> Git API</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Features Section -->
<div class="py-5" style="background-color: var(--bg-secondary); border-top: 1px solid var(--card-border); border-bottom: 1px solid var(--card-border);">
    <div class="container py-5">
        <div class="text-center mb-5">
            <h2 class="display-5 fw-bold Outfit">AI Capabilities & <span class="text-gradient">Unique Features</span></h2>
            <p class="text-secondary col-md-6 mx-auto">Discover the power of CareerCraft. AI-driven intelligence at every stage of your job hunt.</p>
        </div>
        
        <div class="row g-4">
            <!-- Feature 1: AI Scoring -->
            <div class="col-md-4">
                <div class="card glass-card h-100 p-4">
                    <div class="fs-1 text-primary mb-3"><i class="bi bi-lightning-charge-fill text-gradient"></i></div>
                    <h4 class="fw-bold mb-2">AI Resume Scoring</h4>
                    <p class="text-secondary small mb-0">Evaluate your formatting, grammar, and structural components instantly. Receive actionable insights based on target jobs.</p>
                </div>
            </div>
            <!-- Feature 2: ATS keyword matcher -->
            <div class="col-md-4">
                <div class="card glass-card h-100 p-4">
                    <div class="fs-1 text-primary mb-3"><i class="bi bi-patch-check-fill text-gradient"></i></div>
                    <h4 class="fw-bold mb-2">ATS Checker & Keywords</h4>
                    <p class="text-secondary small mb-0">Checks ATS scanner compatibility. We highlight missing technologies and soft skills recruiters search for.</p>
                </div>
            </div>
            <!-- Feature 3: Job Customizer -->
            <div class="col-md-4">
                <div class="card glass-card h-100 p-4">
                    <div class="fs-1 text-primary mb-3"><i class="bi bi-gear-fill text-gradient"></i></div>
                    <h4 class="fw-bold mb-2">Role Customizer</h4>
                    <p class="text-secondary small mb-0">Switch job categories dynamically. The system alters summaries, skills, and highlights specifically for selected roles.</p>
                </div>
            </div>
            <!-- Feature 4: Interview Prep -->
            <div class="col-md-4">
                <div class="card glass-card h-100 p-4">
                    <div class="fs-1 text-primary mb-3"><i class="bi bi-chat-left-dots-fill text-gradient"></i></div>
                    <h4 class="fw-bold mb-2">AI Interview Generator</h4>
                    <p class="text-secondary small mb-0">Get 20 tailored interview questions classified into Difficulty Levels (Easy, Medium, Advanced) extracted from your resume.</p>
                </div>
            </div>
            <!-- Feature 5: Cover Letter -->
            <div class="col-md-4">
                <div class="card glass-card h-100 p-4">
                    <div class="fs-1 text-primary mb-3"><i class="bi bi-file-earmark-text-fill text-gradient"></i></div>
                    <h4 class="fw-bold mb-2">Cover Letter Creator</h4>
                    <p class="text-secondary small mb-0">Generate polished, custom cover letters specifically targeted to any firm and position with single-click actions.</p>
                </div>
            </div>
            <!-- Feature 6: Web Portfolio -->
            <div class="col-md-4">
                <div class="card glass-card h-100 p-4">
                    <div class="fs-1 text-primary mb-3"><i class="bi bi-globe2 text-gradient"></i></div>
                    <h4 class="fw-bold mb-2">AI Portfolio Generator</h4>
                    <p class="text-secondary small mb-0">Instantly launch your responsive personal website containing profile info, projects, and custom styling themes.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
