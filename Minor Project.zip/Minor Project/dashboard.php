<?php
// dashboard.php - Main User Dashboard Panel

require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Route guards
require_login();

define('SHOW_SIDEBAR', true);
$db = getDBConnection();
$userId = get_logged_in_user_id();

$error_msg = "";
$success_msg = "";

// 1. Handle New Resume Creation Request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_create'])) {
    $title = trim($_POST['title'] ?? 'My Resume');
    $role = $_POST['job_role'] ?? 'Software Engineer';
    
    if (empty($title)) {
        $error_msg = "Please enter a resume title.";
    } else {
        // Create token for sharing
        $shareToken = bin2hex(random_bytes(16));
        
        $stmt = $db->prepare("INSERT INTO resumes (user_id, title, target_job_role, share_token) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$userId, $title, $role, $shareToken])) {
            $newId = $db->lastInsertId();
            
            // Seed a starter summary based on role for smoother user flow
            $starterSummary = "Passionate and detail-oriented " . $role . " looking to contribute technical expertise and solve complex challenges in a fast-paced development team.";
            $db->prepare("UPDATE resumes SET summary = ? WHERE id = ?")->execute([$starterSummary, $newId]);
            
            header("Location: resume.php?id=" . $newId);
            exit;
        } else {
            $error_msg = "Failed to create resume. Please try again.";
        }
    }
}

// 2. Handle Resume Deletion
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $resumeId = intval($_GET['id']);
    
    // Verify ownership
    $stmt = $db->prepare("DELETE FROM resumes WHERE id = ? AND user_id = ?");
    if ($stmt->execute([$resumeId, $userId])) {
        $success_msg = "Resume deleted successfully.";
    } else {
        $error_msg = "Failed to delete resume.";
    }
}

// 3. Fetch User's Resumes
$stmt = $db->prepare("SELECT * FROM resumes WHERE user_id = ? ORDER BY updated_at DESC");
$stmt->execute([$userId]);
$resumes = $stmt->fetchAll();

// 4. Calculate Profile Completeness for each Resume
function calculateCompleteness($db, $resume) {
    $score = 0;
    
    // Personal details (20% total)
    if (!empty($resume['full_name'])) $score += 5;
    if (!empty($resume['email'])) $score += 5;
    if (!empty($resume['phone'])) $score += 5;
    if (!empty($resume['address'])) $score += 5;
    
    // Professional Summary (15%)
    if (!empty($resume['summary'])) $score += 15;
    
    // Education (15%)
    $stmt = $db->prepare("SELECT COUNT(*) FROM education WHERE resume_id = ?");
    $stmt->execute([$resume['id']]);
    if ($stmt->fetchColumn() > 0) $score += 15;
    
    // Experience (20%)
    $stmt = $db->prepare("SELECT COUNT(*) FROM experience WHERE resume_id = ?");
    $stmt->execute([$resume['id']]);
    if ($stmt->fetchColumn() > 0) $score += 20;

    // Projects (20%)
    $stmt = $db->prepare("SELECT COUNT(*) FROM projects WHERE resume_id = ?");
    $stmt->execute([$resume['id']]);
    if ($stmt->fetchColumn() > 0) $score += 20;

    // Skills (10%)
    $stmt = $db->prepare("SELECT COUNT(*) FROM skills WHERE resume_id = ?");
    $stmt->execute([$resume['id']]);
    if ($stmt->fetchColumn() > 0) $score += 10;
    
    return $score;
}

// 5. Fetch overall stats for visual charts
$totalResumes = count($resumes);
$mostSelectedRole = 'N/A';
$averageScore = 0;

if ($totalResumes > 0) {
    // Average score
    $resumeIds = array_column($resumes, 'id');
    $placeholders = implode(',', array_fill(0, count($resumeIds), '?'));
    $stmt = $db->prepare("SELECT AVG(score) FROM resume_scores WHERE resume_id IN ($placeholders)");
    $stmt->execute($resumeIds);
    $averageScore = round($stmt->fetchColumn() ?: 0);
    
    // Most popular target role
    $stmt = $db->prepare("SELECT target_job_role, COUNT(*) as count FROM resumes WHERE user_id = ? GROUP BY target_job_role ORDER BY count DESC LIMIT 1");
    $stmt->execute([$userId]);
    $roleRow = $stmt->fetch();
    if ($roleRow) $mostSelectedRole = $roleRow['target_job_role'];
}

$page_title = "Dashboard";
require_once 'includes/header.php';
?>

<div class="row align-items-center mb-4">
    <div class="col">
        <h2 class="fw-bold Outfit mb-0">Welcome back, <span class="text-gradient"><?php echo htmlspecialchars(get_logged_in_username()); ?></span>!</h2>
        <p class="text-secondary mb-0">Review your generated resumes, stats, and personalized career suggestions.</p>
    </div>
    <div class="col-auto">
        <button class="btn btn-gradient py-2" data-bs-toggle="modal" data-bs-target="#createResumeModal">
            <i class="bi bi-plus-lg me-1"></i> Create Resume
        </button>
    </div>
</div>

<!-- Alerts -->
<?php if ($success_msg): ?>
    <div class="alert alert-success alert-dismissible fade show glass-card py-3" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i>
        <span><?php echo htmlspecialchars($success_msg); ?></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if ($error_msg): ?>
    <div class="alert alert-danger alert-dismissible fade show glass-card py-3" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i>
        <span><?php echo htmlspecialchars($error_msg); ?></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<!-- System Statistics Banner Cards -->
<div class="row g-4 mb-5">
    <div class="col-md-4">
        <div class="card glass-card p-4">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="text-secondary text-uppercase fw-bold small">Total Resumes</h6>
                    <h3 class="fw-bold mb-0 text-gradient"><?php echo $totalResumes; ?></h3>
                </div>
                <div class="fs-1 text-primary"><i class="bi bi-file-earmark-person-fill"></i></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card glass-card p-4">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="text-secondary text-uppercase fw-bold small">Avg ATS Score</h6>
                    <h3 class="fw-bold mb-0 text-gradient"><?php echo $averageScore; ?>%</h3>
                </div>
                <div class="fs-1 text-success"><i class="bi bi-patch-check-fill"></i></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card glass-card p-4">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="text-secondary text-uppercase fw-bold small">Favorite Domain</h6>
                    <h3 class="fw-bold mb-0 text-gradient fs-5 mt-1"><?php echo htmlspecialchars($mostSelectedRole); ?></h3>
                </div>
                <div class="fs-1 text-warning"><i class="bi bi-award-fill"></i></div>
            </div>
        </div>
    </div>
</div>

<!-- Saved Resumes Panel -->
<div class="card glass-card mb-5">
    <div class="card-header bg-transparent border-0 pt-4 px-4 d-flex justify-content-between align-items-center">
        <h4 class="fw-bold mb-0"><i class="bi bi-file-earmark-text text-primary me-2"></i>Your Resumes</h4>
        <span class="badge bg-secondary-subtle text-secondary px-3 py-2 rounded-pill"><?php echo $totalResumes; ?> Saved</span>
    </div>
    
    <div class="card-body p-4">
        <?php if ($totalResumes === 0): ?>
            <div class="text-center py-5">
                <i class="bi bi-folder-x fs-1 text-secondary mb-3 d-block"></i>
                <h5 class="fw-bold">No resumes created yet</h5>
                <p class="text-secondary">Click the "Create Resume" button above to design your first AI resume.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr class="text-secondary">
                            <th>Resume Name</th>
                            <th>Target Role</th>
                            <th>Profile Details</th>
                            <th>ATS Score</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($resumes as $resume): 
                            $completeness = calculateCompleteness($db, $resume);
                            
                            // Fetch latest score
                            $scoreStmt = $db->prepare("SELECT score FROM resume_scores WHERE resume_id = ? ORDER BY created_at DESC LIMIT 1");
                            $scoreStmt->execute([$resume['id']]);
                            $scoreVal = $scoreStmt->fetchColumn() ?: 'N/A';
                        ?>
                            <tr>
                                <td>
                                    <div class="fw-bold"><?php echo htmlspecialchars($resume['title']); ?></div>
                                    <small class="text-muted">Updated: <?php echo date('M d, Y', strtotime($resume['updated_at'])); ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-purple-gradient text-white px-2.5 py-1.5 rounded" style="background: var(--primary-gradient);">
                                        <?php echo htmlspecialchars($resume['target_job_role']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="progress flex-grow-1" style="height: 6px; min-width: 80px;">
                                            <div class="progress-bar bg-gradient-primary" role="progressbar" style="width: <?php echo $completeness; ?>%"></div>
                                        </div>
                                        <small class="fw-bold"><?php echo $completeness; ?>%</small>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($scoreVal === 'N/A'): ?>
                                        <span class="text-muted"><i class="bi bi-question-circle me-1"></i>Not Rated</span>
                                    <?php else: ?>
                                        <span class="fw-bold text-success"><i class="bi bi-patch-check-fill me-1"></i><?php echo $scoreVal; ?>/100</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                            Manage
                                        </button>
                                        <ul class="dropdown-menu glass-card">
                                            <li>
                                                <a class="dropdown-item" href="resume.php?id=<?php echo $resume['id']; ?>">
                                                    <i class="bi bi-pencil-square me-2"></i>Edit Resume
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="ats_checker.php?id=<?php echo $resume['id']; ?>">
                                                    <i class="bi bi-patch-check me-2"></i>ATS Optimization
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="cover_letter.php?id=<?php echo $resume['id']; ?>">
                                                    <i class="bi bi-envelope-paper me-2"></i>Cover Letter
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="interview.php?id=<?php echo $resume['id']; ?>">
                                                    <i class="bi bi-chat-text me-2"></i>Interview Prep
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="portfolio.php?id=<?php echo $resume['id']; ?>">
                                                    <i class="bi bi-globe me-2"></i>Portfolio Web
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="share.php?token=<?php echo $resume['share_token']; ?>" target="_blank">
                                                    <i class="bi bi-share me-2"></i>Share Link
                                                </a>
                                            </li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <a class="dropdown-item text-danger" href="dashboard.php?action=delete&id=<?php echo $resume['id']; ?>" onclick="return confirm('Are you sure you want to delete this resume?');">
                                                    <i class="bi bi-trash me-2"></i>Delete
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- AI Career Roadmap Widget -->
<?php if ($totalResumes > 0): 
    // Fetch the most updated resume and its suggestions or score details
    $activeResume = $resumes[0];
?>
<div class="card glass-card p-4">
    <h4 class="fw-bold mb-3"><i class="bi bi-compass text-gradient me-2"></i>AI Smart Career Advisor</h4>
    <p class="text-secondary small">Based on your latest active resume targeted at <strong><?php echo htmlspecialchars($activeResume['target_job_role']); ?></strong>, we suggest the following tailored career roadmap.</p>
    
    <div class="row align-items-stretch mt-4 g-4" id="careerSuggestionsContainer">
        <!-- Load dynamic suggestions via AJAX or show a beautiful Loading Card -->
        <div class="col-12 text-center py-4" id="careerLoader">
            <button class="btn btn-outline-gradient" id="btnLoadSuggestions">
                <i class="bi bi-magic me-1"></i> Generate AI Career Suggestions & Salary Estimate
            </button>
        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
    const btnLoad = document.getElementById("btnLoadSuggestions");
    const container = document.getElementById("careerSuggestionsContainer");
    const resumeId = <?php echo $activeResume['id']; ?>;

    if (btnLoad) {
        btnLoad.addEventListener("click", async () => {
            container.innerHTML = `
                <div class="col-12 text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Analyzing career path...</span>
                    </div>
                    <p class="text-secondary mt-2">Gemini AI is examining your skills and experience to find jobs and roadmaps...</p>
                </div>
            `;
            
            try {
                // Fetch using our standard AI wrapper
                const response = await fetch(APP_URL + "/ai_generate.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        action: "chatbot_message",
                        message: "Based on my resume target role of '<?php echo $activeResume['target_job_role']; ?>', generate a career recommendation. Output a strict JSON structure containing keys: 'roles' (array of objects with title, salary, match), 'missing_skills' (array), 'roadmap' (array of steps), 'technologies' (array). Do not include markdown code fences."
                    })
                });
                const data = await response.json();
                
                let parsed;
                try {
                    const cleanRes = data.result.replace(/```(json)?/g, '').trim();
                    parsed = JSON.parse(cleanRes);
                } catch(e) {
                    // Fallback to mock format if JSON parse failed
                    parsed = {
                        roles: [
                            {title: "Junior <?php echo $activeResume['target_job_role']; ?>", salary: "$70,000 - $90,000", match: "95%"},
                            {title: "Senior <?php echo $activeResume['target_job_role']; ?>", salary: "$110,000 - $140,000", match: "80%"}
                        ],
                        missing_skills: ["System Architecture", "Docker", "RESTful API Integration"],
                        roadmap: ["Master advanced components in MVC databases.", "Participate in agile team environments.", "Build personal projects with complex databases."],
                        technologies: ["Node.js", "Docker", "Kubernetes", "Next.js"]
                    };
                }

                renderCareerSuggestions(parsed);
            } catch (err) {
                container.innerHTML = `
                    <div class="col-12 text-center text-danger py-4">
                        <i class="bi bi-exclamation-triangle fs-2"></i>
                        <p class="mt-2">Failed to retrieve suggestions from Gemini API. Verify your API Key.</p>
                    </div>
                `;
            }
        });
    }

    function renderCareerSuggestions(data) {
        let rolesHtml = data.roles.map(r => `
            <div class="d-flex justify-content-between align-items-center mb-2.5 pb-2 border-bottom border-secondary border-opacity-10">
                <div>
                    <div class="fw-bold">${r.title}</div>
                    <small class="text-secondary">Avg Salary: ${r.salary}</small>
                </div>
                <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-20 px-2 py-1 rounded">${r.match} Match</span>
            </div>
        `).join('');

        let skillsHtml = data.missing_skills.map(s => `
            <span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-20 px-3 py-2 rounded-pill me-1.5 mb-2">${s}</span>
        `).join('');

        let roadmapHtml = data.roadmap.map(step => `
            <div class="d-flex gap-3 align-items-start mb-3">
                <span class="p-1 px-2 bg-primary bg-opacity-10 text-primary rounded fw-bold text-gradient small"><i class="bi bi-check-lg"></i></span>
                <span class="text-secondary small mt-0.5">${step}</span>
            </div>
        `).join('');

        container.innerHTML = `
            <div class="col-md-4">
                <div class="card bg-transparent border border-secondary border-opacity-10 p-3.5 h-100 rounded-3">
                    <h5 class="fw-bold mb-3 text-gradient"><i class="bi bi-briefcase me-2"></i>Best Matching Roles</h5>
                    ${rolesHtml}
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-transparent border border-secondary border-opacity-10 p-3.5 h-100 rounded-3">
                    <h5 class="fw-bold mb-3 text-gradient"><i class="bi bi-exclamation-circle me-2"></i>Missing Skills</h5>
                    <div class="d-flex flex-wrap pt-1">${skillsHtml}</div>
                    <h5 class="fw-bold mb-2.5 mt-3 text-gradient"><i class="bi bi-cpu me-2"></i>Trending Tech</h5>
                    <div class="d-flex flex-wrap">
                        ${data.technologies.map(t => `<span class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary border-opacity-20 px-2.5 py-1.5 rounded me-1.5 mb-1.5 small">${t}</span>`).join('')}
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-transparent border border-secondary border-opacity-10 p-3.5 h-100 rounded-3">
                    <h5 class="fw-bold mb-3 text-gradient"><i class="bi bi-signpost-split me-2"></i>Learning Roadmap</h5>
                    <div class="pt-1">${roadmapHtml}</div>
                </div>
            </div>
        `;
    }
});
</script>
<?php endif; ?>

<!-- Create Resume Modal -->
<div class="modal fade" id="createResumeModal" tabindex="-1" aria-labelledby="createResumeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content glass-card border border-secondary border-opacity-25" style="border-radius: 20px;">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold text-gradient" id="createResumeModalLabel">New AI Resume</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="dashboard.php" method="POST">
                <input type="hidden" name="action_create" value="1">
                <div class="modal-body py-4">
                    <div class="mb-3">
                        <label for="title" class="form-label fw-semibold">Resume Name / Identifier</label>
                        <input type="text" class="form-control" id="title" name="title" required placeholder="e.g. Software Engineer Resume 2026">
                    </div>
                    <div class="mb-1">
                        <label for="job_role" class="form-label fw-semibold">Target Job Role</label>
                        <select class="form-select" id="job_role" name="job_role">
                            <?php foreach ($job_roles as $role): ?>
                                <option value="<?php echo htmlspecialchars($role); ?>"><?php echo htmlspecialchars($role); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-gradient px-4">Create & Customize</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
