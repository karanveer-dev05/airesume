<?php
// resume.php - Multi-Step Interactive Resume Builder Wizard

require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Route guards
require_login();

define('SHOW_SIDEBAR', true);
$db = getDBConnection();
$userId = get_logged_in_user_id();

$resumeId = intval($_GET['id'] ?? 0);

// Verify ownership
$stmt = $db->prepare("SELECT * FROM resumes WHERE id = ? AND user_id = ?");
$stmt->execute([$resumeId, $userId]);
$resume = $stmt->fetch();

if (!$resume) {
    header("Location: dashboard.php?error=notfound");
    exit;
}

$success_msg = "";
$error_msg = "";

// 1. Handle Version Restore
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_restore'])) {
    $versionId = intval($_POST['version_id']);
    
    // Fetch version data
    $vStmt = $db->prepare("SELECT version_data FROM resume_versions WHERE id = ? AND resume_id = ?");
    $vStmt->execute([$versionId, $resumeId]);
    $versionJson = $vStmt->fetchColumn();
    
    if ($versionJson) {
        $data = json_decode($versionJson, true);
        
        try {
            $db->beginTransaction();
            
            // Restore main resume fields
            $stmt = $db->prepare("UPDATE resumes SET title = ?, template_style = ?, target_job_role = ?, full_name = ?, email = ?, phone = ?, linkedin = ?, github = ?, portfolio = ?, address = ?, summary = ?, hobbies = ?, strengths = ?, signature_data = ?, recruiter_comments_enabled = ? WHERE id = ?");
            $stmt->execute([
                $data['title'], $data['template_style'], $data['target_job_role'],
                $data['full_name'], $data['email'], $data['phone'], $data['linkedin'],
                $data['github'], $data['portfolio'], $data['address'], $data['summary'],
                $data['hobbies'], $data['strengths'] ?? '', $data['signature_data'] ?? '',
                $data['recruiter_comments_enabled'], $resumeId
            ]);
            
            // Delete existing relational items
            $db->prepare("DELETE FROM education WHERE resume_id = ?")->execute([$resumeId]);
            $db->prepare("DELETE FROM experience WHERE resume_id = ?")->execute([$resumeId]);
            $db->prepare("DELETE FROM projects WHERE resume_id = ?")->execute([$resumeId]);
            $db->prepare("DELETE FROM skills WHERE resume_id = ?")->execute([$resumeId]);
            $db->prepare("DELETE FROM certificates WHERE resume_id = ?")->execute([$resumeId]);
            $db->prepare("DELETE FROM achievements WHERE resume_id = ?")->execute([$resumeId]);
            
            // Restore education
            if (!empty($data['education'])) {
                $ins = $db->prepare("INSERT INTO education (resume_id, institution, degree, field_of_study, start_date, end_date, description) VALUES (?, ?, ?, ?, ?, ?, ?)");
                foreach ($data['education'] as $edu) {
                    $ins->execute([$resumeId, $edu['institution'], $edu['degree'], $edu['field_of_study'], $edu['start_date'] ?: null, $edu['end_date'] ?: null, $edu['description']]);
                }
            }
            
            // Restore experience
            if (!empty($data['experience'])) {
                $ins = $db->prepare("INSERT INTO experience (resume_id, company, position, start_date, end_date, description, location) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                foreach ($data['experience'] as $exp) {
                    $ins->execute([$resumeId, $exp['company'], $exp['position'], $exp['start_date'] ?: null, $exp['end_date'] ?: null, $exp['description'], $exp['location']]);
                }
            }
            
            // Restore projects
            if (!empty($data['projects'])) {
                $ins = $db->prepare("INSERT INTO projects (resume_id, title, technologies, description, link) VALUES (?, ?, ?, ?, ?)");
                foreach ($data['projects'] as $proj) {
                    $ins->execute([$resumeId, $proj['title'], $proj['technologies'], $proj['description'], $proj['link']]);
                }
            }

            // Restore skills
            if (!empty($data['skills'])) {
                $ins = $db->prepare("INSERT INTO skills (resume_id, name, skill_type, level) VALUES (?, ?, ?, ?)");
                foreach ($data['skills'] as $skill) {
                    $ins->execute([$resumeId, $skill['name'], $skill['skill_type'], $skill['level']]);
                }
            }

            // Restore certificates
            if (!empty($data['certificates'])) {
                $ins = $db->prepare("INSERT INTO certificates (resume_id, name, issuer, issue_date, link) VALUES (?, ?, ?, ?, ?)");
                foreach ($data['certificates'] as $cert) {
                    $ins->execute([$resumeId, $cert['name'], $cert['issuer'], $cert['issue_date'] ?: null, $cert['link']]);
                }
            }

            // Restore achievements
            if (!empty($data['achievements'])) {
                $ins = $db->prepare("INSERT INTO achievements (resume_id, title, description, date) VALUES (?, ?, ?, ?)");
                foreach ($data['achievements'] as $ach) {
                    $ins->execute([$resumeId, $ach['title'], $ach['description'], $ach['date'] ?: null]);
                }
            }
            
            $db->commit();
            $success_msg = "Successfully restored resume backup version.";
            
            // Reload updated resume data
            $stmt = $db->prepare("SELECT * FROM resumes WHERE id = ?");
            $stmt->execute([$resumeId]);
            $resume = $stmt->fetch();
            
        } catch (Exception $e) {
            $db->rollBack();
            $error_msg = "Restore failed: " . $e->getMessage();
        }
    }
}

// 2. Handle Save Changes
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_save'])) {
    try {
        $db->beginTransaction();
        
        // Update basic info
        $stmt = $db->prepare("UPDATE resumes SET title = ?, template_style = ?, target_job_role = ?, full_name = ?, email = ?, phone = ?, linkedin = ?, github = ?, portfolio = ?, address = ?, summary = ?, hobbies = ?, strengths = ?, signature_data = ?, recruiter_comments_enabled = ? WHERE id = ?");
        $stmt->execute([
            trim($_POST['title'] ?? 'My Resume'),
            $_POST['template_style'] ?? 'modern',
            $_POST['target_job_role'] ?? 'Software Engineer',
            trim($_POST['full_name'] ?? ''),
            trim($_POST['email'] ?? ''),
            trim($_POST['phone'] ?? ''),
            trim($_POST['linkedin'] ?? ''),
            trim($_POST['github'] ?? ''),
            trim($_POST['portfolio'] ?? ''),
            trim($_POST['address'] ?? ''),
            trim($_POST['summary'] ?? ''),
            trim($_POST['hobbies'] ?? ''),
            trim($_POST['strengths'] ?? ''),
            trim($_POST['signature_data'] ?? ''),
            isset($_POST['recruiter_comments_enabled']) ? 1 : 0,
            $resumeId
        ]);
        
        // Clear child entries
        $db->prepare("DELETE FROM education WHERE resume_id = ?")->execute([$resumeId]);
        $db->prepare("DELETE FROM experience WHERE resume_id = ?")->execute([$resumeId]);
        $db->prepare("DELETE FROM projects WHERE resume_id = ?")->execute([$resumeId]);
        $db->prepare("DELETE FROM skills WHERE resume_id = ?")->execute([$resumeId]);
        $db->prepare("DELETE FROM certificates WHERE resume_id = ?")->execute([$resumeId]);
        $db->prepare("DELETE FROM achievements WHERE resume_id = ?")->execute([$resumeId]);
        
        // Insert Education
        if (!empty($_POST['edu_institution'])) {
            $ins = $db->prepare("INSERT INTO education (resume_id, institution, degree, field_of_study, start_date, end_date, description) VALUES (?, ?, ?, ?, ?, ?, ?)");
            for ($i = 0; $i < count($_POST['edu_institution']); $i++) {
                if (isset($_POST['edu_institution'][$i]) && trim($_POST['edu_institution'][$i]) !== '') {
                    $ins->execute([
                        $resumeId,
                        trim($_POST['edu_institution'][$i]),
                        trim($_POST['edu_degree'][$i] ?? ''),
                        trim($_POST['edu_field'][$i] ?? ''),
                        (!empty($_POST['edu_start'][$i]) ? $_POST['edu_start'][$i] : null),
                        (!empty($_POST['edu_end'][$i]) ? $_POST['edu_end'][$i] : null),
                        trim($_POST['edu_desc'][$i] ?? '')
                    ]);
                }
            }
        }
        
        // Insert Experience
        if (!empty($_POST['exp_company'])) {
            $ins = $db->prepare("INSERT INTO experience (resume_id, company, position, start_date, end_date, description, location) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            for ($i = 0; $i < count($_POST['exp_company']); $i++) {
                if (isset($_POST['exp_company'][$i]) && trim($_POST['exp_company'][$i]) !== '') {
                    $ins->execute([
                        $resumeId,
                        trim($_POST['exp_company'][$i]),
                        trim($_POST['exp_position'][$i] ?? ''),
                        (!empty($_POST['exp_start'][$i]) ? $_POST['exp_start'][$i] : null),
                        (!empty($_POST['exp_end'][$i]) ? $_POST['exp_end'][$i] : null),
                        trim($_POST['exp_desc'][$i] ?? ''),
                        trim($_POST['exp_location'][$i] ?? '')
                    ]);
                }
            }
        }

        // Insert Projects
        if (!empty($_POST['proj_title'])) {
            $ins = $db->prepare("INSERT INTO projects (resume_id, title, technologies, description, link) VALUES (?, ?, ?, ?, ?)");
            for ($i = 0; $i < count($_POST['proj_title']); $i++) {
                if (isset($_POST['proj_title'][$i]) && trim($_POST['proj_title'][$i]) !== '') {
                    $ins->execute([
                        $resumeId,
                        trim($_POST['proj_title'][$i]),
                        trim($_POST['proj_tech'][$i] ?? ''),
                        trim($_POST['proj_desc'][$i] ?? ''),
                        trim($_POST['proj_link'][$i] ?? '')
                    ]);
                }
            }
        }

        // Insert Skills
        if (!empty($_POST['skill_name'])) {
            $ins = $db->prepare("INSERT INTO skills (resume_id, name, skill_type, level) VALUES (?, ?, ?, ?)");
            for ($i = 0; $i < count($_POST['skill_name']); $i++) {
                if (isset($_POST['skill_name'][$i]) && trim($_POST['skill_name'][$i]) !== '') {
                    $ins->execute([
                        $resumeId,
                        trim($_POST['skill_name'][$i]),
                        $_POST['skill_type'][$i] ?? 'technical',
                        $_POST['skill_level'][$i] ?? 'Intermediate'
                    ]);
                }
            }
        }

        // Insert Certificates
        if (!empty($_POST['cert_name'])) {
            $ins = $db->prepare("INSERT INTO certificates (resume_id, name, issuer, issue_date, link) VALUES (?, ?, ?, ?, ?)");
            for ($i = 0; $i < count($_POST['cert_name']); $i++) {
                if (isset($_POST['cert_name'][$i]) && trim($_POST['cert_name'][$i]) !== '') {
                    $ins->execute([
                        $resumeId,
                        trim($_POST['cert_name'][$i]),
                        trim($_POST['cert_issuer'][$i] ?? ''),
                        (!empty($_POST['cert_date'][$i]) ? $_POST['cert_date'][$i] : null),
                        trim($_POST['cert_link'][$i] ?? '')
                    ]);
                }
            }
        }

        // Insert Achievements
        if (!empty($_POST['ach_title'])) {
            $ins = $db->prepare("INSERT INTO achievements (resume_id, title, description, date) VALUES (?, ?, ?, ?)");
            for ($i = 0; $i < count($_POST['ach_title']); $i++) {
                if (isset($_POST['ach_title'][$i]) && trim($_POST['ach_title'][$i]) !== '') {
                    $ins->execute([
                        $resumeId,
                        trim($_POST['ach_title'][$i]),
                        trim($_POST['ach_desc'][$i] ?? ''),
                        (!empty($_POST['ach_date'][$i]) ? $_POST['ach_date'][$i] : null)
                    ]);
                }
            }
        }

        // 3. Create Version History Snapshot JSON
        // Re-fetch all to get the updated child lists
        $snap = [
            'title' => $_POST['title'] ?? 'My Resume',
            'template_style' => $_POST['template_style'] ?? 'modern',
            'target_job_role' => $_POST['target_job_role'] ?? 'Software Engineer',
            'full_name' => $_POST['full_name'] ?? '',
            'email' => $_POST['email'] ?? '',
            'phone' => $_POST['phone'] ?? '',
            'linkedin' => $_POST['linkedin'] ?? '',
            'github' => $_POST['github'] ?? '',
            'portfolio' => $_POST['portfolio'] ?? '',
            'address' => $_POST['address'] ?? '',
            'summary' => $_POST['summary'] ?? '',
            'hobbies' => $_POST['hobbies'] ?? '',
            'strengths' => $_POST['strengths'] ?? '',
            'signature_data' => $_POST['signature_data'] ?? '',
            'recruiter_comments_enabled' => isset($_POST['recruiter_comments_enabled']) ? 1 : 0,
            'education' => [],
            'experience' => [],
            'projects' => [],
            'skills' => [],
            'certificates' => [],
            'achievements' => []
        ];
        
        // Populate child snapshot entries...
        if (!empty($_POST['edu_institution'])) {
            for ($i=0; $i<count($_POST['edu_institution']); $i++) {
                if (isset($_POST['edu_institution'][$i]) && trim($_POST['edu_institution'][$i]) !== '') {
                    $snap['education'][] = [
                        'institution' => $_POST['edu_institution'][$i],
                        'degree' => $_POST['edu_degree'][$i] ?? '',
                        'field_of_study' => $_POST['edu_field'][$i] ?? '',
                        'start_date' => $_POST['edu_start'][$i] ?? '',
                        'end_date' => $_POST['edu_end'][$i] ?? '',
                        'description' => $_POST['edu_desc'][$i] ?? ''
                    ];
                }
            }
        }
        if (!empty($_POST['exp_company'])) {
            for ($i=0; $i<count($_POST['exp_company']); $i++) {
                if (isset($_POST['exp_company'][$i]) && trim($_POST['exp_company'][$i]) !== '') {
                    $snap['experience'][] = [
                        'company' => $_POST['exp_company'][$i],
                        'position' => $_POST['exp_position'][$i] ?? '',
                        'start_date' => $_POST['exp_start'][$i] ?? '',
                        'end_date' => $_POST['exp_end'][$i] ?? '',
                        'description' => $_POST['exp_desc'][$i] ?? '',
                        'location' => $_POST['exp_location'][$i] ?? ''
                    ];
                }
            }
        }
        if (!empty($_POST['proj_title'])) {
            for ($i=0; $i<count($_POST['proj_title']); $i++) {
                if (isset($_POST['proj_title'][$i]) && trim($_POST['proj_title'][$i]) !== '') {
                    $snap['projects'][] = [
                        'title' => $_POST['proj_title'][$i],
                        'technologies' => $_POST['proj_tech'][$i] ?? '',
                        'description' => $_POST['proj_desc'][$i] ?? '',
                        'link' => $_POST['proj_link'][$i] ?? ''
                    ];
                }
            }
        }
        if (!empty($_POST['skill_name'])) {
            for ($i=0; $i<count($_POST['skill_name']); $i++) {
                if (isset($_POST['skill_name'][$i]) && trim($_POST['skill_name'][$i]) !== '') {
                    $snap['skills'][] = [
                        'name' => $_POST['skill_name'][$i],
                        'skill_type' => $_POST['skill_type'][$i] ?? 'technical',
                        'level' => $_POST['skill_level'][$i] ?? 'Intermediate'
                    ];
                }
            }
        }
        if (!empty($_POST['cert_name'])) {
            for ($i=0; $i<count($_POST['cert_name']); $i++) {
                if (isset($_POST['cert_name'][$i]) && trim($_POST['cert_name'][$i]) !== '') {
                    $snap['certificates'][] = [
                        'name' => $_POST['cert_name'][$i],
                        'issuer' => $_POST['cert_issuer'][$i] ?? '',
                        'issue_date' => $_POST['cert_date'][$i] ?? '',
                        'link' => $_POST['cert_link'][$i] ?? ''
                    ];
                }
            }
        }
        if (!empty($_POST['ach_title'])) {
            for ($i=0; $i<count($_POST['ach_title']); $i++) {
                if (isset($_POST['ach_title'][$i]) && trim($_POST['ach_title'][$i]) !== '') {
                    $snap['achievements'][] = [
                        'title' => $_POST['ach_title'][$i],
                        'description' => $_POST['ach_desc'][$i] ?? '',
                        'date' => $_POST['ach_date'][$i] ?? ''
                    ];
                }
            }
        }

        // Save JSON backup snapshot into versions table
        $backupStmt = $db->prepare("INSERT INTO resume_versions (resume_id, version_data) VALUES (?, ?)");
        $backupStmt->execute([$resumeId, json_encode($snap)]);

        $db->commit();
        $success_msg = "Resume changes saved and new version backed up successfully!";
        
        // Reload details
        $stmt = $db->prepare("SELECT * FROM resumes WHERE id = ?");
        $stmt->execute([$resumeId]);
        $resume = $stmt->fetch();
        
    } catch (Exception $e) {
        $db->rollBack();
        $error_msg = "Failed to save: " . $e->getMessage();
    }
}

// 4. Fetch Child Records for Display in Form
$stmt = $db->prepare("SELECT * FROM education WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$educationList = $stmt->fetchAll();

$stmt = $db->prepare("SELECT * FROM experience WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$experienceList = $stmt->fetchAll();

$stmt = $db->prepare("SELECT * FROM projects WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$projectsList = $stmt->fetchAll();

$stmt = $db->prepare("SELECT * FROM skills WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$skillsList = $stmt->fetchAll();

$stmt = $db->prepare("SELECT * FROM certificates WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$certificatesList = $stmt->fetchAll();

$stmt = $db->prepare("SELECT * FROM achievements WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$achievementsList = $stmt->fetchAll();

$stmt = $db->prepare("SELECT id, created_at FROM resume_versions WHERE resume_id = ? ORDER BY created_at DESC LIMIT 15");
$stmt->execute([$resumeId]);
$versionsList = $stmt->fetchAll();

$page_title = "Resume Builder";
require_once 'includes/header.php';
?>

<!-- Action Bar -->
<div class="row align-items-center mb-4 no-print">
    <div class="col">
        <h2 class="fw-bold Outfit mb-0">Resume Builder Wizard</h2>
        <p class="text-secondary mb-0">Fill in fields, leverage Gemini AI prompts, and preview your custom template styles.</p>
    </div>
    <div class="col-auto d-flex gap-2">
        <a href="dashboard.php" class="btn btn-outline-secondary"><i class="bi bi-chevron-left"></i> Back</a>
        <button type="submit" form="resumeForm" name="action_save" class="btn btn-gradient"><i class="bi bi-save me-1"></i> Save Progress</button>
    </div>
</div>

<?php if ($success_msg): ?>
    <div class="alert alert-success alert-dismissible fade show glass-card py-3 mb-4 no-print" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i>
        <span><?php echo htmlspecialchars($success_msg); ?></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if ($error_msg): ?>
    <div class="alert alert-danger alert-dismissible fade show glass-card py-3 mb-4 no-print" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i>
        <span><?php echo htmlspecialchars($error_msg); ?></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="row">
    <!-- Wizard Forms (Left) -->
    <div class="col-xl-6 mb-4 no-print">
        <div class="card glass-card">
            <div class="card-header bg-transparent border-bottom border-secondary border-opacity-10 p-0">
                <!-- Navigation Steps -->
                <ul class="nav nav-tabs nav-fill border-0" id="wizardTabs" role="tablist">
                    <li class="nav-item">
                        <button class="nav-link py-3 active fw-bold border-0" id="personal-tab" data-bs-toggle="tab" data-bs-target="#personal" type="button"><i class="bi bi-person me-1"></i> Personal</button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link py-3 fw-bold border-0" id="experience-tab" data-bs-toggle="tab" data-bs-target="#experience" type="button"><i class="bi bi-briefcase me-1"></i> Jobs</button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link py-3 fw-bold border-0" id="education-tab" data-bs-toggle="tab" data-bs-target="#education" type="button"><i class="bi bi-book me-1"></i> Studies</button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link py-3 fw-bold border-0" id="skills-tab" data-bs-toggle="tab" data-bs-target="#skills" type="button"><i class="bi bi-award me-1"></i> Skills</button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link py-3 fw-bold border-0" id="versions-tab" data-bs-toggle="tab" data-bs-target="#versions" type="button"><i class="bi bi-clock-history me-1"></i> History</button>
                    </li>
                </ul>
            </div>
            
            <form id="resumeForm" method="POST" action="resume.php?id=<?php echo $resumeId; ?>">
                <input type="hidden" name="action_save" value="1">
                
                <div class="card-body p-4 tab-content">
                    
                    <!-- TAB 1: PERSONAL & SUMMARY -->
                    <div class="tab-pane fade show active" id="personal" role="tabpanel">
                        <h5 class="fw-bold mb-4 text-gradient"><i class="bi bi-person-bounding-box me-2"></i>Personal Details</h5>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Resume Title</label>
                                <input type="text" class="form-control" name="title" value="<?php echo htmlspecialchars($resume['title'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Target Job Role</label>
                                <select class="form-select" name="target_job_role" id="targetRoleSelect">
                                    <?php foreach ($job_roles as $role): ?>
                                        <option value="<?php echo htmlspecialchars($role); ?>" <?php echo (($resume['target_job_role'] ?? '') == $role) ? 'selected' : ''; ?>><?php echo htmlspecialchars($role); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Full Name</label>
                                <input type="text" class="form-control" name="full_name" value="<?php echo htmlspecialchars($resume['full_name'] ?? ''); ?>" placeholder="John Doe">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($resume['email'] ?? ''); ?>" placeholder="john@example.com">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Phone</label>
                                <input type="text" class="form-control" name="phone" value="<?php echo htmlspecialchars($resume['phone'] ?? ''); ?>" placeholder="+1 234 567 890">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">LinkedIn</label>
                                <input type="text" class="form-control" name="linkedin" value="<?php echo htmlspecialchars($resume['linkedin'] ?? ''); ?>" placeholder="linkedin.com/in/username">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">GitHub</label>
                                <input type="text" class="form-control" name="github" value="<?php echo htmlspecialchars($resume['github'] ?? ''); ?>" placeholder="github.com/username">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Portfolio Link</label>
                                <input type="text" class="form-control" name="portfolio" value="<?php echo htmlspecialchars($resume['portfolio'] ?? ''); ?>" placeholder="yourwebsite.com">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Address</label>
                                <textarea class="form-control" name="address" rows="2" placeholder="123 Main St, New York, NY"><?php echo htmlspecialchars($resume['address'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <hr class="my-4 text-muted">
                        
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="fw-bold text-gradient mb-0"><i class="bi bi-quote me-2"></i>Professional Summary</h5>
                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-sm btn-outline-secondary" id="voiceSummaryBtn"><i class="bi bi-mic"></i></button>
                                <button type="button" class="btn btn-sm btn-gradient py-1" id="btnGenSummary"><i class="bi bi-magic me-1"></i> Write with AI</button>
                            </div>
                        </div>
                        <textarea class="form-control" name="summary" id="summaryTextarea" rows="4" placeholder="Briefly describe your career achievements..."><?php echo htmlspecialchars($resume['summary'] ?? ''); ?></textarea>
                        
                        <div class="mb-3 mt-4">
                            <label class="form-label fw-bold">Hobbies <span class="text-secondary small">(Optional)</span></label>
                            <input type="text" class="form-control" name="hobbies" value="<?php echo htmlspecialchars($resume['hobbies'] ?? ''); ?>" placeholder="Coding, Reading, Football">
                        </div>

                        <!-- Strengths Tag Input -->
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Core Strengths <span class="text-secondary small">(Click to add, × to remove)</span></label>
                            <div class="d-flex gap-2 flex-wrap mb-2" id="strengthsTagContainer"></div>
                            <div class="input-group">
                                <input type="text" class="form-control" id="strengthTagInput" placeholder="e.g. Leadership, Teamwork, Problem Solving..." maxlength="40">
                                <button type="button" class="btn btn-outline-secondary" id="addStrengthBtn"><i class="bi bi-plus-lg"></i> Add</button>
                            </div>
                            <div class="d-flex flex-wrap gap-1 mt-2" id="strengthSuggestions">
                                <?php foreach (['Leadership','Teamwork','Problem Solving','Communication','Creativity','Adaptability','Critical Thinking','Time Management','Attention to Detail','Work Ethic'] as $sug): ?>
                                    <span class="badge rounded-pill border border-secondary border-opacity-25 text-secondary px-2 py-1 strength-suggestion" style="cursor:pointer;font-size:0.72rem;"><?php echo $sug; ?></span>
                                <?php endforeach; ?>
                            </div>
                            <!-- Hidden field stores comma-separated strengths for form POST -->
                            <input type="hidden" name="strengths" id="strengthsHiddenInput" value="<?php echo htmlspecialchars($resume['strengths'] ?? ''); ?>">
                        </div>

                        <div class="form-check form-switch mt-3">
                            <input class="form-check-input" type="checkbox" role="switch" id="commentToggle" name="recruiter_comments_enabled" <?php echo (!empty($resume['recruiter_comments_enabled'])) ? 'checked' : ''; ?>>
                            <label class="form-check-label text-secondary" for="commentToggle">Enable recruiter ratings and comment reviews on sharing portal</label>
                        </div>

                        <!-- Signature Pad -->
                        <hr class="my-4 text-muted">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h5 class="fw-bold text-gradient mb-0"><i class="bi bi-pen me-2"></i>Signature</h5>
                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-sm btn-outline-secondary" id="sigTypedTab" onclick="switchSigMode('typed')">Typed</button>
                                <button type="button" class="btn btn-sm btn-outline-gradient" id="sigDrawTab" onclick="switchSigMode('drawn')">Draw</button>
                                <button type="button" class="btn btn-sm btn-outline-danger" id="clearSigBtn"><i class="bi bi-x-circle"></i> Clear</button>
                            </div>
                        </div>
                        <p class="text-secondary small mb-2">Your signature will appear at the bottom of the printed resume.</p>

                        <!-- Drawn Signature Canvas -->
                        <div id="sigDrawArea">
                            <canvas id="signatureCanvas" width="500" height="110"
                                style="border:1px solid var(--input-border); border-radius:8px; background:#fff; cursor:crosshair; width:100%; touch-action:none;"></canvas>
                        </div>

                        <!-- Typed Signature -->
                        <div id="sigTypedArea" class="d-none">
                            <input type="text" class="form-control" id="sigTypedInput" placeholder="Type your full name to generate a signature" style="font-family:'Dancing Script',cursive; font-size:1.6rem; letter-spacing:2px;">
                            <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap">
                        </div>

                        <!-- Hidden base64 storage for signature -->
                        <input type="hidden" name="signature_data" id="signatureDataInput" value="<?php echo htmlspecialchars($resume['signature_data'] ?? ''); ?>">
                    </div>
                    
                    <!-- TAB 2: WORK EXPERIENCE -->
                    <div class="tab-pane fade" id="experience" role="tabpanel">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold text-gradient mb-0"><i class="bi bi-briefcase me-2"></i>Work Experience</h5>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="addExpBtn"><i class="bi bi-plus-lg me-1"></i> Add Entry</button>
                        </div>
                        
                        <div id="experienceContainer">
                            <?php 
                            $expIdx = 0;
                            foreach ($experienceList as $exp): 
                            ?>
                                <div class="card bg-transparent border border-secondary border-opacity-10 p-3 mb-3 position-relative entry-card">
                                    <button type="button" class="btn-close position-absolute top-0 end-0 m-3 btn-remove-entry" aria-label="Remove"></button>
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Company</label>
                                            <input type="text" class="form-control" name="exp_company[]" value="<?php echo htmlspecialchars($exp['company']); ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Position</label>
                                            <input type="text" class="form-control" name="exp_position[]" value="<?php echo htmlspecialchars($exp['position']); ?>" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Location</label>
                                            <input type="text" class="form-control" name="exp_location[]" value="<?php echo htmlspecialchars($exp['location'] ?? ''); ?>">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Start Date</label>
                                            <input type="date" class="form-control" name="exp_start[]" value="<?php echo $exp['start_date']; ?>">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">End Date</label>
                                            <input type="date" class="form-control" name="exp_end[]" value="<?php echo $exp['end_date']; ?>">
                                            <small class="text-muted">Leave empty if current</small>
                                        </div>
                                        <div class="col-12">
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <label class="form-label mb-0">Job Description / Highlights</label>
                                                <div class="d-flex gap-1.5">
                                                    <button type="button" class="btn btn-xs btn-outline-secondary py-0.5 px-2 voice-field-btn"><i class="bi bi-mic"></i></button>
                                                    <button type="button" class="btn btn-xs btn-outline-gradient py-0.5 px-2 ai-rewrite-btn"><i class="bi bi-magic"></i> Improve</button>
                                                </div>
                                            </div>
                                            <textarea class="form-control description-textarea" name="exp_desc[]" rows="3"><?php echo htmlspecialchars($exp['description']); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            <?php 
                            $expIdx++;
                            endforeach; 
                            if ($expIdx === 0):
                            ?>
                                <!-- Starter default card -->
                                <div class="card bg-transparent border border-secondary border-opacity-10 p-3 mb-3 position-relative entry-card">
                                    <button type="button" class="btn-close position-absolute top-0 end-0 m-3 btn-remove-entry" aria-label="Remove"></button>
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Company</label>
                                            <input type="text" class="form-control" name="exp_company[]" placeholder="Google">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Position</label>
                                            <input type="text" class="form-control" name="exp_position[]" placeholder="Web Developer">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Location</label>
                                            <input type="text" class="form-control" name="exp_location[]" placeholder="New York, NY">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Start Date</label>
                                            <input type="date" class="form-control" name="exp_start[]">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">End Date</label>
                                            <input type="date" class="form-control" name="exp_end[]">
                                        </div>
                                        <div class="col-12">
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <label class="form-label mb-0">Job Description / Highlights</label>
                                                <div class="d-flex gap-1.5">
                                                    <button type="button" class="btn btn-xs btn-outline-secondary py-0.5 px-2 voice-field-btn"><i class="bi bi-mic"></i></button>
                                                    <button type="button" class="btn btn-xs btn-outline-gradient py-0.5 px-2 ai-rewrite-btn"><i class="bi bi-magic"></i> Improve</button>
                                                </div>
                                            </div>
                                            <textarea class="form-control description-textarea" name="exp_desc[]" rows="3" placeholder="I made websites and databases..."></textarea>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- TAB 3: STUDIES & PROJECTS -->
                    <div class="tab-pane fade" id="education" role="tabpanel">
                        <!-- Education -->
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="fw-bold text-gradient mb-0"><i class="bi bi-book me-2"></i>Education History</h5>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="addEduBtn"><i class="bi bi-plus-lg me-1"></i> Add Study</button>
                        </div>
                        <div id="educationContainer">
                            <?php 
                            $eduIdx = 0;
                            foreach ($educationList as $edu): 
                            ?>
                                <div class="card bg-transparent border border-secondary border-opacity-10 p-3 mb-3 position-relative entry-card">
                                    <button type="button" class="btn-close position-absolute top-0 end-0 m-3 btn-remove-entry" aria-label="Remove"></button>
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Institution</label>
                                            <input type="text" class="form-control" name="edu_institution[]" value="<?php echo htmlspecialchars($edu['institution']); ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Degree / Certification</label>
                                            <input type="text" class="form-control" name="edu_degree[]" value="<?php echo htmlspecialchars($edu['degree'] ?? ''); ?>" placeholder="Bachelor of Science">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Field of Study</label>
                                            <input type="text" class="form-control" name="edu_field[]" value="<?php echo htmlspecialchars($edu['field_of_study'] ?? ''); ?>" placeholder="Computer Science">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label">Start Date</label>
                                            <input type="date" class="form-control" name="edu_start[]" value="<?php echo $edu['start_date']; ?>">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label">Graduation / Expected Date</label>
                                            <input type="date" class="form-control" name="edu_end[]" value="<?php echo $edu['end_date']; ?>">
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">GPA, Honors & Achievements <span class="text-secondary small">(ATS-friendly: e.g. GPA: 3.8/4.0 · Dean's List · First Class Honours)</span></label>
                                            <textarea class="form-control description-textarea" name="edu_desc[]" rows="2" placeholder="GPA: 3.8/4.0 · Graduated with Distinction · Dean's List (2022–2024) · Relevant coursework: Data Structures, Web Development, Databases"><?php echo htmlspecialchars($edu['description'] ?? ''); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            <?php 
                            $eduIdx++;
                            endforeach; 
                            if ($eduIdx === 0):
                            ?>
                                <!-- Sample Entry 1: Bachelor's Degree -->
                                <div class="card bg-transparent border border-secondary border-opacity-10 p-3 mb-3 position-relative entry-card">
                                    <button type="button" class="btn-close position-absolute top-0 end-0 m-3 btn-remove-entry" aria-label="Remove"></button>
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Institution</label>
                                            <input type="text" class="form-control" name="edu_institution[]" placeholder="e.g. University of Mumbai" value="">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Degree / Certification</label>
                                            <input type="text" class="form-control" name="edu_degree[]" value="" placeholder="e.g. Bachelor of Engineering">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Field of Study</label>
                                            <input type="text" class="form-control" name="edu_field[]" value="" placeholder="e.g. Computer Engineering">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label">Start Date</label>
                                            <input type="date" class="form-control" name="edu_start[]" value="">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label">Graduation / Expected Date</label>
                                            <input type="date" class="form-control" name="edu_end[]" value="">
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">GPA, Honors & Achievements <span class="text-secondary small">(ATS-friendly)</span></label>
                                            <textarea class="form-control description-textarea" name="edu_desc[]" rows="2" placeholder="GPA: 3.8/4.0 · First Class with Distinction · Dean's List · Relevant coursework: Data Structures, DBMS, Web Technologies"></textarea>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Projects -->
                        <div class="d-flex justify-content-between align-items-center mb-3 mt-4">
                            <h5 class="fw-bold text-gradient mb-0"><i class="bi bi-folder me-2"></i>Projects</h5>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="addProjBtn"><i class="bi bi-plus-lg me-1"></i> Add Project</button>
                        </div>
                        <div id="projectsContainer">
                            <?php 
                            $projIdx = 0;
                            foreach ($projectsList as $proj): 
                            ?>
                                <div class="card bg-transparent border border-secondary border-opacity-10 p-3 mb-3 position-relative entry-card">
                                    <button type="button" class="btn-close position-absolute top-0 end-0 m-3 btn-remove-entry" aria-label="Remove"></button>
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Project Title</label>
                                            <input type="text" class="form-control" name="proj_title[]" value="<?php echo htmlspecialchars($proj['title']); ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Technologies (separated by commas)</label>
                                            <input type="text" class="form-control" name="proj_tech[]" value="<?php echo htmlspecialchars($proj['technologies'] ?? ''); ?>" placeholder="PHP, Bootstrap, JS">
                                        </div>
                                        <div class="col-md-12">
                                            <label class="form-label">Project Details / Description</label>
                                            <textarea class="form-control description-textarea" name="proj_desc[]" rows="2"><?php echo htmlspecialchars($proj['description'] ?? ''); ?></textarea>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">Link (optional)</label>
                                            <input type="text" class="form-control" name="proj_link[]" value="<?php echo htmlspecialchars($proj['link'] ?? ''); ?>" placeholder="https://github.com/project">
                                        </div>
                                    </div>
                                </div>
                            <?php 
                            $projIdx++;
                            endforeach;
                            if ($projIdx === 0):
                            ?>
                                <div class="card bg-transparent border border-secondary border-opacity-10 p-3 mb-3 position-relative entry-card">
                                    <button type="button" class="btn-close position-absolute top-0 end-0 m-3 btn-remove-entry" aria-label="Remove"></button>
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Project Title</label>
                                            <input type="text" class="form-control" name="proj_title[]" placeholder="E-Commerce API">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Technologies</label>
                                            <input type="text" class="form-control" name="proj_tech[]" placeholder="PHP, MySQL, REST API">
                                        </div>
                                        <div class="col-md-12">
                                            <label class="form-label">Project Details / Description</label>
                                            <textarea class="form-control description-textarea" name="proj_desc[]" rows="2" placeholder="Designed and optimized a database..."></textarea>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">Link</label>
                                            <input type="text" class="form-control" name="proj_link[]" placeholder="https://github.com/ecommerce">
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- TAB 4: SKILLS & CERTIFICATES -->
                    <div class="tab-pane fade" id="skills" role="tabpanel">

                        <!-- Strengths Section -->
                        <div class="mb-4 p-3 rounded-3" style="background: linear-gradient(135deg,rgba(99,102,241,0.07) 0%,rgba(168,85,247,0.07) 100%); border:1px solid rgba(168,85,247,0.18);">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h5 class="fw-bold text-gradient mb-0"><i class="bi bi-lightning me-2"></i>Core Strengths</h5>
                                <small class="text-secondary">Shown as badges on your resume</small>
                            </div>
                            <p class="text-secondary small mb-0">Manage your strengths from the <strong>Personal</strong> tab (Strengths section).</p>
                            <div class="d-flex flex-wrap gap-2 mt-2" id="strengthsPreviewInSkills"></div>
                        </div>

                        <!-- Skills -->
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="fw-bold text-gradient mb-0"><i class="bi bi-award me-2"></i>Skills</h5>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="addSkillBtn"><i class="bi bi-plus-lg me-1"></i> Add Skill</button>
                        </div>
                        
                        <!-- AI Skill Recommender Button -->
                        <div class="mb-3 p-3 bg-secondary bg-opacity-10 border border-secondary border-opacity-15 rounded-3 d-flex justify-content-between align-items-center">
                            <div>
                                <small class="fw-bold d-block text-gradient">AI Skill Insights</small>
                                <small class="text-secondary">Analyze your active skills and recommend missing ones.</small>
                            </div>
                            <button type="button" class="btn btn-sm btn-outline-gradient" id="btnRecSkills"><i class="bi bi-magic me-1"></i> Auto Recommend</button>
                        </div>
                        <div id="aiSkillSuggestions" class="mb-3 d-none">
                            <small class="text-muted d-block mb-2">Click below to add recommended skills instantly:</small>
                            <div class="d-flex flex-wrap gap-2" id="aiSkillsList"></div>
                        </div>

                        <div id="skillsContainer">
                            <?php 
                            $skillIdx = 0;
                            foreach ($skillsList as $skill): 
                            ?>
                                <div class="row g-2 mb-2 align-items-center entry-card">
                                    <div class="col-md-5">
                                        <input type="text" class="form-control skill-name-field" name="skill_name[]" value="<?php echo htmlspecialchars($skill['name']); ?>" required placeholder="e.g. JavaScript">
                                    </div>
                                    <div class="col-md-4">
                                        <select class="form-select" name="skill_type[]">
                                            <option value="technical" <?php echo ($skill['skill_type'] == 'technical') ? 'selected' : ''; ?>>Technical</option>
                                            <option value="soft" <?php echo ($skill['skill_type'] == 'soft') ? 'selected' : ''; ?>>Soft Skill</option>
                                            <option value="language" <?php echo ($skill['skill_type'] == 'language') ? 'selected' : ''; ?>>Language</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <select class="form-select" name="skill_level[]">
                                            <option value="Beginner" <?php echo ($skill['level'] == 'Beginner') ? 'selected' : ''; ?>>Beginner</option>
                                            <option value="Intermediate" <?php echo ($skill['level'] == 'Intermediate') ? 'selected' : ''; ?>>Intermediate</option>
                                            <option value="Expert" <?php echo ($skill['level'] == 'Expert') ? 'selected' : ''; ?>>Expert</option>
                                        </select>
                                    </div>
                                    <div class="col-md-1 text-center">
                                        <button type="button" class="btn btn-sm btn-link text-danger btn-remove-entry p-0"><i class="bi bi-trash fs-5"></i></button>
                                    </div>
                                </div>
                            <?php 
                            $skillIdx++;
                            endforeach; 
                            if ($skillIdx === 0):
                            ?>
                                <div class="row g-2 mb-2 align-items-center entry-card">
                                    <div class="col-md-5">
                                        <input type="text" class="form-control skill-name-field" name="skill_name[]" placeholder="e.g. PHP">
                                    </div>
                                    <div class="col-md-4">
                                        <select class="form-select" name="skill_type[]">
                                            <option value="technical">Technical</option>
                                            <option value="soft">Soft Skill</option>
                                            <option value="language">Language</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <select class="form-select" name="skill_level[]">
                                            <option value="Beginner">Beginner</option>
                                            <option value="Intermediate" selected>Intermediate</option>
                                            <option value="Expert">Expert</option>
                                        </select>
                                    </div>
                                    <div class="col-md-1 text-center">
                                        <button type="button" class="btn btn-sm btn-link text-danger btn-remove-entry p-0"><i class="bi bi-trash fs-5"></i></button>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Certificates -->
                        <div class="d-flex justify-content-between align-items-center mb-3 mt-4">
                            <h5 class="fw-bold text-gradient mb-0"><i class="bi bi-patch-check me-2"></i>Certificates</h5>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="addCertBtn"><i class="bi bi-plus-lg me-1"></i> Add Certificate</button>
                        </div>
                        <div id="certificatesContainer">
                            <?php 
                            $certIdx = 0;
                            foreach ($certificatesList as $cert): 
                            ?>
                                <div class="card bg-transparent border border-secondary border-opacity-10 p-3 mb-3 position-relative entry-card">
                                    <button type="button" class="btn-close position-absolute top-0 end-0 m-3 btn-remove-entry" aria-label="Remove"></button>
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Certificate Name</label>
                                            <input type="text" class="form-control" name="cert_name[]" value="<?php echo htmlspecialchars($cert['name']); ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Issuer</label>
                                            <input type="text" class="form-control" name="cert_issuer[]" value="<?php echo htmlspecialchars($cert['issuer'] ?? ''); ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Issue Date</label>
                                            <input type="date" class="form-control" name="cert_date[]" value="<?php echo $cert['issue_date']; ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Certificate Link (optional)</label>
                                            <input type="text" class="form-control" name="cert_link[]" value="<?php echo htmlspecialchars($cert['link'] ?? ''); ?>">
                                        </div>
                                    </div>
                                </div>
                            <?php 
                            $certIdx++;
                            endforeach; 
                            ?>
                        </div>

                        <!-- Achievements -->
                        <div class="d-flex justify-content-between align-items-center mb-3 mt-4">
                            <h5 class="fw-bold text-gradient mb-0"><i class="bi bi-trophy me-2"></i>Achievements</h5>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="addAchBtn"><i class="bi bi-plus-lg me-1"></i> Add Achievement</button>
                        </div>
                        <div id="achievementsContainer">
                            <?php 
                            $achIdx = 0;
                            foreach ($achievementsList as $ach): 
                            ?>
                                <div class="card bg-transparent border border-secondary border-opacity-10 p-3 mb-3 position-relative entry-card">
                                    <button type="button" class="btn-close position-absolute top-0 end-0 m-3 btn-remove-entry" aria-label="Remove"></button>
                                    <div class="row g-3">
                                        <div class="col-md-8">
                                            <label class="form-label">Achievement Title</label>
                                            <input type="text" class="form-control" name="ach_title[]" value="<?php echo htmlspecialchars($ach['title']); ?>" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Date Awarded</label>
                                            <input type="date" class="form-control" name="ach_date[]" value="<?php echo $ach['date']; ?>">
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">Description / Highlight</label>
                                            <textarea class="form-control" name="ach_desc[]" rows="2"><?php echo htmlspecialchars($ach['description'] ?? ''); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            <?php 
                            $achIdx++;
                            endforeach; 
                            ?>
                        </div>
                    </div>
                    
                    <!-- TAB 5: BACKUP VERSIONS -->
                    <div class="tab-pane fade" id="versions" role="tabpanel">
                        <h5 class="fw-bold mb-4 text-gradient"><i class="bi bi-clock-history me-2"></i>Version History Backup</h5>
                        <p class="text-secondary small">Every time you click "Save Progress", the builder creates a secure JSON snapshot of your data. You can rollback or restore details instantly.</p>
                        
                        <?php if (count($versionsList) === 0): ?>
                            <div class="text-center py-4">
                                <i class="bi bi-cloud-arrow-up fs-2 text-secondary mb-2 d-block"></i>
                                <small class="text-secondary">No versions backed up yet. Make a save to trigger snapshot.</small>
                            </div>
                        <?php else: ?>
                            <div class="list-group">
                                <?php foreach ($versionsList as $v): ?>
                                    <div class="list-group-item bg-transparent border-secondary border-opacity-10 d-flex justify-content-between align-items-center py-3">
                                        <div>
                                            <span class="fw-bold text-gradient small d-block">Snapshot #<?php echo $v['id']; ?></span>
                                            <small class="text-secondary"><?php echo date('F d, Y h:i A', strtotime($v['created_at'])); ?></small>
                                        </div>
                                        <form action="resume.php?id=<?php echo $resumeId; ?>" method="POST" onsubmit="return confirm('Warning: Restoring will overwrite your current screen modifications. Proceed?');">
                                            <input type="hidden" name="action_restore" value="1">
                                            <input type="hidden" name="version_id" value="<?php echo $v['id']; ?>">
                                            <button type="submit" class="btn btn-xs btn-outline-gradient"><i class="bi bi-arrow-counterclockwise"></i> Restore</button>
                                        </form>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                </div>
            </form>
        </div>
    </div>
    
    <!-- Real-time Styled Print Preview (Right) -->
    <div class="col-xl-6 print-container">
        <!-- Actions & Template Switcher -->
        <div class="card glass-card p-3 mb-4 no-print d-flex flex-row flex-wrap justify-content-between align-items-center gap-3">
            <div class="d-flex align-items-center gap-2">
                <label class="fw-semibold small text-secondary">Style Theme:</label>
                <select class="form-select form-select-sm" id="templateStyleSelector">
                    <?php foreach ($templates as $key => $name): ?>
                        <option value="<?php echo $key; ?>" <?php echo (($resume['template_style'] ?? 'modern') == $key) ? 'selected' : ''; ?>><?php echo $name; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="d-flex gap-2">
                <!-- QR Code Generator Button -->
                <button class="btn btn-sm btn-outline-secondary" id="btnGenQR" title="Generate Resume QR Code"><i class="bi bi-qr-code"></i> QR Code</button>
                <button class="btn btn-sm btn-outline-gradient" onclick="printResume();"><i class="bi bi-printer-fill me-1"></i> Print / PDF</button>
            </div>
        </div>
        
        <!-- Live Preview Target Container -->
        <div id="resumePreview" class="resume-preview-container template-<?php echo htmlspecialchars($resume['template_style'] ?? 'modern'); ?>">
            <!-- Filled dynamically via JS inputs -->
        </div>
        
        <!-- QR Code Display Placeholder -->
        <div id="qrContainer" class="card glass-card p-3 mb-4 text-center d-none no-print">
            <h6 class="fw-bold mb-2">Resume Sharing QR Code</h6>
            <div class="d-inline-block bg-white p-2 rounded mb-2" id="qrTarget"></div>
            <p class="text-secondary small mb-0">Recruiters can scan this code to view your active online profile rating panel.</p>
        </div>
    </div>
</div>

<!-- Dynamically injected item templates for dynamically added fields -->
<div class="d-none">
    <!-- Education Template -->
    <div id="eduTemplate">
        <div class="card bg-transparent border border-secondary border-opacity-10 p-3 mb-3 position-relative entry-card">
            <button type="button" class="btn-close position-absolute top-0 end-0 m-3 btn-remove-entry" aria-label="Remove"></button>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Institution</label>
                    <input type="text" class="form-control" name="edu_institution[]" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Degree / Certification</label>
                    <input type="text" class="form-control" name="edu_degree[]" placeholder="Bachelor of Science">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Field of Study</label>
                    <input type="text" class="form-control" name="edu_field[]" placeholder="Computer Science">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Start Date</label>
                    <input type="date" class="form-control" name="edu_start[]">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Graduation / Expected Date</label>
                    <input type="date" class="form-control" name="edu_end[]">
                </div>
                <div class="col-12">
                    <label class="form-label">GPA, Honors & Achievements <span class="text-secondary small">(ATS-friendly)</span></label>
                    <textarea class="form-control description-textarea" name="edu_desc[]" rows="2" placeholder="GPA: 3.8/4.0 · Graduated with Distinction · Dean's List · Relevant coursework: Algorithms, Databases, Web Dev"></textarea>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Experience Template -->
    <div id="expTemplate">
        <div class="card bg-transparent border border-secondary border-opacity-10 p-3 mb-3 position-relative entry-card">
            <button type="button" class="btn-close position-absolute top-0 end-0 m-3 btn-remove-entry" aria-label="Remove"></button>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Company</label>
                    <input type="text" class="form-control" name="exp_company[]" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Position</label>
                    <input type="text" class="form-control" name="exp_position[]" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Location</label>
                    <input type="text" class="form-control" name="exp_location[]" placeholder="New York, NY">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Start Date</label>
                    <input type="date" class="form-control" name="exp_start[]">
                </div>
                <div class="col-md-4">
                    <label class="form-label">End Date</label>
                    <input type="date" class="form-control" name="exp_end[]">
                </div>
                <div class="col-12">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <label class="form-label mb-0">Job Description / Highlights</label>
                        <div class="d-flex gap-1.5">
                            <button type="button" class="btn btn-xs btn-outline-secondary py-0.5 px-2 voice-field-btn"><i class="bi bi-mic"></i></button>
                            <button type="button" class="btn btn-xs btn-outline-gradient py-0.5 px-2 ai-rewrite-btn"><i class="bi bi-magic"></i> Improve</button>
                        </div>
                    </div>
                    <textarea class="form-control description-textarea" name="exp_desc[]" rows="3"></textarea>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Projects Template -->
    <div id="projTemplate">
        <div class="card bg-transparent border border-secondary border-opacity-10 p-3 mb-3 position-relative entry-card">
            <button type="button" class="btn-close position-absolute top-0 end-0 m-3 btn-remove-entry" aria-label="Remove"></button>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Project Title</label>
                    <input type="text" class="form-control" name="proj_title[]" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Technologies</label>
                    <input type="text" class="form-control" name="proj_tech[]" placeholder="React, Node.js">
                </div>
                <div class="col-md-12">
                    <label class="form-label">Project Details / Description</label>
                    <textarea class="form-control description-textarea" name="proj_desc[]" rows="2"></textarea>
                </div>
                <div class="col-12">
                    <label class="form-label">Link</label>
                    <input type="text" class="form-control" name="proj_link[]" placeholder="https://github.com/project">
                </div>
            </div>
        </div>
    </div>
    
    <!-- Skills Template -->
    <div id="skillTemplate">
        <div class="row g-2 mb-2 align-items-center entry-card animate-fade-in">
            <div class="col-md-5">
                <input type="text" class="form-control skill-name-field" name="skill_name[]" placeholder="e.g. JavaScript" required>
            </div>
            <div class="col-md-4">
                <select class="form-select" name="skill_type[]">
                    <option value="technical" selected>Technical</option>
                    <option value="soft">Soft Skill</option>
                    <option value="language">Language</option>
                </select>
            </div>
            <div class="col-md-2">
                <select class="form-select" name="skill_level[]">
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate" selected>Intermediate</option>
                    <option value="Expert">Expert</option>
                </select>
            </div>
            <div class="col-md-1 text-center">
                <button type="button" class="btn btn-sm btn-link text-danger btn-remove-entry p-0"><i class="bi bi-trash fs-5"></i></button>
            </div>
        </div>
    </div>

    <!-- Certificate Template -->
    <div id="certTemplate">
        <div class="card bg-transparent border border-secondary border-opacity-10 p-3 mb-3 position-relative entry-card">
            <button type="button" class="btn-close position-absolute top-0 end-0 m-3 btn-remove-entry" aria-label="Remove"></button>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Certificate Name</label>
                    <input type="text" class="form-control" name="cert_name[]" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Issuer</label>
                    <input type="text" class="form-control" name="cert_issuer[]">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Issue Date</label>
                    <input type="date" class="form-control" name="cert_date[]">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Certificate Link (optional)</label>
                    <input type="text" class="form-control" name="cert_link[]">
                </div>
            </div>
        </div>
    </div>

    <!-- Achievement Template -->
    <div id="achTemplate">
        <div class="card bg-transparent border border-secondary border-opacity-10 p-3 mb-3 position-relative entry-card">
            <button type="button" class="btn-close position-absolute top-0 end-0 m-3 btn-remove-entry" aria-label="Remove"></button>
            <div class="row g-3">
                <div class="col-md-8">
                    <label class="form-label">Achievement Title</label>
                    <input type="text" class="form-control" name="ach_title[]" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Date Awarded</label>
                    <input type="date" class="form-control" name="ach_date[]">
                </div>
                <div class="col-12">
                    <label class="form-label">Description / Highlight</label>
                    <textarea class="form-control" name="ach_desc[]" rows="2"></textarea>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- QR Generator Library -->
<script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>

<script>
// Helper to trigger print once web fonts are fully loaded
function printResume() {
    document.fonts.ready.then(() => {
        window.print();
    });
}

document.addEventListener("DOMContentLoaded", () => {
    const previewContainer = document.getElementById("resumePreview");
    const styleSelector = document.getElementById("templateStyleSelector");
    const resumeForm = document.getElementById("resumeForm");

    // 1. Dynamic list additions
    const bindRemovers = () => {
        document.querySelectorAll(".btn-remove-entry").forEach(btn => {
            btn.onclick = () => {
                const entry = btn.closest(".entry-card");
                if (entry) {
                    entry.remove();
                    updatePreview();
                }
            };
        });
    };

    const addCard = (containerId, templateId) => {
        const container = document.getElementById(containerId);
        const temp = document.getElementById(templateId).firstElementChild.cloneNode(true);
        container.appendChild(temp);
        bindRemovers();
        bindAIButtons(temp);
        bindVoiceButtons(temp);
        
        // auto-scroll
        temp.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    };

    document.getElementById("addExpBtn").onclick = () => addCard("experienceContainer", "expTemplate");
    document.getElementById("addEduBtn").onclick = () => addCard("educationContainer", "eduTemplate");
    document.getElementById("addProjBtn").onclick = () => addCard("projectsContainer", "projTemplate");
    document.getElementById("addSkillBtn").onclick = () => addCard("skillsContainer", "skillTemplate");
    document.getElementById("addCertBtn").onclick = () => addCard("certificatesContainer", "certTemplate");
    document.getElementById("addAchBtn").onclick = () => addCard("achievementsContainer", "achTemplate");

    // Helper to get element value safely to prevent JS errors
    const getVal = (selector, fallback = '') => {
        const el = resumeForm.querySelector(selector);
        return el ? el.value : fallback;
    };

    // Helper to format bullets in text blocks (e.g. from - or • to list items)
    const formatBullets = (text) => {
        if (!text) return "";
        const lines = text.split('\n');
        let hasBullets = false;
        
        const formattedLines = lines.map(line => {
            const trimmed = line.trim();
            if (trimmed.startsWith('-') || trimmed.startsWith('*') || trimmed.startsWith('•')) {
                hasBullets = true;
                const content = trimmed.substring(1).trim();
                return `<li>${content}</li>`;
            }
            return line;
        });

        if (hasBullets) {
            let html = "";
            let inList = false;
            for (let i = 0; i < formattedLines.length; i++) {
                const line = formattedLines[i];
                if (line.startsWith('<li>')) {
                    if (!inList) {
                        html += `<ul class="resume-bullet-list mb-2">`;
                        inList = true;
                    }
                    html += line;
                } else {
                    if (inList) {
                        html += `</ul>`;
                        inList = false;
                    }
                    if (line.trim() !== '') {
                        html += `<p class="mb-1 small">${line}</p>`;
                    }
                }
            }
            if (inList) {
                html += `</ul>`;
            }
            return html;
        } else {
            return `<p class="mb-0 small" style="white-space: pre-wrap;">${text}</p>`;
        }
    };

    // 2. Realtime Preview Renderer
    const updatePreview = () => {
        const title = styleSelector.value;
        previewContainer.className = `resume-preview-container template-${title}`;

        const fullName = getVal("[name='full_name']", "Full Name");
        const email = getVal("[name='email']", "email@example.com");
        const phone = getVal("[name='phone']", "+123-456-7890");
        const linkedin = getVal("[name='linkedin']");
        const github = getVal("[name='github']");
        const portfolio = getVal("[name='portfolio']");
        const address = getVal("[name='address']");
        const summary = getVal("[name='summary']", "Your professional summary will appear here...");
        const hobbies = getVal("[name='hobbies']");
        const strengths = getVal("[name='strengths']");

        // Build contact links line
        let contactHtml = `<div class="d-flex flex-wrap gap-3 justify-content-center align-items-center border-bottom pb-3 small mb-3 border-secondary border-opacity-10 text-muted">
            <span class="d-inline-flex align-items-center gap-1"><i class="bi bi-envelope"></i> ${email}</span>
            <span class="d-inline-flex align-items-center gap-1"><i class="bi bi-phone"></i> ${phone}</span>`;
        if (address) contactHtml += `<span class="d-inline-flex align-items-center gap-1"><i class="bi bi-geo-alt"></i> ${address}</span>`;
        if (linkedin) contactHtml += `<span class="d-inline-flex align-items-center gap-1"><i class="bi bi-linkedin"></i> ${linkedin}</span>`;
        if (github) contactHtml += `<span class="d-inline-flex align-items-center gap-1"><i class="bi bi-github"></i> ${github}</span>`;
        if (portfolio) contactHtml += `<span class="d-inline-flex align-items-center gap-1"><i class="bi bi-globe"></i> ${portfolio}</span>`;
        contactHtml += `</div>`;

        // Gather Experience
        let expHtml = "";
        const expCompanies = resumeForm.querySelectorAll("[name='exp_company[]']");
        const expPositions = resumeForm.querySelectorAll("[name='exp_position[]']");
        const expLocations = resumeForm.querySelectorAll("[name='exp_location[]']");
        const expStarts = resumeForm.querySelectorAll("[name='exp_start[]']");
        const expEnds = resumeForm.querySelectorAll("[name='exp_end[]']");
        const expDescs = resumeForm.querySelectorAll("[name='exp_desc[]']");
        
        for (let i = 0; i < expCompanies.length; i++) {
            if (expCompanies[i] && expCompanies[i].value.trim() !== '') {
                const start = expStarts[i] && expStarts[i].value ? new Date(expStarts[i].value).toLocaleDateString('en-US', { year: 'numeric', month: 'short' }) : '';
                const end = expEnds[i] && expEnds[i].value ? new Date(expEnds[i].value).toLocaleDateString('en-US', { year: 'numeric', month: 'short' }) : 'Present';
                const pos = expPositions[i] ? expPositions[i].value : '';
                const loc = expLocations[i] ? expLocations[i].value : '';
                const desc = expDescs[i] ? expDescs[i].value : '';
                
                expHtml += `
                    <div class="mb-3">
                        <div class="d-flex justify-content-between font-heading">
                            <strong class="text-body-emphasis">${pos} - ${expCompanies[i].value}</strong>
                            <span class="text-muted small">${start} - ${end}</span>
                        </div>
                        <div class="text-muted small">${loc}</div>
                        <div class="mt-1">${formatBullets(desc)}</div>
                    </div>
                `;
            }
        }
        if (expHtml) expHtml = `<h2>Professional Experience</h2>` + expHtml;

        // Gather Education
        let eduHtml = "";
        const eduInsts = resumeForm.querySelectorAll("[name='edu_institution[]']");
        const eduDegrees = resumeForm.querySelectorAll("[name='edu_degree[]']");
        const eduFields = resumeForm.querySelectorAll("[name='edu_field[]']");
        const eduStarts = resumeForm.querySelectorAll("[name='edu_start[]']");
        const eduEnds = resumeForm.querySelectorAll("[name='edu_end[]']");
        const eduDescs = resumeForm.querySelectorAll("[name='edu_desc[]']");
        
        for (let i = 0; i < eduInsts.length; i++) {
            if (eduInsts[i] && eduInsts[i].value.trim() !== '') {
                const start = eduStarts[i] && eduStarts[i].value ? new Date(eduStarts[i].value).toLocaleDateString('en-US', { year: 'numeric' }) : '';
                const end = eduEnds[i] && eduEnds[i].value ? new Date(eduEnds[i].value).toLocaleDateString('en-US', { year: 'numeric' }) : 'Present';
                const degree = eduDegrees[i] ? eduDegrees[i].value : '';
                const field = eduFields[i] ? eduFields[i].value : '';
                const desc = eduDescs[i] ? eduDescs[i].value.trim() : '';
                
                eduHtml += `
                    <div class="mb-3.5">
                        <div class="d-flex justify-content-between font-heading">
                            <strong class="text-body-emphasis">${degree} in ${field}</strong>
                            <span class="text-muted small">${start} - ${end}</span>
                        </div>
                        <div class="text-secondary small">${eduInsts[i].value}</div>
                        ${desc ? `<p class="mt-1 small text-secondary mb-0" style="white-space: pre-wrap;">${desc}</p>` : ''}
                    </div>
                `;
            }
        }
        if (eduHtml) eduHtml = `<h2>Education</h2>` + eduHtml;

        // Gather Projects
        let projHtml = "";
        const projTitles = resumeForm.querySelectorAll("[name='proj_title[]']");
        const projTechs = resumeForm.querySelectorAll("[name='proj_tech[]']");
        const projDescs = resumeForm.querySelectorAll("[name='proj_desc[]']");
        const projLinks = resumeForm.querySelectorAll("[name='proj_link[]']");
        
        for (let i = 0; i < projTitles.length; i++) {
            if (projTitles[i] && projTitles[i].value.trim() !== '') {
                const tech = projTechs[i] ? projTechs[i].value : '';
                const desc = projDescs[i] ? projDescs[i].value : '';
                const link = projLinks[i] ? projLinks[i].value : '';
                
                projHtml += `
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <strong class="text-body-emphasis">${projTitles[i].value}</strong>
                            ${link ? `<a href="${link}" target="_blank" class="small text-decoration-none"><i class="bi bi-link-45deg"></i> Link</a>` : ''}
                        </div>
                        <div class="text-secondary small font-heading">Tech: ${tech}</div>
                        <div class="mt-1">${formatBullets(desc)}</div>
                    </div>
                `;
            }
        }
        if (projHtml) projHtml = `<h2>Projects</h2>` + projHtml;

        // Gather Skills
        let skillsHtml = "";
        const skillNames = resumeForm.querySelectorAll(".skill-name-field");
        const skillTypes = resumeForm.querySelectorAll("[name='skill_type[]']");
        const skillLevels = resumeForm.querySelectorAll("[name='skill_level[]']");
        
        let skillsGroup = { technical: [], soft: [], language: [] };
        for (let i = 0; i < skillNames.length; i++) {
            if (skillNames[i] && skillNames[i].value.trim() !== '') {
                const type = skillTypes[i] ? skillTypes[i].value : 'technical';
                const level = skillLevels[i] ? skillLevels[i].value : 'Intermediate';
                if (!skillsGroup[type]) {
                    skillsGroup[type] = [];
                }
                skillsGroup[type].push(`${skillNames[i].value} (${level})`);
            }
        }
        
        if (skillsGroup.technical.length > 0) skillsHtml += `<div class="mb-2"><strong class="small text-uppercase text-secondary">Technical Skills:</strong> <span class="small">${skillsGroup.technical.join(', ')}</span></div>`;
        if (skillsGroup.soft.length > 0) skillsHtml += `<div class="mb-2"><strong class="small text-uppercase text-secondary">Soft Skills:</strong> <span class="small">${skillsGroup.soft.join(', ')}</span></div>`;
        if (skillsGroup.language.length > 0) skillsHtml += `<div class="mb-2"><strong class="small text-uppercase text-secondary">Languages:</strong> <span class="small">${skillsGroup.language.join(', ')}</span></div>`;
        
        if (skillsHtml) skillsHtml = `<h2>Skills</h2>` + skillsHtml;

        // Gather Certificates
        let certHtml = "";
        const certNames = resumeForm.querySelectorAll("[name='cert_name[]']");
        const certIssuers = resumeForm.querySelectorAll("[name='cert_issuer[]']");
        const certDates = resumeForm.querySelectorAll("[name='cert_date[]']");
        
        for (let i = 0; i < certNames.length; i++) {
            if (certNames[i] && certNames[i].value.trim() !== '') {
                const issuer = certIssuers[i] ? certIssuers[i].value : '';
                const date = certDates[i] && certDates[i].value ? new Date(certDates[i].value).toLocaleDateString('en-US', { year: 'numeric', month: 'short' }) : '';
                certHtml += `
                    <div class="mb-2 small d-flex justify-content-between">
                        <span><strong>${certNames[i].value}</strong> - <span class="text-secondary">${issuer}</span></span>
                        <span class="text-muted">${date}</span>
                    </div>
                `;
            }
        }
        if (certHtml) certHtml = `<h2>Certifications</h2>` + certHtml;

        // Gather Achievements
        let achHtml = "";
        const achTitles = resumeForm.querySelectorAll("[name='ach_title[]']");
        const achDates = resumeForm.querySelectorAll("[name='ach_date[]']");
        const achDescs = resumeForm.querySelectorAll("[name='ach_desc[]']");
        
        for (let i = 0; i < achTitles.length; i++) {
            if (achTitles[i] && achTitles[i].value.trim() !== '') {
                const date = achDates[i] && achDates[i].value ? new Date(achDates[i].value).toLocaleDateString('en-US', { year: 'numeric', month: 'short' }) : '';
                const desc = achDescs[i] ? achDescs[i].value : '';
                achHtml += `
                    <div class="mb-3">
                        <div class="d-flex justify-content-between font-heading small">
                            <strong>${achTitles[i].value}</strong>
                            <span class="text-muted">${date}</span>
                        </div>
                        <p class="small text-secondary mb-0">${desc}</p>
                    </div>
                `;
            }
        }
        if (achHtml) achHtml = `<h2>Achievements</h2>` + achHtml;
        
        let hobbiesHtml = hobbies ? `<h2>Hobbies</h2><p class="small mb-0">${hobbies}</p>` : '';

        // Strengths badges for preview
        let strengthsHtml2 = '';
        if (strengths && strengths.trim()) {
            const sArr = strengths.split(',').map(s => s.trim()).filter(Boolean);
            if (sArr.length) {
                const badges = sArr.map(s => `<span class="resume-strength-badge">${s}</span>`).join('');
                strengthsHtml2 = `<h2>Core Strengths</h2><div class="resume-strengths-wrap">${badges}</div>`;
            }
        }

        // Signature for preview
        const sigData = getVal("[name='signature_data']");
        let sigHtml = '';
        if (sigData && sigData.trim()) {
            const today = new Date().toLocaleDateString('en-IN', {day:'2-digit', month:'short', year:'numeric'});
            let sigContent;
            if (sigData.startsWith('data:image')) {
                sigContent = `<img src="${sigData}" alt="Signature" class="resume-sig-img">`;
            } else {
                sigContent = `<span class="resume-sig-typed">${sigData}</span>`;
            }
            sigHtml = `<div class="resume-signature-block"><div class="resume-sig-inner">${sigContent}<div class="resume-sig-underline"></div><small class="resume-sig-name">${fullName}</small><small class="resume-sig-date">${today}</small></div></div>`;
        }

        // Combined Template Layout Structure
        const jobRoleVal = getVal("[name='target_job_role']", "Software Engineer");
        previewContainer.innerHTML = `
            <div class="header-section text-center">
                <h1 class="mb-1 fw-bold text-gradient font-heading">${fullName}</h1>
                <h4 class="text-secondary fw-semibold font-heading mb-3">${jobRoleVal}</h4>
                ${contactHtml}
            </div>
            <div class="mt-4">
                <p class="small mb-4" style="white-space: pre-wrap;">${summary}</p>
                <div class="row g-4">
                    <div class="col-md-7 border-end border-secondary border-opacity-10 pe-md-4">
                        ${expHtml}
                        ${projHtml}
                    </div>
                    <div class="col-md-5 ps-md-4">
                        ${eduHtml}
                        ${strengthsHtml2}
                        ${skillsHtml}
                        ${certHtml}
                        ${achHtml}
                        ${hobbiesHtml}
                    </div>
                </div>
                ${sigHtml}
            </div>
        `;
    };

    // 3. AI Integrations in Wizard
    const bindAIButtons = (parent = document) => {
        parent.querySelectorAll(".ai-rewrite-btn").forEach(btn => {
            btn.onclick = async () => {
                const card = btn.closest(".entry-card");
                const textarea = card.querySelector(".description-textarea");
                const text = textarea.value.trim();
                
                if (!text) {
                    alert("Please enter some starter details to rewrite.");
                    return;
                }

                btn.disabled = true;
                btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Processing...';
                
                try {
                    const response = await fetch(APP_URL + "/ai_generate.php", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                            action: "rewrite_text",
                            text: text
                        })
                    });
                    const data = await response.json();
                    if (data.error) {
                        alert(data.error);
                    } else {
                        textarea.value = data.result;
                        updatePreview();
                    }
                } catch(e) {
                    alert("Failed to reach Gemini API.");
                } finally {
                    btn.disabled = false;
                    btn.innerHTML = '<i class="bi bi-magic"></i> Improve';
                }
            };
        });
    };

    // 4. Voice Input binding helper
    const bindVoiceButtons = (parent = document) => {
        parent.querySelectorAll(".voice-field-btn").forEach(btn => {
            btn.onclick = () => {
                const card = btn.closest(".entry-card");
                const textarea = card.querySelector(".description-textarea");
                window.voiceRecognizer.start(btn, textarea);
            };
        });
    };

    // Summary AI Generator
    const btnGenSummary = document.getElementById("btnGenSummary");
    if (btnGenSummary) {
        btnGenSummary.onclick = async () => {
            const role = resumeForm.querySelector("[name='target_job_role']").value;
            
            // Collect experience text & skills
            const expDescs = Array.from(resumeForm.querySelectorAll("[name='exp_desc[]']")).map(e => e.value).join(" ");
            const skillNames = Array.from(resumeForm.querySelectorAll(".skill-name-field")).map(s => s.value).join(", ");
            
            btnGenSummary.disabled = true;
            btnGenSummary.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Creating...';
            
            try {
                const response = await fetch(APP_URL + "/ai_generate.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        action: "generate_summary",
                        target_role: role,
                        skills: skillNames,
                        experience: expDescs
                    })
                });
                const data = await response.json();
                if (data.error) {
                    alert(data.error);
                } else {
                    document.getElementById("summaryTextarea").value = data.result;
                    updatePreview();
                }
            } catch(e) {
                alert("Network error.");
            } finally {
                btnGenSummary.disabled = false;
                btnGenSummary.innerHTML = '<i class="bi bi-magic me-1"></i> Write with AI';
            }
        };
    }

    // Bind summary microphone button
    const voiceSummaryBtn = document.getElementById("voiceSummaryBtn");
    if (voiceSummaryBtn) {
        voiceSummaryBtn.onclick = () => {
            window.voiceRecognizer.start(voiceSummaryBtn, document.getElementById("summaryTextarea"));
        };
    }

    // AI Skill Recommender
    const btnRecSkills = document.getElementById("btnRecSkills");
    const aiSkillsDiv = document.getElementById("aiSkillSuggestions");
    const aiSkillsList = document.getElementById("aiSkillsList");

    if (btnRecSkills) {
        btnRecSkills.onclick = async () => {
            const skillNames = Array.from(resumeForm.querySelectorAll(".skill-name-field")).map(s => s.value).filter(v => v !== "").join(", ");
            btnRecSkills.disabled = true;
            
            try {
                const response = await fetch(APP_URL + "/ai_generate.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        action: "recommend_skills",
                        skills: skillNames
                    })
                });
                const recommendedArray = await response.json();
                
                if (Array.isArray(recommendedArray)) {
                    aiSkillsList.innerHTML = "";
                    recommendedArray.forEach(sk => {
                        const badge = document.createElement("span");
                        badge.className = "badge bg-purple-gradient text-white px-2.5 py-1.5 rounded cursor-pointer animate-fade-in";
                        badge.style.cursor = "pointer";
                        badge.style.background = "var(--primary-gradient)";
                        badge.innerHTML = `<i class="bi bi-plus-lg me-1"></i> ${sk}`;
                        
                        badge.onclick = () => {
                            // Add skill row
                            const container = document.getElementById("skillsContainer");
                            const temp = document.getElementById("skillTemplate").firstElementChild.cloneNode(true);
                            temp.querySelector(".skill-name-field").value = sk;
                            container.appendChild(temp);
                            bindRemovers();
                            badge.remove();
                            updatePreview();
                        };
                        aiSkillsList.appendChild(badge);
                    });
                    aiSkillsDiv.classList.remove("d-none");
                }
            } catch(e) {
                console.error(e);
            } finally {
                btnRecSkills.disabled = false;
            }
        };
    }

    // 5. QR Code Generator
    const btnGenQR = document.getElementById("btnGenQR");
    const qrContainer = document.getElementById("qrContainer");
    const qrTarget = document.getElementById("qrTarget");

    if (btnGenQR) {
        btnGenQR.onclick = () => {
            qrTarget.innerHTML = "";
            const shareUrl = APP_URL + "/share.php?token=<?php echo $resume['share_token']; ?>";
            
            new QRCode(qrTarget, {
                text: shareUrl,
                width: 140,
                height: 140,
                colorDark : "#0f172a",
                colorLight : "#ffffff",
                correctLevel : QRCode.CorrectLevel.H
            });
            qrContainer.classList.remove("d-none");
            qrContainer.scrollIntoView({ behavior: 'smooth' });
        };
    }

    // ============================================================
    // STRENGTHS TAG CHIP MANAGER
    // ============================================================
    const strengthsHiddenInput = document.getElementById('strengthsHiddenInput');
    const strengthsTagContainer = document.getElementById('strengthsTagContainer');
    const strengthTagInput = document.getElementById('strengthTagInput');
    const addStrengthBtn = document.getElementById('addStrengthBtn');
    const strengthsPreviewInSkills = document.getElementById('strengthsPreviewInSkills');

    function getStrengthsArray() {
        return strengthsHiddenInput && strengthsHiddenInput.value
            ? strengthsHiddenInput.value.split(',').map(s => s.trim()).filter(Boolean)
            : [];
    }

    function syncStrengths(arr) {
        if (!strengthsHiddenInput) return;
        strengthsHiddenInput.value = arr.join(', ');
        renderStrengthTags(arr);
        updatePreview();
    }

    function renderStrengthTags(arr) {
        if (!strengthsTagContainer) return;
        strengthsTagContainer.innerHTML = arr.map((s, i) => `
            <span class="strength-chip animate-fade-in">
                ${s}
                <button type="button" class="strength-chip-remove" data-idx="${i}" title="Remove">&times;</button>
            </span>`).join('');
        strengthsTagContainer.querySelectorAll('.strength-chip-remove').forEach(btn => {
            btn.onclick = () => {
                const arr2 = getStrengthsArray();
                arr2.splice(parseInt(btn.dataset.idx), 1);
                syncStrengths(arr2);
            };
        });
        // Also update the Skills tab preview
        if (strengthsPreviewInSkills) {
            strengthsPreviewInSkills.innerHTML = arr.length
                ? arr.map(s => `<span class="resume-strength-badge">${s}</span>`).join('')
                : '<small class="text-secondary">No strengths added yet.</small>';
        }
    }

    function addStrength(val) {
        if (!val || !val.trim()) return;
        const arr = getStrengthsArray();
        const trimmed = val.trim();
        if (!arr.includes(trimmed)) {
            arr.push(trimmed);
            syncStrengths(arr);
        }
        if (strengthTagInput) strengthTagInput.value = '';
    }

    if (addStrengthBtn) {
        addStrengthBtn.onclick = () => addStrength(strengthTagInput ? strengthTagInput.value : '');
    }
    if (strengthTagInput) {
        strengthTagInput.addEventListener('keydown', e => {
            if (e.key === 'Enter') { e.preventDefault(); addStrength(strengthTagInput.value); }
        });
    }
    // Suggestion badges clickable
    document.querySelectorAll('.strength-suggestion').forEach(badge => {
        badge.onclick = () => addStrength(badge.textContent.trim());
    });

    // Initialise tags from pre-filled hidden value (page load)
    renderStrengthTags(getStrengthsArray());

    // ============================================================
    // SIGNATURE PAD (Canvas draw + Typed mode)
    // ============================================================
    const sigCanvas = document.getElementById('signatureCanvas');
    const sigDataInput = document.getElementById('signatureDataInput');
    const sigDrawArea = document.getElementById('sigDrawArea');
    const sigTypedArea = document.getElementById('sigTypedArea');
    const sigTypedInput = document.getElementById('sigTypedInput');
    const clearSigBtn = document.getElementById('clearSigBtn');
    let sigMode = 'drawn';
    let isDrawing = false;
    let lastX = 0, lastY = 0;

    // Switch between draw/typed modes
    window.switchSigMode = (mode) => {
        sigMode = mode;
        if (mode === 'drawn') {
            sigDrawArea && sigDrawArea.classList.remove('d-none');
            sigTypedArea && sigTypedArea.classList.add('d-none');
        } else {
            sigTypedArea && sigTypedArea.classList.remove('d-none');
            sigDrawArea && sigDrawArea.classList.add('d-none');
        }
    };

    // Load existing signature on page load
    if (sigCanvas && sigDataInput && sigDataInput.value && sigDataInput.value.startsWith('data:image')) {
        const img = new Image();
        img.onload = () => { sigCanvas.getContext('2d').drawImage(img, 0, 0); };
        img.src = sigDataInput.value;
    }
    if (sigTypedInput && sigDataInput && sigDataInput.value && !sigDataInput.value.startsWith('data:image')) {
        sigTypedInput.value = sigDataInput.value;
    }

    // Canvas drawing
    if (sigCanvas) {
        const ctx = sigCanvas.getContext('2d');
        ctx.strokeStyle = '#1a1a2e';
        ctx.lineWidth = 2.2;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        const getPos = (e) => {
            const rect = sigCanvas.getBoundingClientRect();
            const scaleX = sigCanvas.width / rect.width;
            const scaleY = sigCanvas.height / rect.height;
            if (e.touches) {
                return [(e.touches[0].clientX - rect.left) * scaleX, (e.touches[0].clientY - rect.top) * scaleY];
            }
            return [(e.clientX - rect.left) * scaleX, (e.clientY - rect.top) * scaleY];
        };

        const startDraw = (e) => { e.preventDefault(); isDrawing = true; [lastX, lastY] = getPos(e); };
        const draw = (e) => {
            if (!isDrawing) return;
            e.preventDefault();
            const [x, y] = getPos(e);
            ctx.beginPath();
            ctx.moveTo(lastX, lastY);
            ctx.lineTo(x, y);
            ctx.stroke();
            [lastX, lastY] = [x, y];
        };
        const endDraw = () => {
            if (!isDrawing) return;
            isDrawing = false;
            // Save to hidden input
            if (sigDataInput) {
                sigDataInput.value = sigCanvas.toDataURL('image/png');
                updatePreview();
            }
        };

        sigCanvas.addEventListener('mousedown', startDraw);
        sigCanvas.addEventListener('mousemove', draw);
        sigCanvas.addEventListener('mouseup', endDraw);
        sigCanvas.addEventListener('mouseleave', endDraw);
        sigCanvas.addEventListener('touchstart', startDraw, {passive:false});
        sigCanvas.addEventListener('touchmove', draw, {passive:false});
        sigCanvas.addEventListener('touchend', endDraw);
    }

    // Typed signature input
    if (sigTypedInput && sigDataInput) {
        sigTypedInput.addEventListener('input', () => {
            sigDataInput.value = sigTypedInput.value;
            updatePreview();
        });
    }

    // Clear signature
    if (clearSigBtn) {
        clearSigBtn.onclick = () => {
            if (sigCanvas) { sigCanvas.getContext('2d').clearRect(0, 0, sigCanvas.width, sigCanvas.height); }
            if (sigTypedInput) sigTypedInput.value = '';
            if (sigDataInput) sigDataInput.value = '';
            updatePreview();
        };
    }

    // Form binding changes to trigger preview updates in real-time
    resumeForm.addEventListener("input", updatePreview);
    styleSelector.addEventListener("change", updatePreview);

    // Initial triggers
    bindRemovers();
    bindAIButtons();
    bindVoiceButtons();
    updatePreview();

    // Auto-trigger print/PDF download if requested in URL
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('print')) {
        document.fonts.ready.then(() => {
            setTimeout(() => {
                window.print();
            }, 300);
        });
    }
});

</script>

<?php require_once 'includes/footer.php';


?>