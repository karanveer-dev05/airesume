<?php
// login.php - Secure User Login Page

require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Handle Logout action
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    logout_user();
}

// Redirect if already logged in
if (is_logged_in()) {
    header("Location: dashboard.php");
    exit;
}

$error_msg = "";
$success_msg = "";

if (isset($_GET['registered'])) {
    $success_msg = "Account created successfully! Please log in.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identity = trim($_POST['identity'] ?? ''); // Can be email or username
    $password = $_POST['password'] ?? '';

    if (empty($identity) || empty($password)) {
        $error_msg = "Both fields are required.";
    } else {
        $db = getDBConnection();
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$identity, $identity]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            // Success: Login user
            login_user($user['id'], $user['username'], $user['role']);
            
            // Redirect to dashboard
            header("Location: dashboard.php");
            exit;
        } else {
            $error_msg = "Invalid username/email or password.";
        }
    }
}

$page_title = "Welcome Back";
require_once 'includes/header.php';
?>

<div class="container d-flex align-items-center justify-content-center" style="min-height: calc(100vh - 120px); padding-top: 80px;">
    <div class="row w-100 justify-content-center">
        <div class="col-md-6 col-lg-5 col-xl-4">
            <div class="card glass-card p-4 animate-fade-in">
                <div class="card-body">
                    <div class="text-center mb-4">
                        <i class="bi bi-person-workspace text-gradient fs-1"></i>
                        <h2 class="fw-bold mt-2">Welcome Back</h2>
                        <p class="text-secondary">Sign in to your account</p>
                    </div>

                    <?php if ($error_msg): ?>
                        <div class="alert alert-danger d-flex align-items-center py-2" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i>
                            <div><?php echo htmlspecialchars($error_msg); ?></div>
                        </div>
                    <?php endif; ?>

                    <?php if ($success_msg): ?>
                        <div class="alert alert-success d-flex align-items-center py-2" role="alert">
                            <i class="bi bi-check-circle-fill me-2"></i>
                            <div><?php echo htmlspecialchars($success_msg); ?></div>
                        </div>
                    <?php endif; ?>

                    <form action="login.php" method="POST" novalidate>
                        <div class="mb-3">
                            <label for="identity" class="form-label">Username or Email</label>
                            <div class="input-group">
                                <span class="input-group-text bg-transparent border-end-0"><i class="bi bi-person text-secondary"></i></span>
                                <input type="text" class="form-control border-start-0" id="identity" name="identity" value="<?php echo htmlspecialchars($_POST['identity'] ?? ''); ?>" required placeholder="username or email">
                            </div>
                        </div>

                        <div class="mb-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <label for="password" class="form-label mb-0">Password</label>
                                <a href="forgot_password.php" class="text-gradient small text-decoration-none fw-bold">Forgot Password?</a>
                            </div>
                            <div class="input-group">
                                <span class="input-group-text bg-transparent border-end-0"><i class="bi bi-lock text-secondary"></i></span>
                                <input type="password" class="form-control border-start-0" id="password" name="password" required placeholder="••••••••">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-gradient w-100 py-2 mb-3">Sign In</button>
                    </form>

                    <div class="text-center mt-3">
                        <span class="text-secondary small">Don't have an account?</span>
                        <a href="register.php" class="text-gradient fw-bold small ms-1 text-decoration-none">Sign Up</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
