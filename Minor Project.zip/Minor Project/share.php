<?php
// share.php - Public Resume Sharing Landing Page (Recruiter Mode)

require_once 'includes/config.php';
require_once 'includes/db.php';

// Helper function to format text lines into HTML lists
function formatResumeBullets($text) {
    if (empty($text)) return "";
    $lines = explode("\n", $text);
    $hasBullets = false;
    
    $formattedLines = [];
    foreach ($lines as $line) {
        $trimmed = trim($line);
        if (strpos($trimmed, '-') === 0 || strpos($trimmed, '*') === 0 || strpos($trimmed, '•') === 0) {
            $hasBullets = true;
            // Remove first character and trim
            $content = trim(mb_substr($trimmed, 1));
            $formattedLines[] = "<li>" . htmlspecialchars($content) . "</li>";
        } else {
            $formattedLines[] = htmlspecialchars($line);
        }
    }
    
    if ($hasBullets) {
        $html = "";
        $inList = false;
        foreach ($formattedLines as $line) {
            if (strpos($line, '<li>') === 0) {
                if (!$inList) {
                    $html .= '<ul class="resume-bullet-list mb-2">';
                    $inList = true;
                }
                $html .= $line;
            } else {
                if ($inList) {
                    $html .= '</ul>';
                    $inList = false;
                }
                if (trim($line) !== '') {
                    $html .= '<p class="mb-1 small">' . $line . '</p>';
                }
            }
        }
        if ($inList) {
            $html .= '</ul>';
        }
        return $html;
    } else {
        return '<p class="mb-0 small" style="white-space: pre-wrap;">' . htmlspecialchars($text) . '</p>';
    }
}

$db = getDBConnection();
$token = $_GET['token'] ?? '';

if (empty($token)) {
    die("Error: Invalid or missing secure sharing token.");
}

// Fetch resume details based on share token
$stmt = $db->prepare("SELECT * FROM resumes WHERE share_token = ?");
$stmt->execute([$token]);
$resume = $stmt->fetch();

if (!$resume) {
    die("Error: The requested resume was not found or has been deleted.");
}

$resumeId = $resume['id'];

// Fetch all resume children
$stmt = $db->prepare("SELECT * FROM education WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$education = $stmt->fetchAll();

$stmt = $db->prepare("SELECT * FROM experience WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$experience = $stmt->fetchAll();

$stmt = $db->prepare("SELECT * FROM projects WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$projects = $stmt->fetchAll();

$stmt = $db->prepare("SELECT * FROM skills WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$skills = $stmt->fetchAll();

$stmt = $db->prepare("SELECT * FROM certificates WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$certificates = $stmt->fetchAll();

$stmt = $db->prepare("SELECT * FROM achievements WHERE resume_id = ?");
$stmt->execute([$resumeId]);
$achievements = $stmt->fetchAll();

// Handle review submission
$success_msg = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_review']) && ($resume['recruiter_comments_enabled'] ?? false)) {
    $recruiterName = trim($_POST['recruiter_name'] ?: 'Anonymous Recruiter');
    $rating = intval($_POST['rating']);
    $comments = trim($_POST['comments']);
    
    if ($rating >= 1 && $rating <= 5 && !empty($comments)) {
        $stmt = $db->prepare("INSERT INTO recruiter_reviews (resume_id, recruiter_name, rating, comments) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$resumeId, $recruiterName, $rating, $comments])) {
            $success_msg = "Your feedback has been successfully posted. Thank you!";
        }
    }
}

// Fetch other reviews
$reviewStmt = $db->prepare("SELECT * FROM recruiter_reviews WHERE resume_id = ? ORDER BY created_at DESC");
$reviewStmt->execute([$resumeId]);
$reviews = $reviewStmt->fetchAll();

// Setup print CSS and classes based on style selection
$templateStyle = $resume['template_style'] ?? 'modern';

$page_title = "Online Resume - " . ($resume['full_name'] ?? 'Guest');
require_once 'includes/header.php';
?>

<!-- Action controls bar (Only visible on web, hidden on print) -->
<div class="container py-4 mt-5 no-print">
    <div class="card glass-card p-3 mb-4 d-flex flex-row flex-wrap justify-content-between align-items-center gap-3">
        <div>
            <h5 class="fw-bold mb-0 text-gradient">Recruiter Mode Portal</h5>
            <small class="text-secondary">You are viewing the secure online resume of <strong><?php echo htmlspecialchars($resume['full_name'] ?? ''); ?></strong>.</small>
        </div>
        <div class="d-flex gap-2">
            <button class="btn btn-outline-gradient btn-sm" onclick="window.print();">
                <i class="bi bi-printer-fill me-1"></i> Print / PDF Copy
            </button>
            <a href="portfolio.php?id=<?php echo $resumeId; ?>&preview=1" class="btn btn-gradient btn-sm" target="_blank">
                <i class="bi bi-globe me-1"></i> Open Portfolio Site
            </a>
        </div>
    </div>
</div>

<!-- Print target resume page container -->
<div class="container print-container">
    <div id="resumePreview" class="resume-preview-container template-<?php echo htmlspecialchars($templateStyle); ?>">
        <div class="header-section text-center">
            <h1 class="mb-1 fw-bold text-gradient font-heading"><?php echo htmlspecialchars($resume['full_name'] ?? ''); ?></h1>
            <h4 class="text-secondary fw-semibold font-heading mb-3"><?php echo htmlspecialchars($resume['target_job_role'] ?? ''); ?></h4>
            
            <div class="d-flex flex-wrap gap-3 justify-content-center align-items-center border-bottom pb-3 small mb-3 border-secondary border-opacity-10 text-muted">
                <span class="d-inline-flex align-items-center gap-1"><i class="bi bi-envelope"></i> <?php echo htmlspecialchars($resume['email'] ?? ''); ?></span>
                <span class="d-inline-flex align-items-center gap-1"><i class="bi bi-phone"></i> <?php echo htmlspecialchars($resume['phone'] ?? ''); ?></span>
                <?php if (!empty($resume['address'])): ?>
                    <span class="d-inline-flex align-items-center gap-1"><i class="bi bi-geo-alt"></i> <?php echo htmlspecialchars($resume['address'] ?? ''); ?></span>
                <?php endif; ?>
                <?php if (!empty($resume['linkedin'])): ?>
                    <span class="d-inline-flex align-items-center gap-1"><i class="bi bi-linkedin"></i> <?php echo htmlspecialchars($resume['linkedin'] ?? ''); ?></span>
                <?php endif; ?>
                <?php if (!empty($resume['github'])): ?>
                    <span class="d-inline-flex align-items-center gap-1"><i class="bi bi-github"></i> <?php echo htmlspecialchars($resume['github'] ?? ''); ?></span>
                <?php endif; ?>
                <?php if (!empty($resume['portfolio'])): ?>
                    <span class="d-inline-flex align-items-center gap-1"><i class="bi bi-globe"></i> <?php echo htmlspecialchars($resume['portfolio'] ?? ''); ?></span>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="mt-4">
            <p class="small mb-4" style="white-space: pre-wrap;"><?php echo htmlspecialchars($resume['summary'] ?? ''); ?></p>
            
            <div class="row g-4">
                <!-- Left column: Experience & Projects -->
                <div class="col-md-7 border-end border-secondary border-opacity-10 pe-md-4">
                    <?php if (count($experience) > 0): ?>
                        <h2>Professional Experience</h2>
                        <?php foreach ($experience as $exp): ?>
                            <div class="mb-3">
                                <div class="d-flex justify-content-between font-heading">
                                    <strong class="text-body-emphasis"><?php echo htmlspecialchars($exp['position'] ?? ''); ?> - <?php echo htmlspecialchars($exp['company'] ?? ''); ?></strong>
                                    <span class="text-muted small">
                                        <?php 
                                        $start = !empty($exp['start_date']) ? date('M Y', strtotime($exp['start_date'])) : '';
                                        $end = !empty($exp['end_date']) ? date('M Y', strtotime($exp['end_date'])) : 'Present';
                                        echo htmlspecialchars($start . ($start && $end ? ' - ' : '') . $end);
                                        ?>
                                    </span>
                                </div>
                                <div class="text-muted small"><?php echo htmlspecialchars($exp['location'] ?? 'Remote'); ?></div>
                                <div class="mt-1"><?php echo formatResumeBullets($exp['description'] ?? ''); ?></div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <?php if (count($projects) > 0): ?>
                        <h2 class="mt-4">Projects</h2>
                        <?php foreach ($projects as $proj): ?>
                            <div class="mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <strong class="text-body-emphasis"><?php echo htmlspecialchars($proj['title'] ?? ''); ?></strong>
                                    <?php if (!empty($proj['link'])): ?>
                                        <a href="<?php echo htmlspecialchars($proj['link']); ?>" target="_blank" class="small text-decoration-none"><i class="bi bi-link-45deg"></i> Link</a>
                                    <?php endif; ?>
                                </div>
                                <div class="text-secondary small font-heading">Tech: <?php echo htmlspecialchars($proj['technologies'] ?? ''); ?></div>
                                <div class="mt-1"><?php echo formatResumeBullets($proj['description'] ?? ''); ?></div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Right column: Education, Skills, Certificates, Achievements -->
                <div class="col-md-5 ps-md-4">
                    <?php if (count($education) > 0): ?>
                        <h2>Education</h2>
                        <?php foreach ($education as $edu): ?>
                            <div class="mb-3">
                                <div class="d-flex justify-content-between font-heading">
                                    <strong class="text-body-emphasis"><?php echo htmlspecialchars($edu['degree'] ?? ''); ?> in <?php echo htmlspecialchars($edu['field_of_study'] ?? ''); ?></strong>
                                    <span class="text-muted small">
                                        <?php 
                                        $start = !empty($edu['start_date']) ? date('Y', strtotime($edu['start_date'])) : '';
                                        $end = !empty($edu['end_date']) ? date('Y', strtotime($edu['end_date'])) : 'Present';
                                        echo htmlspecialchars($start . ($start && $end ? ' - ' : '') . $end);
                                        ?>
                                    </span>
                                </div>
                                <div class="text-secondary small"><?php echo htmlspecialchars($edu['institution'] ?? ''); ?></div>
                                <?php if (!empty($edu['description'])): ?>
                                    <p class="mt-1 small text-secondary mb-0" style="white-space: pre-wrap;"><?php echo htmlspecialchars($edu['description']); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <?php if (count($skills) > 0): ?>
                        <h2 class="mt-4">Skills</h2>
                        <?php 
                        $groups = ['technical' => [], 'soft' => [], 'language' => []];
                        foreach ($skills as $s) {
                            $type = $s['skill_type'] ?? 'technical';
                            if (!isset($groups[$type])) {
                                $groups[$type] = [];
                            }
                            $groups[$type][] = ($s['name'] ?? '') . " (" . ($s['level'] ?? 'Intermediate') . ")";
                        }
                        ?>
                        <?php if (count($groups['technical']) > 0): ?>
                            <div class="mb-2"><strong class="small text-uppercase text-secondary">Technical:</strong> <span class="small"><?php echo implode(', ', $groups['technical']); ?></span></div>
                        <?php endif; ?>
                        <?php if (count($groups['soft']) > 0): ?>
                            <div class="mb-2"><strong class="small text-uppercase text-secondary">Soft:</strong> <span class="small"><?php echo implode(', ', $groups['soft']); ?></span></div>
                        <?php endif; ?>
                        <?php if (count($groups['language']) > 0): ?>
                            <div class="mb-2"><strong class="small text-uppercase text-secondary">Languages:</strong> <span class="small"><?php echo implode(', ', $groups['language']); ?></span></div>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if (count($certificates) > 0): ?>
                        <h2 class="mt-4">Certifications</h2>
                        <?php foreach ($certificates as $cert): ?>
                            <div class="mb-2 small d-flex justify-content-between">
                                <span><strong><?php echo htmlspecialchars($cert['name'] ?? ''); ?></strong> - <span class="text-secondary"><?php echo htmlspecialchars($cert['issuer'] ?? ''); ?></span></span>
                                <span class="text-muted"><?php echo !empty($cert['issue_date']) ? date('Y', strtotime($cert['issue_date'])) : ''; ?></span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <?php if (count($achievements) > 0): ?>
                        <h2 class="mt-4">Achievements</h2>
                        <?php foreach ($achievements as $ach): ?>
                            <div class="mb-3">
                                <div class="d-flex justify-content-between font-heading small">
                                    <strong><?php echo htmlspecialchars($ach['title'] ?? ''); ?></strong>
                                    <span class="text-muted"><?php echo !empty($ach['date']) ? date('Y', strtotime($ach['date'])) : ''; ?></span>
                                </div>
                                <p class="small text-secondary mb-0"><?php echo htmlspecialchars($ach['description'] ?? ''); ?></p>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    
                    <?php if (!empty($resume['hobbies'])): ?>
                        <h2 class="mt-4">Hobbies</h2>
                        <p class="small mb-0"><?php echo htmlspecialchars($resume['hobbies']); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recruiter rating feedback segment (web only) -->
<?php if ($resume['recruiter_comments_enabled']): ?>
<div class="container py-5 no-print">
    <div class="row g-4">
        <!-- Review inputs -->
        <div class="col-md-6">
            <div class="card glass-card p-4">
                <h4 class="fw-bold mb-3 text-gradient"><i class="bi bi-star-half me-2"></i>Rate this Applicant</h4>
                
                <?php if ($success_msg): ?>
                    <div class="alert alert-success py-2.5 small"><?php echo htmlspecialchars($success_msg); ?></div>
                <?php endif; ?>
                
                <form action="share.php?token=<?php echo htmlspecialchars($token); ?>" method="POST">
                    <input type="hidden" name="action_review" value="1">
                    
                    <div class="mb-3">
                        <label class="form-label small">Your Name / Organization</label>
                        <input type="text" class="form-control" name="recruiter_name" placeholder="Hiring Manager at Google" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label small">Rating Scale</label>
                        <select class="form-select" name="rating">
                            <option value="5">★★★★★ Excellent (5/5)</option>
                            <option value="4" selected>★★★★ Good Fit (4/5)</option>
                            <option value="3">★★★ Average (3/5)</option>
                            <option value="2">★★ Below Par (2/5)</option>
                            <option value="1">★ Critical gaps (1/5)</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label small">Recruiter Notes / Comments</label>
                        <textarea class="form-control" name="comments" rows="3" placeholder="Suggest improvements or schedule interviews..." required></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-gradient w-100 py-2.5">Post Evaluation</button>
                </form>
            </div>
        </div>
        
        <!-- Logged comment history list -->
        <div class="col-md-6">
            <div class="card glass-card p-4 h-100">
                <h4 class="fw-bold mb-3 text-gradient"><i class="bi bi-chat-left-text me-2"></i>Recruiter Remarks (<?php echo count($reviews); ?>)</h4>
                
                <div style="max-height: 380px; overflow-y: auto;">
                    <?php if (count($reviews) === 0): ?>
                        <p class="text-secondary small">No remarks left yet. Let the applicant know what you think!</p>
                    <?php else: ?>
                        <?php foreach ($reviews as $rev): ?>
                            <div class="border-bottom border-secondary border-opacity-10 pb-3 mb-3">
                                <div class="d-flex justify-content-between align-items-center small mb-1">
                                    <strong class="text-gradient"><?php echo htmlspecialchars($rev['recruiter_name']); ?></strong>
                                    <span class="text-warning"><?php echo str_repeat('★', $rev['rating']); ?></span>
                                </div>
                                <p class="small text-secondary mb-0"><?php echo htmlspecialchars($rev['comments']); ?></p>
                                <small class="text-muted" style="font-size: 0.75rem;"><i class="bi bi-clock me-1"></i><?php echo date('M d, Y', strtotime($rev['created_at'])); ?></small>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
