<?php
// cover_letter.php - AI Cover Letter Builder

require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Route guards
require_login();

define('SHOW_SIDEBAR', true);
$db = getDBConnection();
$userId = get_logged_in_user_id();

$resumeId = intval($_GET['id'] ?? 0);

if ($resumeId === 0) {
    // Fetch resumes
    $stmt = $db->prepare("SELECT * FROM resumes WHERE user_id = ? ORDER BY updated_at DESC");
    $stmt->execute([$userId]);
    $resumes = $stmt->fetchAll();
    
    $page_title = "Cover Letters";
    require_once 'includes/header.php';
    ?>
    <div class="row justify-content-center">
        <div class="col-md-8 text-center py-5">
            <i class="bi bi-envelope-paper text-gradient display-1 mb-3"></i>
            <h2 class="fw-bold Outfit">AI Cover Letter Generator</h2>
            <p class="text-secondary mb-4">Select a resume to use as context for your cover letter.</p>
            
            <?php if (count($resumes) === 0): ?>
                <div class="alert alert-warning glass-card py-3">
                    Please create a resume first. <a href="dashboard.php" class="alert-link text-decoration-none text-gradient fw-bold">Create Now</a>
                </div>
            <?php else: ?>
                <div class="list-group col-md-8 mx-auto shadow-sm rounded-3">
                    <?php foreach ($resumes as $res): ?>
                        <a href="cover_letter.php?id=<?php echo $res['id']; ?>" class="list-group-item list-group-item-action bg-transparent border-secondary border-opacity-10 py-3 text-start d-flex justify-content-between align-items-center">
                            <div>
                                <span class="fw-bold text-gradient d-block"><?php echo htmlspecialchars($res['title']); ?></span>
                                <small class="text-secondary"><?php echo htmlspecialchars($res['target_job_role']); ?></small>
                            </div>
                            <span class="btn btn-sm btn-gradient">Select <i class="bi bi-chevron-right small"></i></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
    require_once 'includes/footer.php';
    exit;
}

// Verify ownership
$stmt = $db->prepare("SELECT * FROM resumes WHERE id = ? AND user_id = ?");
$stmt->execute([$resumeId, $userId]);
$resume = $stmt->fetch();

if (!$resume) {
    header("Location: cover_letter.php?error=notfound");
    exit;
}

// Fetch generated cover letters history for this resume
$clStmt = $db->prepare("SELECT * FROM cover_letters WHERE resume_id = ? ORDER BY created_at DESC");
$clStmt->execute([$resumeId]);
$clHistory = $clStmt->fetchAll();

$page_title = "AI Cover Letter - " . $resume['title'];
require_once 'includes/header.php';
?>

<div class="row">
    <!-- Letter Request Form (Left) -->
    <div class="col-lg-5 mb-4 no-print">
        <div class="card glass-card p-4">
            <h4 class="fw-bold mb-3 text-gradient"><i class="bi bi-file-earmark-plus me-2"></i>Generate Cover Letter</h4>
            <p class="text-secondary small mb-4">Leverage Gemini AI to write a customized cover letter utilizing your resume's experiences and skills.</p>
            
            <form id="clForm">
                <input type="hidden" name="resume_id" value="<?php echo $resumeId; ?>">
                
                <div class="mb-3">
                    <label class="form-label">Target Company Name</label>
                    <input type="text" class="form-control" id="companyName" required placeholder="e.g. Google or OpenAI">
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Position / Job Title</label>
                    <input type="text" class="form-control" id="jobTitle" value="<?php echo htmlspecialchars($resume['target_job_role']); ?>" required>
                </div>
                
                <button type="submit" class="btn btn-gradient w-100 py-2.5 mt-2" id="btnGenLetter">
                    <i class="bi bi-cpu me-1"></i> Craft Letter with AI
                </button>
            </form>
            
            <hr class="my-4 text-muted">
            
            <h5 class="fw-bold mb-3 text-gradient"><i class="bi bi-clock-history me-2"></i>Saved Letters History</h5>
            <?php if (count($clHistory) === 0): ?>
                <p class="text-secondary small mb-0">No generated letters found for this resume.</p>
            <?php else: ?>
                <div class="list-group">
                    <?php foreach ($clHistory as $cl): ?>
                        <button type="button" class="list-group-item list-group-item-action bg-transparent border-secondary border-opacity-10 py-2.5 text-start px-2 d-flex justify-content-between align-items-center btn-view-history-cl" data-content="<?php echo htmlspecialchars($cl['content']); ?>">
                            <div>
                                <span class="fw-bold text-gradient small d-block"><?php echo htmlspecialchars($cl['company_name']); ?></span>
                                <small class="text-secondary small"><?php echo htmlspecialchars($cl['job_role']); ?> - <?php echo date('M d, Y', strtotime($cl['created_at'])); ?></small>
                            </div>
                            <i class="bi bi-file-text text-secondary"></i>
                        </button>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Visual Output Canvas (Right) -->
    <div class="col-lg-7 print-container">
        <div class="card glass-card p-4 h-100 d-flex flex-column">
            <div class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-4 no-print" style="border-color: var(--card-border) !important;">
                <h4 class="fw-bold mb-0 text-gradient"><i class="bi bi-file-earmark-richtext me-2"></i>Cover Letter View</h4>
                <div class="d-flex gap-2">
                    <button class="btn btn-sm btn-outline-secondary" id="btnCopyLetter" title="Copy to clipboard"><i class="bi bi-clipboard"></i> Copy</button>
                    <button class="btn btn-sm btn-outline-gradient" onclick="window.print();"><i class="bi bi-printer-fill"></i> Print / PDF</button>
                </div>
            </div>
            
            <!-- Target visual output -->
            <div class="flex-grow-1 p-3 rounded bg-white text-dark shadow-inner" style="min-height: 480px; font-family: 'Inter', sans-serif;">
                <div id="clOutput" style="white-space: pre-wrap; font-size: 0.95rem; line-height: 1.6;">
                    [Your letter will appear here after clicking generation or selecting history items...]
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
    const clForm = document.getElementById("clForm");
    const btnGen = document.getElementById("btnGenLetter");
    const outputDiv = document.getElementById("clOutput");
    const btnCopy = document.getElementById("btnCopyLetter");

    // Form generation handler
    if (clForm) {
        clForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            
            const company = document.getElementById("companyName").value.trim();
            const role = document.getElementById("jobTitle").value.trim();
            
            btnGen.disabled = true;
            btnGen.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status"></span> Generating letter...';
            outputDiv.innerHTML = "Creating a tailored cover letter using your resume profile, projects, and target role highlights. Please wait...";
            
            try {
                const response = await fetch(APP_URL + "/ai_generate.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        action: "generate_cover_letter",
                        resume_id: <?php echo $resumeId; ?>,
                        company_name: company,
                        job_role: role
                    })
                });
                const data = await response.json();
                
                if (data.error) {
                    outputDiv.innerHTML = `<span class="text-danger">Failed: ${data.error}</span>`;
                } else {
                    outputDiv.innerHTML = data.result;
                    // Reload window to update history listing
                    setTimeout(() => location.reload(), 1500);
                }
            } catch(err) {
                outputDiv.innerHTML = '<span class="text-danger">Network failure when communicating with AI.</span>';
            } finally {
                btnGen.disabled = false;
                btnGen.innerHTML = '<i class="bi bi-cpu me-1"></i> Craft Letter with AI';
            }
        });
    }

    // Bind history clicks
    document.querySelectorAll(".btn-view-history-cl").forEach(btn => {
        btn.onclick = () => {
            const content = btn.getAttribute("data-content");
            outputDiv.innerHTML = content;
            // Scroll right container on mobile
            if (window.innerWidth < 992) {
                outputDiv.scrollIntoView({ behavior: 'smooth' });
            }
        };
    });

    // Copy to clipboard
    if (btnCopy) {
        btnCopy.onclick = () => {
            const text = outputDiv.innerText;
            navigator.clipboard.writeText(text).then(() => {
                const origText = btnCopy.innerHTML;
                btnCopy.innerHTML = '<i class="bi bi-check-lg text-success"></i> Copied!';
                setTimeout(() => btnCopy.innerHTML = origText, 2000);
            });
        };
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
