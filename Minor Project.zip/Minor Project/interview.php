<?php
// interview.php - AI Mock Interview Questions & Evaluation Portal

require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Route guards
require_login();

define('SHOW_SIDEBAR', true);
$db = getDBConnection();
$userId = get_logged_in_user_id();

$resumeId = intval($_GET['id'] ?? 0);

if ($resumeId === 0) {
    // Select resume
    $stmt = $db->prepare("SELECT * FROM resumes WHERE user_id = ? ORDER BY updated_at DESC");
    $stmt->execute([$userId]);
    $resumes = $stmt->fetchAll();
    
    $page_title = "Interview Prep";
    require_once 'includes/header.php';
    ?>
    <div class="row justify-content-center">
        <div class="col-md-8 text-center py-5">
            <i class="bi bi-chat-text text-gradient display-1 mb-3"></i>
            <h2 class="fw-bold Outfit">AI Mock Interview Prep</h2>
            <p class="text-secondary mb-4">Select a resume. We will analyze your skills and projects to construct custom mock interview challenges.</p>
            
            <?php if (count($resumes) === 0): ?>
                <div class="alert alert-warning glass-card py-3">
                    You need to create a resume first. <a href="dashboard.php" class="alert-link text-gradient fw-bold">Create Now</a>
                </div>
            <?php else: ?>
                <div class="list-group col-md-8 mx-auto shadow-sm rounded-3">
                    <?php foreach ($resumes as $res): ?>
                        <a href="interview.php?id=<?php echo $res['id']; ?>" class="list-group-item list-group-item-action bg-transparent border-secondary border-opacity-10 py-3 text-start d-flex justify-content-between align-items-center">
                            <div>
                                <span class="fw-bold text-gradient d-block"><?php echo htmlspecialchars($res['title']); ?></span>
                                <small class="text-secondary"><?php echo htmlspecialchars($res['target_job_role']); ?></small>
                            </div>
                            <span class="btn btn-sm btn-gradient">Select <i class="bi bi-chevron-right small"></i></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
    require_once 'includes/footer.php';
    exit;
}

// Verify ownership
$stmt = $db->prepare("SELECT * FROM resumes WHERE id = ? AND user_id = ?");
$stmt->execute([$resumeId, $userId]);
$resume = $stmt->fetch();

if (!$resume) {
    header("Location: interview.php?error=notfound");
    exit;
}

$page_title = "Mock Interview - " . $resume['title'];
require_once 'includes/header.php';
?>

<div class="row align-items-center mb-4">
    <div class="col">
        <h2 class="fw-bold Outfit mb-0">AI Mock Interview Board</h2>
        <p class="text-secondary mb-0">Prepare for target technical job loops. Review 20 customized loops and test your replies with Gemini.</p>
    </div>
    <div class="col-auto">
        <button class="btn btn-gradient py-2" id="btnGenQuestions">
            <i class="bi bi-arrow-repeat me-1"></i> Generate Mock Loop
        </button>
    </div>
</div>

<div class="row">
    <!-- Questions accordion (Left) -->
    <div class="col-lg-6 mb-4">
        <div class="card glass-card p-4 h-100" id="questionsCardContainer">
            <h5 class="fw-bold mb-3 text-gradient"><i class="bi bi-patch-question me-2"></i>20 Technical & Soft Questions</h5>
            <p class="text-secondary small mb-4">Gemini extracted these categories from your resume skills and projects for <strong><?php echo htmlspecialchars($resume['target_job_role']); ?></strong>.</p>
            
            <div id="questionsLoader" class="text-center py-4 d-none">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Building loop...</span>
                </div>
                <p class="text-secondary mt-2">Constructing custom questions list...</p>
            </div>
            
            <div id="questionsPlaceholder" class="text-center py-5">
                <i class="bi bi-chat-quote text-secondary fs-1 mb-2 d-block"></i>
                <h6 class="fw-bold text-secondary">No Interview Loop Active</h6>
                <p class="text-secondary small px-4">Click "Generate Mock Loop" to assemble specialized easy, medium, and advanced questions.</p>
            </div>
            
            <div class="accordion accordion-flush d-none" id="interviewAccordion">
                <!-- Easy Category -->
                <div class="accordion-item bg-transparent">
                    <h2 class="accordion-header">
                        <button class="accordion-button bg-transparent fw-bold text-gradient" type="button" data-bs-toggle="collapse" data-bs-target="#easyCollapse">
                            Easy Loops (6 Questions)
                        </button>
                    </h2>
                    <div id="easyCollapse" class="accordion-collapse collapse show" data-bs-parent="#interviewAccordion">
                        <div class="accordion-body px-0" id="easyQuestionsList"></div>
                    </div>
                </div>
                
                <!-- Medium Category -->
                <div class="accordion-item bg-transparent">
                    <h2 class="accordion-header">
                        <button class="accordion-button bg-transparent fw-bold text-gradient collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#mediumCollapse">
                            Medium Loops (7 Questions)
                        </button>
                    </h2>
                    <div id="mediumCollapse" class="accordion-collapse collapse" data-bs-parent="#interviewAccordion">
                        <div class="accordion-body px-0" id="mediumQuestionsList"></div>
                    </div>
                </div>
                
                <!-- Advanced Category -->
                <div class="accordion-item bg-transparent">
                    <h2 class="accordion-header">
                        <button class="accordion-button bg-transparent fw-bold text-gradient collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#advCollapse">
                            Advanced Loops (7 Questions)
                        </button>
                    </h2>
                    <div id="advCollapse" class="accordion-collapse collapse" data-bs-parent="#interviewAccordion">
                        <div class="accordion-body px-0" id="advancedQuestionsList"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Answer assessment workspace (Right) -->
    <div class="col-lg-6 mb-4">
        <div class="card glass-card p-4 h-100 d-flex flex-column" id="answerWorkspace">
            <h5 class="fw-bold mb-3 text-gradient"><i class="bi bi-pencil-square me-2"></i>Answer Practice Board</h5>
            <p class="text-secondary small mb-4">Select any question on the left to write and evaluate your answer.</p>
            
            <div class="flex-grow-1 d-flex flex-column" id="workspaceContent">
                <div class="mb-3">
                    <label class="form-label fw-bold text-secondary small">Active Question</label>
                    <div class="p-3 bg-secondary bg-opacity-10 border border-secondary border-opacity-10 rounded-3 small fw-bold" id="activeQuestionText">
                        No question selected.
                    </div>
                </div>
                
                <div class="mb-3 flex-grow-1 d-flex flex-column">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <label class="form-label fw-bold text-secondary small mb-0">Your Answer</label>
                        <button type="button" class="btn btn-xs btn-outline-secondary py-0.5 px-2" id="btnMicAnswer"><i class="bi bi-mic"></i> Speak Answer</button>
                    </div>
                    <textarea class="form-control flex-grow-1" id="userAnswerText" rows="6" placeholder="Type your answer here..." style="min-height: 120px;"></textarea>
                </div>
                
                <button type="button" class="btn btn-gradient w-100 py-2.5 mb-4" id="btnEvaluate" disabled>
                    <i class="bi bi-magic me-1"></i> Submit & Grade with AI
                </button>
                
                <div id="evaluationLoader" class="text-center py-4 d-none">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Grading...</span>
                    </div>
                    <p class="text-secondary mt-2 small">Gemini is checking your vocabulary, technical accuracy and suggestions...</p>
                </div>
                
                <div class="d-none mt-2" id="evaluationResults">
                    <div class="border-top border-secondary border-opacity-10 pt-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="fw-bold text-gradient mb-0">Assessment Feedback</h6>
                            <span class="badge bg-success-subtle text-success px-2 py-1 border border-success-subtle" id="evaluationGrade">Passed</span>
                        </div>
                        <p class="text-secondary small mb-3" id="evaluationFeedback" style="white-space: pre-wrap;"></p>
                        
                        <h6 class="fw-bold text-gradient mb-2">Sample Recruiter-Approved Answer</h6>
                        <div class="p-3 bg-success bg-opacity-10 border border-success border-opacity-10 rounded-3 text-secondary small" id="evaluationIdealAnswer" style="white-space: pre-wrap;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
    const btnGen = document.getElementById("btnGenQuestions");
    const loader = document.getElementById("questionsLoader");
    const placeholder = document.getElementById("questionsPlaceholder");
    const accordion = document.getElementById("interviewAccordion");
    
    const easyList = document.getElementById("easyQuestionsList");
    const medList = document.getElementById("mediumQuestionsList");
    const advList = document.getElementById("advancedQuestionsList");

    const activeText = document.getElementById("activeQuestionText");
    const answerInput = document.getElementById("userAnswerText");
    const btnEval = document.getElementById("btnEvaluate");
    const evalLoader = document.getElementById("evaluationLoader");
    const evalResults = document.getElementById("evaluationResults");
    
    const evalGrade = document.getElementById("evaluationGrade");
    const evalFeedback = document.getElementById("evaluationFeedback");
    const evalIdeal = document.getElementById("evaluationIdealAnswer");
    
    const btnMic = document.getElementById("btnMicAnswer");

    let currentQuestion = "";

    // Speech-to-text integration for answering
    if (btnMic && window.voiceRecognizer) {
        btnMic.onclick = () => {
            window.voiceRecognizer.start(btnMic, answerInput);
        };
    }

    if (btnGen) {
        btnGen.onclick = async () => {
            btnGen.disabled = true;
            placeholder.classList.add("d-none");
            accordion.classList.add("d-none");
            loader.classList.remove("d-none");

            try {
                const response = await fetch(APP_URL + "/ai_generate.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        action: "generate_interview",
                        resume_id: <?php echo $resumeId; ?>
                    })
                });
                const data = await response.json();
                
                if (data.error) {
                    placeholder.innerHTML = `<h6 class="text-danger">Failed to Load Loops: ${data.error}</h6>`;
                    placeholder.classList.remove("d-none");
                } else {
                    renderQuestions(data);
                }
            } catch(e) {
                placeholder.innerHTML = `<h6 class="text-danger">Network Error Occurred.</h6>`;
                placeholder.classList.remove("d-none");
            } finally {
                loader.classList.add("d-none");
                btnGen.disabled = false;
            }
        };
    }

    function renderQuestions(data) {
        const buildList = (array) => {
            return array.map((q, idx) => `
                <div class="list-group-item bg-transparent border-secondary border-opacity-10 py-2.5 px-2 text-start d-flex justify-content-between align-items-center clickable-question" style="cursor:pointer;" data-question="${q}">
                    <span class="small text-secondary">${idx+1}. ${q}</span>
                    <i class="bi bi-chevron-right text-muted small"></i>
                </div>
            `).join('');
        };

        easyList.innerHTML = buildList(data.easy);
        medList.innerHTML = buildList(data.medium);
        advList.innerHTML = buildList(data.advanced);

        accordion.classList.remove("d-none");

        // Bind clicks
        document.querySelectorAll(".clickable-question").forEach(qDiv => {
            qDiv.onclick = () => {
                currentQuestion = qDiv.getAttribute("data-question");
                activeText.innerHTML = currentQuestion;
                answerInput.value = "";
                btnEval.disabled = false;
                evalResults.classList.add("d-none");
                
                // Highlight active row
                document.querySelectorAll(".clickable-question").forEach(x => x.classList.remove("bg-secondary", "bg-opacity-10"));
                qDiv.classList.add("bg-secondary", "bg-opacity-10");
                
                if (window.innerWidth < 992) {
                    document.getElementById("answerWorkspace").scrollIntoView({ behavior: 'smooth' });
                }
            };
        });
    }

    // Handle Evaluation click
    if (btnEval) {
        btnEval.onclick = async () => {
            const answerText = answerInput.value.trim();
            if (!answerText) {
                alert("Please type or speak your answer before submitting.");
                return;
            }

            btnEval.disabled = true;
            evalResults.classList.add("d-none");
            evalLoader.classList.remove("d-none");

            try {
                const response = await fetch(APP_URL + "/ai_generate.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        action: "chatbot_message",
                        message: `A candidate is answering an interview question. Assess their answer and generate feedback.\nQuestion: "${currentQuestion}"\nCandidate Answer: "${answerText}"\nOutput a JSON object ONLY with structure: {"grade": "Strong/Acceptable/Needs Work", "feedback": "Detailed corrections of errors or structural additions", "ideal_answer": "Complete recruiter-approved response for this question"}. Do not include markdown code fences.`
                    })
                });
                const data = await response.json();
                
                let parsed;
                try {
                    const cleanRes = data.result.replace(/```(json)?/g, '').trim();
                    parsed = JSON.parse(cleanRes);
                } catch(err) {
                    parsed = {
                        grade: "Evaluated",
                        feedback: data.result,
                        ideal_answer: "Ideal response based on your developer skillset."
                    };
                }

                evalGrade.innerHTML = parsed.grade;
                if (parsed.grade.toLowerCase().includes("needs work")) {
                    evalGrade.className = "badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-1";
                } else if (parsed.grade.toLowerCase().includes("acceptable")) {
                    evalGrade.className = "badge bg-warning-subtle text-warning border border-warning-subtle px-2 py-1";
                } else {
                    evalGrade.className = "badge bg-success-subtle text-success border border-success-subtle px-2 py-1";
                }
                
                evalFeedback.innerHTML = parsed.feedback;
                evalIdeal.innerHTML = parsed.ideal_answer;
                
                evalResults.classList.remove("d-none");
                
            } catch(e) {
                alert("Evaluation network failure.");
            } finally {
                evalLoader.classList.add("d-none");
                btnEval.disabled = false;
            }
        };
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
