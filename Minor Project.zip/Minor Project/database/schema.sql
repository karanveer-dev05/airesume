-- AI Resume Builder Database Schema

CREATE DATABASE IF NOT EXISTS `resume_builder` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `resume_builder`;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('user', 'admin') DEFAULT 'user',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Resumes Table (includes personal details)
CREATE TABLE IF NOT EXISTS `resumes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `title` VARCHAR(100) NOT NULL DEFAULT 'My Resume',
  `template_style` VARCHAR(50) DEFAULT 'modern',
  `target_job_role` VARCHAR(100) DEFAULT 'Software Engineer',
  `full_name` VARCHAR(100) DEFAULT '',
  `email` VARCHAR(100) DEFAULT '',
  `phone` VARCHAR(30) DEFAULT '',
  `linkedin` VARCHAR(255) DEFAULT '',
  `github` VARCHAR(255) DEFAULT '',
  `portfolio` VARCHAR(255) DEFAULT '',
  `address` TEXT DEFAULT NULL,
  `summary` TEXT DEFAULT NULL,
  `hobbies` TEXT DEFAULT NULL,
  `strengths` TEXT DEFAULT NULL,
  `signature_data` LONGTEXT DEFAULT NULL,
  `share_token` VARCHAR(64) UNIQUE DEFAULT NULL,
  `recruiter_comments_enabled` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Education Table
CREATE TABLE IF NOT EXISTS `education` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `resume_id` INT NOT NULL,
  `institution` VARCHAR(150) NOT NULL,
  `degree` VARCHAR(100) DEFAULT NULL,
  `field_of_study` VARCHAR(100) DEFAULT NULL,
  `start_date` DATE DEFAULT NULL,
  `end_date` DATE DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  FOREIGN KEY (`resume_id`) REFERENCES `resumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Experience Table
CREATE TABLE IF NOT EXISTS `experience` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `resume_id` INT NOT NULL,
  `company` VARCHAR(150) NOT NULL,
  `position` VARCHAR(100) DEFAULT NULL,
  `start_date` DATE DEFAULT NULL,
  `end_date` DATE DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `location` VARCHAR(100) DEFAULT NULL,
  FOREIGN KEY (`resume_id`) REFERENCES `resumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Projects Table
CREATE TABLE IF NOT EXISTS `projects` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `resume_id` INT NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `technologies` VARCHAR(255) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `link` VARCHAR(255) DEFAULT NULL,
  FOREIGN KEY (`resume_id`) REFERENCES `resumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Skills Table
CREATE TABLE IF NOT EXISTS `skills` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `resume_id` INT NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `skill_type` ENUM('technical', 'soft', 'language') DEFAULT 'technical',
  `level` VARCHAR(50) DEFAULT 'Intermediate',
  FOREIGN KEY (`resume_id`) REFERENCES `resumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Certificates Table
CREATE TABLE IF NOT EXISTS `certificates` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `resume_id` INT NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `issuer` VARCHAR(150) DEFAULT NULL,
  `issue_date` DATE DEFAULT NULL,
  `link` VARCHAR(255) DEFAULT NULL,
  FOREIGN KEY (`resume_id`) REFERENCES `resumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Achievements Table
CREATE TABLE IF NOT EXISTS `achievements` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `resume_id` INT NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `date` DATE DEFAULT NULL,
  FOREIGN KEY (`resume_id`) REFERENCES `resumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Resume Versions Table
CREATE TABLE IF NOT EXISTS `resume_versions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `resume_id` INT NOT NULL,
  `version_data` LONGTEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`resume_id`) REFERENCES `resumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Resume Scores Table
CREATE TABLE IF NOT EXISTS `resume_scores` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `resume_id` INT NOT NULL,
  `score` INT NOT NULL,
  `grammar_score` INT NOT NULL,
  `ats_score` INT NOT NULL,
  `keywords_analysis` TEXT DEFAULT NULL,
  `suggestions` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`resume_id`) REFERENCES `resumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Cover Letters Table
CREATE TABLE IF NOT EXISTS `cover_letters` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `resume_id` INT NOT NULL,
  `company_name` VARCHAR(150) NOT NULL,
  `job_role` VARCHAR(150) NOT NULL,
  `content` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`resume_id`) REFERENCES `resumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. AI History Table
CREATE TABLE IF NOT EXISTS `ai_history` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `resume_id` INT DEFAULT NULL,
  `action_type` VARCHAR(50) NOT NULL,
  `prompt_tokens` INT DEFAULT 0,
  `response_tokens` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. Recruiter Reviews Table
CREATE TABLE IF NOT EXISTS `recruiter_reviews` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `resume_id` INT NOT NULL,
  `recruiter_name` VARCHAR(100) DEFAULT NULL,
  `rating` INT DEFAULT NULL,
  `comments` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`resume_id`) REFERENCES `resumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed default Admin User (password is 'admin123')
INSERT INTO `users` (`username`, `email`, `password_hash`, `role`)
VALUES ('admin', 'admin@ai-resumebuilder.com', '$2y$10$wN9PezJ4qFkQ1Pia/1PKe.00B81wF4xH.07M2V4pX008d5nK5U6q.', 'admin')
ON DUPLICATE KEY UPDATE `id`=`id`;
