-- Migration v2: Add Strengths and Signature columns to resumes table
-- Run this once in phpMyAdmin or MySQL console

USE `resume_builder`;

ALTER TABLE `resumes`
    ADD COLUMN IF NOT EXISTS `strengths` TEXT DEFAULT NULL AFTER `hobbies`,
    ADD COLUMN IF NOT EXISTS `signature_data` LONGTEXT DEFAULT NULL AFTER `strengths`;
