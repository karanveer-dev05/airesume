// voice.js - Voice Recognition Engine for Form Fields

class VoiceRecognizer {
    constructor() {
        this.recognition = null;
        this.activeButton = null;
        this.activeTarget = null;
        this.isListening = false;
        
        this.init();
    }

    init() {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (SpeechRecognition) {
            this.recognition = new SpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US';

            this.recognition.onstart = () => {
                this.isListening = true;
                if (this.activeButton) {
                    this.activeButton.classList.add("btn-danger", "text-white");
                    this.activeButton.classList.remove("btn-outline-secondary");
                    this.activeButton.innerHTML = '<i class="bi bi-mic-fill animate-pulse"></i> Listening...';
                }
            };

            this.recognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                if (this.activeTarget) {
                    // Append transcript or replace if empty
                    const currentValue = this.activeTarget.value.trim();
                    this.activeTarget.value = currentValue ? currentValue + " " + transcript : transcript;
                    // Trigger input change event for binding/validation frameworks
                    this.activeTarget.dispatchEvent(new Event('input'));
                }
            };

            this.recognition.onerror = (e) => {
                console.error("Speech recognition error:", e.error);
                this.stopListening();
            };

            this.recognition.onend = () => {
                this.stopListening();
            };
        }
    }

    start(button, targetInput) {
        if (!this.recognition) {
            alert("Voice Speech Recognition is not supported by your current browser. Please try Google Chrome or Microsoft Edge.");
            return;
        }

        if (this.isListening) {
            this.recognition.stop();
            return;
        }

        this.activeButton = button;
        this.activeTarget = targetInput;
        this.recognition.start();
    }

    stopListening() {
        this.isListening = false;
        if (this.activeButton) {
            this.activeButton.classList.remove("btn-danger", "text-white");
            this.activeButton.classList.add("btn-outline-secondary");
            this.activeButton.innerHTML = '<i class="bi bi-mic"></i>';
        }
        this.activeButton = null;
        this.activeTarget = null;
    }
}

// Global initialization
window.voiceRecognizer = new VoiceRecognizer();

// Helper to bind elements dynamically
function bindVoiceInput(buttonId, targetId) {
    const btn = document.getElementById(buttonId);
    const target = document.getElementById(targetId);
    if (btn && target) {
        btn.addEventListener("click", () => {
            window.voiceRecognizer.start(btn, target);
        });
    }
}
