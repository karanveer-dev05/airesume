// chatbot.js - CareerCraft AI Assistant Panel Controller

document.addEventListener("DOMContentLoaded", () => {
    const trigger = document.getElementById("chatbot-trigger");
    const container = document.getElementById("chatbot-container");
    const closeBtn = document.getElementById("chatbot-close");
    const sendBtn = document.getElementById("chatbot-send");
    const textInput = document.getElementById("chatbotInput");
    const voiceBtn = document.getElementById("chatbotVoiceBtn");
    const messagesBox = document.getElementById("chatbotMessages");

    let chatHistory = [];

    if (!trigger || !container) return;

    // Toggle panel
    trigger.addEventListener("click", () => {
        container.classList.remove("d-none");
        trigger.classList.add("d-none");
        textInput.focus();
    });

    closeBtn.addEventListener("click", () => {
        container.classList.add("d-none");
        trigger.classList.remove("d-none");
    });

    // Send Message function
    const sendMessage = async () => {
        const text = textInput.value.trim();
        if (!text) return;

        // Render User Message
        appendMessage("user", text);
        textInput.value = "";

        // Show typing indicator
        const typingId = appendMessage("bot", '<div class="spinner-border spinner-border-sm text-secondary" role="status"><span class="visually-hidden">Thinking...</span></div>');

        try {
            const response = await fetch(APP_URL + "/ai_generate.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    action: "chatbot_message",
                    message: text,
                    history: chatHistory
                })
            });
            const data = await response.json();
            
            // Remove typing indicator
            removeMessage(typingId);

            if (data.error) {
                appendMessage("bot", "Error: " + data.error);
            } else {
                appendMessage("bot", data.result);
                // Keep history limited to last 6 entries to conserve tokens
                chatHistory.push({ role: "user", text: text });
                chatHistory.push({ role: "assistant", text: data.result });
                if (chatHistory.length > 12) {
                    chatHistory.shift();
                    chatHistory.shift();
                }
            }
        } catch (error) {
            removeMessage(typingId);
            appendMessage("bot", "Network error occurred while communicating with AI.");
            console.error(error);
        }
    };

    // Helper functions to modify messages
    let messageCounter = 0;
    function appendMessage(sender, htmlContent) {
        messageCounter++;
        const id = "msg-" + messageCounter;
        const msgDiv = document.createElement("div");
        msgDiv.id = id;
        msgDiv.className = `chatbot-message ${sender}`;
        msgDiv.innerHTML = htmlContent;
        messagesBox.appendChild(msgDiv);
        messagesBox.scrollTop = messagesBox.scrollHeight;
        return id;
    }

    function removeMessage(id) {
        const el = document.getElementById(id);
        if (el) el.remove();
    }

    // Trigger buttons
    const chatbotSendBtn = document.getElementById("chatbotSend");
    if (chatbotSendBtn) {
        chatbotSendBtn.addEventListener("click", sendMessage);
    }
    
    textInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
            sendMessage();
        }
    });

    // Voice to Text helper in chatbot
    if (voiceBtn && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onstart = () => {
            voiceBtn.innerHTML = '<i class="bi bi-record-circle text-danger animate-pulse"></i>';
        };

        recognition.onresult = (event) => {
            const resultText = event.results[0][0].transcript;
            textInput.value = resultText;
        };

        recognition.onerror = (event) => {
            console.error("Speech recognition error", event.error);
            voiceBtn.innerHTML = '<i class="bi bi-mic"></i>';
        };

        recognition.onend = () => {
            voiceBtn.innerHTML = '<i class="bi bi-mic"></i>';
        };

        voiceBtn.addEventListener("click", () => {
            recognition.start();
        });
    } else if (voiceBtn) {
        // No webkit support
        voiceBtn.classList.add("disabled");
        voiceBtn.title = "Voice recognition not supported by browser";
    }
});
