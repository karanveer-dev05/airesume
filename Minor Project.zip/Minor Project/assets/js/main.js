// main.js - Core UI Interactions & Theme Controller

document.addEventListener("DOMContentLoaded", () => {
    // Dark/Light Theme Switching
    const themeToggler = document.getElementById("themeToggler");
    const themeTogglerIcon = document.getElementById("themeTogglerIcon");
    const htmlElement = document.documentElement;

    const setTheme = (theme) => {
        htmlElement.setAttribute("data-bs-theme", theme);
        localStorage.setItem("app-theme", theme);
        
        if (theme === "dark") {
            themeTogglerIcon.className = "bi bi-sun-fill text-warning";
        } else {
            themeTogglerIcon.className = "bi bi-moon-stars-fill";
        }
    };

    // Load persisted theme or default to system preference
    const savedTheme = localStorage.getItem("app-theme");
    const systemPrefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    
    if (savedTheme) {
        setTheme(savedTheme);
    } else {
        setTheme(systemPrefersDark ? "dark" : "light");
    }

    if (themeToggler) {
        themeToggler.addEventListener("click", () => {
            const currentTheme = htmlElement.getAttribute("data-bs-theme");
            setTheme(currentTheme === "dark" ? "light" : "dark");
        });
    }

    // Interactive Sidebar toggle for mobile layouts
    const sidebar = document.querySelector(".sidebar");
    const toggleButton = document.querySelector(".navbar-toggler");
    if (toggleButton && sidebar) {
        toggleButton.addEventListener("click", (e) => {
            if (window.innerWidth < 992) {
                sidebar.classList.toggle("active");
            }
        });
    }

    // Auto-fade dismiss alerts
    const alerts = document.querySelectorAll(".alert-dismissible");
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = bootstrap.Alert.getInstance(alert);
            if (bsAlert) bsAlert.close();
        }, 5000);
    });
});
