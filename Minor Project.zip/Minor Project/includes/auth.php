<?php
// auth.php - Authentication Helper Utilities

require_once __DIR__ . '/config.php';

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function get_logged_in_user_id() {
    return $_SESSION['user_id'] ?? null;
}

function get_logged_in_username() {
    return $_SESSION['username'] ?? '';
}

function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function require_login() {
    if (!is_logged_in()) {
        header("Location: " . APP_URL . "/login.php");
        exit;
    }
}

function require_admin() {
    require_login();
    if (!is_admin()) {
        header("Location: " . APP_URL . "/dashboard.php?error=unauthorized");
        exit;
    }
}

function login_user($id, $username, $role) {
    $_SESSION['user_id'] = $id;
    $_SESSION['username'] = $username;
    $_SESSION['role'] = $role;
}

function logout_user() {
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
    header("Location: " . APP_URL . "/login.php");
    exit;
}
?>
