<?php
// config.php - System Configuration & Initialization

// Ensure session is started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Database Credentials
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'resume_builder');

// Gemini API Configuration
// Users/Admins can set the API key in their environment variables, or edit it here directly.
define('GEMINI_API_KEY', getenv('GEMINI_API_KEY') ?: 'YOUR_GEMINI_API_KEY_HERE');
define('GEMINI_API_URL', 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent');

// System Constants
define('APP_NAME', 'AI Resume Builder');
define('APP_URL', 'http://localhost/Minor Project');

// Available Target Job Roles
$job_roles = [
    'Software Engineer',
    'Web Developer',
    'Data Analyst',
    'AI Engineer',
    'Java Developer',
    'Python Developer',
    'Cloud Engineer'
];

// Available Resume Templates
$templates = [
    'modern' => 'Modern Violet',
    'professional' => 'Professional Corporate',
    'creative' => 'Creative Orange',
    'minimal' => 'Minimal Slate',
    'corporate' => 'Classic Corporate',
    'dark' => 'Cyber Dark Mode',
    'light' => 'Pure White Light'
];
?>
