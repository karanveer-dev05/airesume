<?php
// header.php - Header Layout Template

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title><?php echo isset($page_title) ? $page_title . " | " . APP_NAME : APP_NAME; ?></title>
    
    <!-- Meta tags for SEO -->
    <meta name="description" content="Build premium ATS-friendly professional resumes with Gemini AI writing assistance, templates, scores, mock interviews, and recruiter sharing.">
    <meta name="author" content="AI Resume Builder">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/style.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
    <!-- Bootstrap 5 CSS override using standard URL -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <!-- Custom Style Sheet -->
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/style.css">
    <!-- Dancing Script for typed signature -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap" rel="stylesheet">
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg glass-nav fixed-top no-print">
    <div class="container-fluid px-4">
        <a class="navbar-brand d-flex align-items-center" href="<?php echo APP_URL; ?>/index.php">
            <i class="bi bi-rocket-takeoff-fill text-gradient fs-3 me-2"></i>
            <span class="fw-bold Outfit text-gradient fs-4">CareerCraft AI</span>
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <?php if (is_logged_in()): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>" href="<?php echo APP_URL; ?>/dashboard.php">
                            <i class="bi bi-speedometer2 me-1"></i> Dashboard
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
            
            <div class="d-flex align-items-center gap-3">
                <!-- Theme Switcher -->
                <button class="btn btn-link text-body p-2 border-0" id="themeToggler" type="button" aria-label="Toggle theme">
                    <i class="bi bi-moon-stars-fill" id="themeTogglerIcon"></i>
                </button>
                
                <?php if (is_logged_in()): ?>
                    <div class="dropdown">
                        <button class="btn btn-outline-gradient dropdown-toggle d-flex align-items-center gap-2" type="button" id="userMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person-circle"></i>
                            <span><?php echo htmlspecialchars(get_logged_in_username()); ?></span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end glass-card" aria-labelledby="userMenuButton">
                            <?php if (is_admin()): ?>
                                <li>
                                    <a class="dropdown-item text-warning" href="<?php echo APP_URL; ?>/admin/dashboard.php">
                                        <i class="bi bi-shield-lock-fill me-2"></i> Admin Panel
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>
                            <li>
                                <a class="dropdown-item text-danger" href="<?php echo APP_URL; ?>/login.php?action=logout">
                                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="<?php echo APP_URL; ?>/login.php" class="btn btn-outline-gradient">Login</a>
                    <a href="<?php echo APP_URL; ?>/register.php" class="btn btn-gradient">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<?php 
// Show Sidebar if defined in page
if (defined('SHOW_SIDEBAR') && SHOW_SIDEBAR === true && is_logged_in()): 
?>
<!-- Sidebar Navigation -->
<div class="sidebar no-print">
    <a href="<?php echo APP_URL; ?>/dashboard.php" class="sidebar-link <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
        <i class="bi bi-house-door"></i> Dashboard
    </a>
    <a href="<?php echo APP_URL; ?>/resume.php" class="sidebar-link <?php echo ($current_page == 'resume.php') ? 'active' : ''; ?>">
        <i class="bi bi-file-earmark-person"></i> Resume Builder
    </a>
    <a href="<?php echo APP_URL; ?>/ats_checker.php" class="sidebar-link <?php echo ($current_page == 'ats_checker.php') ? 'active' : ''; ?>">
        <i class="bi bi-patch-check"></i> ATS Optimizer
    </a>
    <a href="<?php echo APP_URL; ?>/cover_letter.php" class="sidebar-link <?php echo ($current_page == 'cover_letter.php') ? 'active' : ''; ?>">
        <i class="bi bi-envelope-paper"></i> Cover Letter
    </a>
    <a href="<?php echo APP_URL; ?>/interview.php" class="sidebar-link <?php echo ($current_page == 'interview.php') ? 'active' : ''; ?>">
        <i class="bi bi-chat-text"></i> Mock Interview
    </a>
    <a href="<?php echo APP_URL; ?>/portfolio.php" class="sidebar-link <?php echo ($current_page == 'portfolio.php') ? 'active' : ''; ?>">
        <i class="bi bi-globe"></i> Portfolio Web
    </a>
    <?php if (is_admin()): ?>
        <hr class="mx-3 my-2 text-muted">
        <a href="<?php echo APP_URL; ?>/admin/dashboard.php" class="sidebar-link text-warning">
            <i class="bi bi-shield-lock"></i> Admin Console
        </a>
    <?php endif; ?>
</div>
<div class="main-content">
<?php endif; ?>
