<?php
// footer.php - Footer Layout Template
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
?>

<?php if (defined('SHOW_SIDEBAR') && SHOW_SIDEBAR === true && is_logged_in()): ?>
</div> <!-- End of main-content -->
<?php endif; ?>

<!-- Footer Area (For pages without sidebar) -->
<?php if (!defined('SHOW_SIDEBAR') || SHOW_SIDEBAR === false): ?>
<footer class="py-4 mt-auto border-top no-print" style="border-color: var(--card-border) !important;">
    <div class="container text-center">
        <p class="text-secondary mb-0">&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. Built with Gemini AI.</p>
    </div>
</footer>
<?php endif; ?>

<!-- AI Assistant Floating Chatbot (Only if logged in) -->
<?php if (is_logged_in() && basename($_SERVER['PHP_SELF']) != 'login.php' && basename($_SERVER['PHP_SELF']) != 'register.php'): ?>
<button id="chatbot-trigger" class="no-print" title="Ask CareerCraft AI Assistant">
    <i class="bi bi-robot"></i>
</button>

<div id="chatbot-container" class="glass-card d-none no-print">
    <div class="chatbot-header">
        <div class="d-flex align-items-center gap-2">
            <i class="bi bi-cpu fs-5"></i>
            <span class="fw-bold">CareerCraft Assistant</span>
        </div>
        <button type="button" class="btn-close btn-close-white" id="chatbot-close" aria-label="Close"></button>
    </div>
    <div class="chatbot-messages d-flex flex-column" id="chatbotMessages">
        <div class="chatbot-message bot">
            Hello! I am your AI career assistant. How can I help you improve your resume, write descriptions, or prepare for interviews today?
        </div>
    </div>
    <div class="chatbot-input-area">
        <input type="text" id="chatbotInput" class="form-control" placeholder="Ask AI to improve experience..." aria-label="Ask AI">
        <button class="btn btn-outline-secondary" id="chatbotVoiceBtn" type="button" title="Speak to build">
            <i class="bi bi-mic"></i>
        </button>
        <button class="btn btn-gradient px-3" id="chatbotSend" type="button">
            <i class="bi bi-send-fill"></i>
        </button>
    </div>
</div>
<?php endif; ?>

<!-- Bootstrap Bundle with Popper JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom JS Application Scripts -->
<script>
    // Set global app URL variable for JS scripts
    const APP_URL = "<?php echo APP_URL; ?>";
</script>
<script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
<?php if (is_logged_in()): ?>
    <script src="<?php echo APP_URL; ?>/assets/js/voice.js"></script>
    <script src="<?php echo APP_URL; ?>/assets/js/chatbot.js"></script>
<?php endif; ?>

</body>
</html>
