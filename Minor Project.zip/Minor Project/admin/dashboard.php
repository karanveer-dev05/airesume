<?php
// admin/dashboard.php - Administrator Control Console

require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Force Admin Access
require_admin();

define('SHOW_SIDEBAR', false); // No user-centric sidebar
$db = getDBConnection();

$error_msg = "";
$success_msg = "";

// 1. Handle User Deletion
if (isset($_GET['action']) && $_GET['action'] === 'delete_user' && isset($_GET['id'])) {
    $targetId = intval($_GET['id']);
    
    // Prevent self-deletion
    if ($targetId === get_logged_in_user_id()) {
        $error_msg = "You cannot delete your own admin account.";
    } else {
        $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
        if ($stmt->execute([$targetId])) {
            $success_msg = "User deleted successfully.";
        } else {
            $error_msg = "Failed to delete user.";
        }
    }
}

// 2. Fetch Admin Statistics
// Total users
$totalUsers = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
// Total resumes
$totalResumes = $db->query("SELECT COUNT(*) FROM resumes")->fetchColumn();
// Total AI operations
$totalAiCalls = $db->query("SELECT COUNT(*) FROM ai_history")->fetchColumn();

// Popular job roles
$stmt = $db->query("SELECT target_job_role, COUNT(*) as count FROM resumes GROUP BY target_job_role ORDER BY count DESC LIMIT 5");
$popularRoles = $stmt->fetchAll();

// Popular Skills
$stmt = $db->query("SELECT name, COUNT(*) as count FROM skills GROUP BY name ORDER BY count DESC LIMIT 8");
$popularSkills = $stmt->fetchAll();

// Gemini Action Types counts
$stmt = $db->query("SELECT action_type, COUNT(*) as count FROM ai_history GROUP BY action_type ORDER BY count DESC");
$aiActionStats = $stmt->fetchAll();

// 3. Fetch User Directory List
$stmt = $db->query("SELECT id, username, email, role, created_at FROM users ORDER BY id ASC");
$usersList = $stmt->fetchAll();

$page_title = "Admin Panel";
require_once '../includes/header.php';
?>

<!-- Custom Admin Layout Container -->
<div class="container py-5 mt-5">
    <div class="row align-items-center mb-4">
        <div class="col">
            <h2 class="fw-bold Outfit mb-0 text-gradient"><i class="bi bi-shield-lock-fill me-2"></i>Admin Console</h2>
            <p class="text-secondary mb-0">Monitor workspace metrics, user records, and Gemini API token operations.</p>
        </div>
        <div class="col-auto">
            <a href="../dashboard.php" class="btn btn-outline-gradient"><i class="bi bi-arrow-left"></i> User Panel</a>
        </div>
    </div>

    <!-- Alert triggers -->
    <?php if ($success_msg): ?>
        <div class="alert alert-success alert-dismissible fade show glass-card py-3 mb-4" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <span><?php echo htmlspecialchars($success_msg); ?></span>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger alert-dismissible fade show glass-card py-3 mb-4" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <span><?php echo htmlspecialchars($error_msg); ?></span>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Total Workspace Metrics -->
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="card glass-card p-4">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-secondary text-uppercase fw-bold small">Total Register Users</h6>
                        <h3 class="fw-bold mb-0 text-gradient"><?php echo $totalUsers; ?></h3>
                    </div>
                    <div class="fs-1 text-primary"><i class="bi bi-people-fill"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card glass-card p-4">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-secondary text-uppercase fw-bold small">Total Generated Resumes</h6>
                        <h3 class="fw-bold mb-0 text-gradient"><?php echo $totalResumes; ?></h3>
                    </div>
                    <div class="fs-1 text-success"><i class="bi bi-file-earmark-bar-graph-fill"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card glass-card p-4">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-secondary text-uppercase fw-bold small">Total Gemini AI Calls</h6>
                        <h3 class="fw-bold mb-0 text-gradient"><?php echo $totalAiCalls; ?></h3>
                    </div>
                    <div class="fs-1 text-warning"><i class="bi bi-cpu-fill"></i></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-5">
        <!-- Gemini AI Usage distribution details -->
        <div class="col-lg-6">
            <div class="card glass-card p-4 h-100">
                <h5 class="fw-bold mb-3 text-gradient"><i class="bi bi-activity me-2"></i>Gemini API Activity distribution</h5>
                <div class="table-responsive">
                    <table class="table table-sm align-middle">
                        <thead>
                            <tr class="text-secondary small">
                                <th>Action Call Type</th>
                                <th class="text-end">Total Executions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($aiActionStats) === 0): ?>
                                <tr><td colspan="2" class="text-center text-muted small py-3">No AI history tracked.</td></tr>
                            <?php else: ?>
                                <?php foreach ($aiActionStats as $stat): ?>
                                    <tr class="small text-secondary">
                                        <td><code><?php echo htmlspecialchars($stat['action_type']); ?></code></td>
                                        <td class="text-end fw-bold"><?php echo $stat['count']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Popular Job Roles & Skills -->
        <div class="col-lg-6">
            <div class="card glass-card p-4 h-100">
                <h5 class="fw-bold mb-3 text-gradient"><i class="bi bi-bar-chart-line me-2"></i>Domain & Skills Insights</h5>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="fw-bold small text-secondary d-block mb-2">Top Job Roles</label>
                        <ul class="list-group list-group-flush bg-transparent">
                            <?php foreach ($popularRoles as $role): ?>
                                <li class="list-group-item bg-transparent border-secondary border-opacity-10 px-0 py-1.5 small text-secondary d-flex justify-content-between">
                                    <span><?php echo htmlspecialchars($role['target_job_role']); ?></span>
                                    <span class="badge bg-secondary-subtle text-secondary px-2 rounded-pill"><?php echo $role['count']; ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <label class="fw-bold small text-secondary d-block mb-2">Most Popular Skills</label>
                        <ul class="list-group list-group-flush bg-transparent">
                            <?php foreach ($popularSkills as $sk): ?>
                                <li class="list-group-item bg-transparent border-secondary border-opacity-10 px-0 py-1.5 small text-secondary d-flex justify-content-between">
                                    <span><?php echo htmlspecialchars($sk['name']); ?></span>
                                    <span class="badge bg-secondary-subtle text-secondary px-2 rounded-pill"><?php echo $sk['count']; ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- User directory management -->
    <div class="card glass-card p-4">
        <h5 class="fw-bold mb-4 text-gradient"><i class="bi bi-people me-2"></i>Workspace User Directory</h5>
        
        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr class="text-secondary small">
                        <th>User ID</th>
                        <th>Username</th>
                        <th>Email Address</th>
                        <th>Access Role</th>
                        <th>Date Registered</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($usersList as $user): ?>
                        <tr class="small text-secondary">
                            <td><?php echo $user['id']; ?></td>
                            <td><strong class="text-body"><?php echo htmlspecialchars($user['username']); ?></strong></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <span class="badge <?php echo ($user['role'] === 'admin') ? 'bg-warning-subtle text-warning border border-warning-subtle' : 'bg-secondary-subtle text-secondary border border-secondary-subtle'; ?> px-2.5 py-1.5">
                                    <?php echo strtoupper($user['role']); ?>
                                </span>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                            <td class="text-center">
                                <?php if ($user['id'] !== get_logged_in_user_id()): ?>
                                    <a href="dashboard.php?action=delete_user&id=<?php echo $user['id']; ?>" class="btn btn-sm btn-link text-danger p-0" onclick="return confirm('Are you sure you want to delete this user and all their resumes? This action cannot be undone.');">
                                        <i class="bi bi-trash fs-5"></i>
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted small">Current User</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
