<?php
// download_pdf.php - Helper to trigger print PDF view of a resume

require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

require_login();

$resumeId = intval($_GET['id'] ?? 0);
if ($resumeId === 0) {
    header("Location: dashboard.php");
    exit;
}

// Redirect user directly to the builder with a print trigger
header("Location: resume.php?id=" . $resumeId . "&print=1");
exit;
?>
